#!/bin/sh
#
# PowerChute Network Shutdown Daemon
# Copyright (c) 1999-2018 Schneider Electric, All Rights Reserved. 
#
# chkconfig: 2345 99 99
# description: PowerChute Network Shutdown Daemon
#
# LSB required header
### BEGIN INIT INFO
# Provides:          PowerChute 
# Required-Start:    $network $remote_fs $syslog
# Required-Stop:     $network $remote_fs $syslog
# Default-Start:     1 3 5
# Default-Stop:      0 1 6
# Short-Description: PCNS Deamon.
# Description:       PowerChute Network Shutdown Deamon.
### END INIT INFO


INSTALL_PATH=GSUB_INSTALL_PATH

GROUP1_PATH=$INSTALL_PATH"/group1"
GROUP2_PATH=$INSTALL_PATH"/group2"
GROUP3_PATH=$INSTALL_PATH"/group3"

START_SCRIPT="powerchute.sh"
GROUP1_START=$GROUP1_PATH"/"$START_SCRIPT
GROUP2_START=$GROUP2_PATH"/"$START_SCRIPT
GROUP3_START=$GROUP3_PATH"/"$START_SCRIPT

PID_FILE="pcns.pid"
GROUP1_PID=$GROUP1_PATH"/"$PID_FILE
GROUP2_PID=$GROUP2_PATH"/"$PID_FILE
GROUP3_PID=$GROUP3_PATH"/"$PID_FILE

case "$1" in
start_msg) echo "Start PowerChute Network Shutdown" ;;

start)
    echo
    echo "PowerChute Network Shutdown, v4.3.0"
    echo "Copyright (c) 1999-2018, Schneider Electric.  All Rights Reserved."

    if [ -s $GROUP1_START ] # Group1 is insatalled
    then
        if [ -s $GROUP2_START ] # echo only multiple group are insatalled
        then
            echo "Starting Group #1 ..."
        fi
        cd $GROUP1_PATH
        ./$START_SCRIPT 2>/dev/null
        if [ ! $? = 0 ]; then
            echo
            echo "Failed to start PowerChute Network Shutdown"
            echo
            exit 1
        fi
    fi
    if [ -s $GROUP2_START ] # Group2 is insatalled
    then
        echo "Starting Group #2 ..."
        cd $GROUP2_PATH
        ./$START_SCRIPT 2>/dev/null
        if [ ! $? = 0 ]; then
            echo
            echo "Failed to start PowerChute Network Shutdown"
            echo
            exit 1
        fi
    fi
    if [ -s $GROUP3_START ] # Group3 is insatalled
    then
        echo "Starting Group #3 ..."
        cd $GROUP3_PATH
        ./$START_SCRIPT 2>/dev/null
        if [ ! $? = 0 ]; then
            echo
            echo "Failed to start PowerChute Network Shutdown"
            echo
            exit 1
        fi
    fi
    
    #
    # Create Linux Lock File
    #
    OS=`uname | grep -i Linux`
    if [ ! -z "$OS" ]; then
    	# Fix for PCNS-3377
    	if [ -d "/var/lock/subsys" ]; then
    		touch /var/lock/subsys/PowerChute
    	else
    		if [ -d "/var/lock" ]; then
    			touch /var/lock/PowerChute
    		fi
    	fi
    fi
        
    echo "Startup completed."
    echo
    ;;

stop_msg) echo "Stop PowerChute Network Shutdown" ;;

stop)
    if [ -s $GROUP1_PID ] #file containing pid exists
    then
        set `cat $GROUP1_PID` 
        echo "Killing PowerChute Network Shutdown Group #1. PID= $1"
        kill -9 $1
        rm $GROUP1_PID
    fi
    if [ -s $GROUP2_PID ] #file containing pid exists
    then
        set `cat $GROUP2_PID` 
        echo "Killing PowerChute Network Shutdown Group #2. PID= $1"
        kill -9 $1
        rm $GROUP2_PID
    fi
    if [ -s $GROUP3_PID ] #file containing pid exists
    then
        set `cat $GROUP3_PID` 
        echo "Killing PowerChute Network Shutdown Group #3. PID= $1"
        kill -9 $1
        rm $GROUP3_PID
    fi
    
    #
    # Remove linux lock file
    #
    OS=`uname | grep -i Linux`
    if [ ! -z "$OS" ]; then
    # Fix for PCNS-3377
    	if [ -d "/var/lock/subsys" ]; then
        	rm -f /var/lock/subsys/PowerChute
        else
        	if [ -d "/var/lock" ]; then
        		rm -f /var/lock/PowerChute
        	fi
        fi
    fi
    
    echo "Done."
    echo    
    ;;

status)
    ps -p `cat $GROUP1_PATH/pcns.pid 2>/dev/null | awk "{ print "'$1'" }"` 2>/dev/null | grep 'java' > /dev/null
    if [ $? = 0 -a -f $GROUP1_PATH/pcns.pid ]
    then
        echo "PowerChute is running ..."
    else
        echo "PowerChute is stopped"
    fi
    ;;

*)
    echo "Usage $0 [start|stop|status]"
    ;;
esac

exit 0
