var resRequiredFieldValidation,
    resRangeLengthValidation,
    resInvalidCharacters,
    resPassPhraseWhiteSpaceError,
    resSSHKeyNotFound,
    resValidVcenterServerValidation,
    resPasswordDialogTitle,
    resVMPasswordDialogTitle,
    resVMHostPasswordDialogTitle,
    resVMPassphraseDialogTitle,
    resAdminPasswordName,
    resVMPasswordName,
    resVMPassphraseName,
    resVMSshKeyPathName,
    resVMHostPasswordName,
    resOKButton,
    resCancelButton,
    resCloseButton,
    resPasswordsDoNotMatch,
    dirty,
    passwordDirty,
    vmpasswordDirty,
    vmpassphraseDirty,
    vmSshKeyPathDirty,
    vmHostPasswordDirty,
    resAttemptConnection,
    resInvalidConnection,
    resNetworkError,
    resPermissionsError,
    isESXi,
    isVCenterManaged,
    isHyperV,
    isNutanix,
    adminInitPasswordValidation,
    vmInitPasswordValidation,
    vmInitPassphraseValidation, 
    vmInitHostPasswordValidation,
    adminInitPasswordDialog,
    vmInitPasswordDialog,
    vmInitPassphraseDialog,
    vmInitHostPasswordDialog,
    pageForm,
    adminResetPasswordForm,
    vmResetPasswordForm, 
    vmResetPassphraseForm,
    vmResetHostPasswordForm,
    adminValidatePasswordForm,
    vmValidatePasswordForm,
    vmValidatePassphraseForm,
    vmValidateHostPasswordForm,
    isClusterPasswordSet,
    isHostPasswordSet,
    isSSHKeyPathSet;

jQuery(document).ready(function() {
    dirty = false;
    passwordDirty = false;
    vmpasswordDirty = false;
    vmpassphraseDirty = false;
    vmSshKeyPathDirty = false;
    vmHostPasswordDirty = false;
    resRequiredFieldValidation = jQuery("#resRequiredFieldValidation").text();
    resRangeLengthValidation = jQuery("#resRangeLengthValidation").text();
    resInvalidCharacters = jQuery("#resInvalidCharacters").text();
    resPassPhraseWhiteSpaceError = jQuery("#resPassPhraseWhiteSpaceError").text();
    resSSHKeyNotFound = jQuery("#resSSHKeyNotFound").text();
    resValidVcenterServerValidation = jQuery("#resValidVcenterServerValidation").text();
    resPasswordDialogTitle = jQuery("#resPasswordDialogTitle").text();
    resVMPasswordDialogTitle = jQuery("#resVMPasswordDialogTitle").text();
    resVMHostPasswordDialogTitle = jQuery("#resVMHostPasswordDialogTitle").text();
    resAdminPasswordName = jQuery("#resAdminPasswordName").text();
    resVMPasswordName = jQuery("#resVMPasswordName").text();
    resVMPassphraseName = jQuery("#resVMSshPassphraseName").text();
    resVMSshKeyPathName = jQuery("#resVMSshKeyPathName").text();
    resVMHostPasswordName = jQuery("#resVMHostPassword").text();
    resOKButton = jQuery("#resOKButton").text();
    resCancelButton = jQuery("#resCancelButton").text();
    resCloseButton = jQuery("#resCloseButton").text();
    resPasswordsDoNotMatch = jQuery("#resPasswordsDoNotMatch").text();
    resRangeValidation = jQuery("#rangeSpan").text();
    resAttemptConnection = jQuery("#attemptConnectionSpan").text();
    resInvalidConnection = jQuery("#invalidConnectionSpan").text();
    resNetworkError = jQuery("#networkErrorSpan").text();
    resPermissionsError = jQuery("#permissionsErrorSpan").text();
    resVMPassphraseDialogTitle = jQuery("#resVMPassphraseDialogTitle").text();
    resPassphrasesDoNotMatch = jQuery("#resPassphrasesDoNotMatch").text();
    pageForm = "#setupcommsform";

    setupAdminChangePasswordParams();
    setupVMChangePasswordParams();

    adminInitPasswordValidation = makeInitPasswordValidation(changeAdminPasswordDialog);
    vmInitPasswordValidation = makeInitPasswordValidation(changeVMPasswordDialog);
    vmInitPassphraseValidation = makeInitPasswordValidation(changeVMPassphraseDialog);
    vmInitHostPasswordValidation = makeInitPasswordValidation(changeVMHostPasswordDialog);

    adminResetPasswordForm = makeResetPasswordForm(changeAdminPasswordDialog.passwordForm, changeAdminPasswordDialog.passwordError);
    vmResetPasswordForm = makeResetPasswordForm(changeVMPasswordDialog.passwordForm, changeVMPasswordDialog.passwordError);
    vmResetPassphraseForm = makeResetPasswordForm(changeVMPassphraseDialog.passwordForm, changeVMPassphraseDialog.passwordError);
    vmResetHostPasswordForm = makeResetPasswordForm(changeVMHostPasswordDialog.passwordForm, changeVMHostPasswordDialog.passwordError);

    adminValidatePasswordForm = makeValidatePasswordForm(changeAdminPasswordDialog.passwordForm);
    vmValidatePasswordForm = makeValidatePasswordForm(changeVMPasswordDialog.passwordForm);
    vmValidatePassphraseForm = makeValidatePasswordForm(changeVMPassphraseDialog.passwordForm);
    vmValidateHostPasswordForm = makeValidatePasswordForm(changeVMHostPasswordDialog.passwordForm);

    adminInitPasswordDialog = makeInitPasswordDialog(changeAdminPasswordDialog, adminResetPasswordForm, adminValidatePasswordForm);
    vmInitPasswordDialog = makeInitPasswordDialog(changeVMPasswordDialog, vmResetPasswordForm, vmValidatePasswordForm);
    vmInitPassphraseDialog = makeInitPasswordDialog(changeVMPassphraseDialog, vmResetPassphraseForm, vmValidatePassphraseForm);
    vmInitHostPasswordDialog = makeInitPasswordDialog(changeVMHostPasswordDialog, vmResetHostPasswordForm, vmValidateHostPasswordForm);

    isESXi = false;
    isVCenterManaged = false;
    isHyperV = false;
    isNutanix = false;

    var prefix = "vcenter_server_";
    if (jQuery("#esxi_host_protocol").length > 0) {
        prefix = "esxi_host_";
        isESXi = true;
    } else if (jQuery("#vcenter_server_protocol").length > 0) {
        prefix = "vcenter_server_";
        isESXi = true;
        isVCenterManaged = true;
    } else if (jQuery("#SCVMMIpName").length > 0) {
        isHyperV = true;
    } else if (jQuery("#nutanix_cluster_ip").length > 0) {
        isNutanix = true;
    }

    if (isNutanix) {
        isClusterPasswordSet = false;
        isHostPasswordSet = false;
        isSSHKeyPathSet = false;
        
        isClusterPasswordSet = ($("#isClusterPasswordSet").length > 0);
        isHostPasswordSet = ($("#isHostPasswordSet").length > 0);
        isSSHKeyPathSet = ($("#isSSHKeyPathSet").length > 0);
    }
    
    blockNavigation(pageForm);
    jQuery("#resetButton").click(function() {

        adminResetPasswordForm();
        vmResetPasswordForm();
        jQuery("#setupcommsform")[0].reset();
        jQuery("#setupcommsform").validate().resetForm();
        
        adminResetPasswordForm();
        jQuery("#" + resAdminPasswordName).remove();
        
        vmResetPasswordForm();
        jQuery("#" + resVMPasswordName).remove();
        
        dirty = false;
        passwordDirty = false;
        vmpasswordDirty = false;

        if (isNutanix) {
            vmResetPassphraseForm();
            jQuery("#" + resVMPassphraseName).remove();
            vmpassphraseDirty = false;

            vmSshKeyPathDirty = false;
            
            vmResetHostPasswordForm();
            jQuery("#" + resVMHostPasswordName).remove();
            vmHostPasswordDirty = false;

            jQuery("#passwordWillBeDeletedWarning").hide();
            jQuery("#SshKeyPathWillBeDeletedWarning").hide();
        }
    });

    jQuery("#checkDetailsButton").click(function() {
        checkDetails();
    });
    
    jQuery("#checkAHVHostDetails").click(function() {
        checkNutanixHostDetails();
    });

    initValidation();
    adminInitPasswordDialog();
    adminInitPasswordValidation();
    jQuery("#changePasswordLink").click(function() {

        jQuery("#" + resAdminPasswordName).remove();
        passwordDirty = false;
        jQuery(changeAdminPasswordDialog.passwordDiv).dialog("open");
        adminResetPasswordForm();
    });

    vmInitPasswordDialog();
    vmInitPasswordValidation();
    jQuery("#vmchangePasswordLink").click(function() {

        jQuery("#" + resVMPasswordName).remove();
        vmpasswordDirty = false;

        if (isNutanix) {
            jQuery("#" + resVMPassphraseName).remove();
            vmpassphraseDirty = false;
            showHideNutanixPasswordWarnings();
        }

        jQuery(changeVMPasswordDialog.passwordDiv).dialog("open");
        vmResetPasswordForm();
    });

    if (isNutanix) {
        vmInitPassphraseDialog();
        vmInitPassphraseValidation();
        jQuery("#vmchangePassphraseLink").click(function() {
            jQuery("#" + resVMPassphraseName).remove();
            vmpassphraseDirty = false;
            jQuery(changeVMPassphraseDialog.passwordDiv).dialog("open");
            vmResetPassphraseForm();
        });

        vmInitHostPasswordDialog();
        vmInitHostPasswordValidation();
        jQuery("#vmchangeHostPasswordLink").click(function() {
            jQuery("#" + resVMHostPasswordName).remove();
            jQuery("#" + resVMPassphraseName).remove();
            vmHostPasswordDirty = false;
            showHideNutanixPasswordWarnings();
            jQuery(changeVMHostPasswordDialog.passwordDiv).dialog("open");
            vmResetHostPasswordForm();
        });
        
        jQuery("#nutanix_ssh_key_path").on("keyup paste", function () {
            vmSshkeyPathDirty = true;
            if (jQuery("#nutanix_ssh_key_path").val() != "") {
                jQuery("#" + resVMPasswordName).remove();
                vmpasswordDirty = false;
                jQuery("#" + resVMHostPasswordName).remove();
                vmHostPasswordDirty = false;
                jQuery("#passwordWillBeDeletedWarning").show();
                jQuery("#SshKeyPathWillBeDeletedWarning").hide();
            } else { 
                jQuery("#passwordWillBeDeletedWarning").hide();
            }
            validateNutanixPasswords();
        });
    }

    jQuery("#" + prefix + "protocol").change(function() {
        setDefaultPort(prefix);
    });

    initWaitDialog();
    initializeCheckboxes();
    window.onbeforeunload = confirmExit;
    validateForm(pageForm);
    if (isESXi) {
        checkVMWareConnection();
    } else if (isHyperV) {
        checkHyperVConnection();
    } else if (isNutanix) {
        checkNutanixConnection();
    }
});

function makeInitPasswordValidation(changePasswordDialog) {
    return function() {
        if (jQuery(changePasswordDialog.passwordForm).length == 0) {
            return;
        }

        makePasswordMatchRule(changePasswordDialog);

        jQuery(changePasswordDialog.passwordForm).validate({
            ignoreTitle : true,
            rules : {
                ignore : [],
                currentPassword : {
                    required : true
                },
                newPassword1 : {
                    required : true,
                    usascii : true,
                    rangelength : [
                            3, 32
                    ]
                },
                vmnewPassword1 : {
                    required : true,
                    usascii : true,
                    rangelength : [
                            3, 32
                    ]
                },
                vmNewHostPassword1 : {
                    required : true,
                    usascii : true,
                    rangelength : [
                            3, 32
                    ]
                },
                newPassword2 : {
                    required : true,
                    adminPasswordMatch : true
                },
                vmnewPassword2 : {
                    required : true,
                    vmPasswordMatch : true
                },
                vmnewPassphrase2 : {
                    vmPassphraseMatch : true
                },
                vmNewHostPassword2 : {
                    required : true,
                    vmHostPasswordMatch : true
                }
                
            },
            messages : {
                vmcurrentPassphrase : {
                    required : resRequiredFieldValidation
                },
                vmcurrentPassword : {
                    required : resRequiredFieldValidation
                },
                newPassword1 : {
                    required : resRequiredFieldValidation,
                    rangelength : resRangeLengthValidation
                },
                vmnewPassword1 : {
                    required : resRequiredFieldValidation,
                    rangelength : resRangeLengthValidation
                },
                vmNewHostPassword1 : {
                    required : resRequiredFieldValidation,
                    rangelength : resRangeLengthValidation
                },
                newPassword2 : {
                    required : resRequiredFieldValidation
                },
                vmnewPassword2 : {
                    required : resRequiredFieldValidation
                },
                vmNewHostPassword2 : {
                    required : resRequiredFieldValidation
                }
            },
            errorPlacement : function(error, element) {

                // display error message after the label-value-pair row
                error.appendTo(element.closest(".labelvaluediv"));
            }
        });
    };
}

function confirmExit() {
    if (dirty || passwordDirty || vmpasswordDirty || vmpassphraseDirty || vmSshKeyPathDirty || vmHostPasswordDirty) {
        return ("");
    }
}

function initValidation() {
    jQuery("#setupcommsform").validate({
        ignore : [],
        ignoreTitle : true,
        rules : {
            vcenter_server_protocol : {
                required : true
            },
            vcenter_server_port : {
                required : true,
                range : [
                        0, 65535
                ]
            },
            vcenter_server_ip : {
                required : true,
                checkValidServerAddress : true
            },
            vcenter_server_username : {
                required : true
            },
            VcenterAuthenticationKey : {
                required : true
            },
            SCVMMIpName : {
                required : true,
                checkValidServerAddress : true
            },
            esxi_host_protocol : {
                required : true
            },
            esxi_host_port : {
                required : true,
                range : [
                        0, 65535
                ]
            },
            esxi_host_ip : {
                required : true,
                checkValidServerAddress : true
            },
            esxi_host_username : {
                required : true
            },
            ESXiAuthenticationKey : {
                required : true
            },
            AuthenticationKeyUserName : {
                required : true,
                validchars : true,
                rangelength : [
                        1, 10
                ]
            },
            MD5PassPhrase : {
                required : true,
                whitespace : true,
                rangelength : [
                        15, 32
                ]
            },
            nutanix_cluster_ip : {
                required : true,
                checkValidServerAddress : true
            },
            nutanix_ssh_key_path : {
                required : function(){
                    var newClusterPasswordToSet = jQuery("#" + resVMPasswordName).length > 0;
                    var newHostPasswordToSet = jQuery("#" + resVMHostPasswordName).length > 0;
                    return !((newHostPasswordToSet && newClusterPasswordToSet)
                            || (isHostPasswordSet && isClusterPasswordSet));    
                },
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    data : {
                        // readable check
                        executable : false,
                        param_name : "nutanix_ssh_key_path",
                        formtoken : jQuery("#formtoken").val(),
                        formtokenid : jQuery("#formtokenid").val()
                    }
                }
            }
        },
        messages : {
            vcenter_server_protocol : {
                required : resRequiredFieldValidation
            },
            vcenter_server_port : {
                required : resRequiredFieldValidation,
                range : resRangeValidation
            },
            vcenter_server_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            vcenter_server_username : {
                required : resRequiredFieldValidation
            },
            VcenterAuthenticationKey : {
                required : resRequiredFieldValidation
            },
            SCVMMIpName : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            esxi_host_protocol : {
                required : resRequiredFieldValidation
            },
            esxi_host_port : {
                required : resRequiredFieldValidation,
                range : resRangeValidation
            },
            esxi_host_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            exsi_host_username : {
                required : resRequiredFieldValidation
            },
            ESXiAuthenticationKey : {
                required : resRequiredFieldValidation
            },
            AuthenticationKeyUserName : {
                required : resRequiredFieldValidation,
                rangelength : resRangeLengthValidation
            },
            MD5PassPhrase : {
                required : resRequiredFieldValidation,
                rangelength : resRangeLengthValidation
            },
            nutanix_cluster_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            nutanix_ssh_key_path : {
                required : resRequiredFieldValidation,
                remote : resSSHKeyNotFound
            }
            
        },
        // errorContainer : jQuery("#errorcontainer"),
        errorPlacement : function(error, element) {

            // display error message after the label-value-pair row
            error.appendTo(element.closest(".labelvaluediv"));
        },
        submitHandler : function(form) {
            // apply button clicked and form validated
            dirty = false;
            passwordDirty = false;
            vmpasswordDirty = false;
            vmpassphraseDirty = false;
            vmSshKeyPathDirty = false;
            vmHostPasswordDirty = false;
            jQuery("#waitDialog").dialog("open");
            form.submit();
        }

    });
    jQuery.validator.addMethod("checkValidServerAddress", function(address, element) {

        var result = isValidServerAddress(address);
        return this.optional(element) || result;
    });
    jQuery.validator.addMethod("validchars", function(value, element) {

        return this.optional(element) || /^[\x20-\x3B\x3D\x3F-\x7E]+$/.test(value);
    }, resInvalidCharacters);
    jQuery.validator.addMethod("usascii", function(value, element) {

        return this.optional(element) || /^[\x20-\x7E]+$/.test(value);
    }, resInvalidCharacters);
    jQuery.validator.addMethod("whitespace", function(value, element) {

        return this.optional(element) || /^\S.*\S$/.test(value);
    }, resPassPhraseWhiteSpaceError);
}

function validateForm(pageForm) {
    if (isNutanix) {
        validateNutanixPasswords();
    }
    if (jQuery(pageForm).validate().form()) {
        jQuery(pageForm).validate().resetForm();
    }
}
function checkDetails() {
    jQuery('#checkDetailscontainer').empty();
    var authKeyUserName = jQuery('#AuthenticationKeyUserName').val();
    var authKey = jQuery('#AuthenticationKey').val();
    var md5PassPhrase = jQuery('#MD5PassPhrase').val();
    var postdata = "AuthenticationKey=" + authKey + "&AuthenticationKeyUserName=" + authKeyUserName + "&MD5PassPhrase=" + md5PassPhrase;
    jQuery("#checkDetailsDialog").dialog("open");
    jQuery.post('/CheckNMCDetails', postdata, function(data) {

        jQuery('#checkDetailscontainer').html(data);
        jQuery("#checkDetailsDialog").dialog("close");

    });
}

function initializeCheckboxes() {
    var webPluginChk = jQuery("#VSphereWebPluginName");
    var legacyPluginChk = jQuery("#VSpherePluginName");
    var webPlugin = webPluginChk.is(':checked');
    var legacyPlugin = legacyPluginChk.is(':checked');

    if (webPlugin == true) {
        legacyPluginChk.attr('disabled', 'disabled');
    } else if (legacyPlugin == true) {
        webPluginChk.attr('disabled', 'disabled');
    } else {
        webPluginChk.removeAttr('disabled');
        legacyPluginChk.removeAttr('disabled');
    }

    legacyPluginChk.on('change', function() {
        var checked = legacyPluginChk.is(":checked");
        if (checked == true) {
            webPluginChk.attr('disabled', 'disabled');
        } else {
            webPluginChk.removeAttr('disabled');
        }
    });

    webPluginChk.on('change', function() {
        var checked = webPluginChk.is(":checked");
        if (checked == true) {
            legacyPluginChk.attr('disabled', 'disabled');
        } else {
            legacyPluginChk.removeAttr('disabled');
        }
    });

}

function checkHyperVConnection() {
    var scvmmIp = jQuery("#SCVMMIpName").val();
    var formtoken = jQuery("#formtoken").val();
    var formtokenid = jQuery("#formtokenid").val();
    var data = {
        SCVMMIpName : scvmmIp,
        "formtoken" : formtoken,
        "formtokenid" : formtokenid
    };

    checkConnection(data);
}

function checkVMWareConnection() {
    var prefix = "vcenter_server_";
    if (jQuery("#esxi_host_ip").length > 0) {
        prefix = "esxi_host_";
    }
    var ipPrefix = prefix + "ip";
    var userPrefix = prefix + "username";
    var passwordPrefix = prefix + "password";
    var protocol = jQuery("#" + prefix + "protocol").prop('selectedIndex');
    var port = jQuery("#" + prefix + "port").val();
    var ip = jQuery("#" + prefix + "ip").val();
    var username = jQuery("#" + prefix + "username").val();
    var password = jQuery("#" + prefix + "password").val();
    var formtoken = jQuery("#formtoken").val();
    var formtokenid = jQuery("#formtokenid").val();
    var data = {
        "protocol" : protocol,
        "port" : port,
        ipPrefix : ip,
        userPrefix : username,
        passwordPrefix : password,
        "formtoken" : formtoken,
        "formtokenid" : formtokenid,
        "main_ui" : true
    };
    checkConnection(data);
}

function showHideWebPluginDiv(webPluginSupported) {
    if (webPluginSupported == false) {
        jQuery("#webplugin").remove();
    } else {
        jQuery("#webplugin").show();
    }
}

function showHideLegacyPluginDiv(legacyPluginSupported) {
    if (legacyPluginSupported == false) {
        jQuery("#legacyplugin").remove();
    } else {
        jQuery("#legacyplugin").show();
    }
}

function setDefaultPort(prefix) {
    var port = jQuery("#" + prefix + "port");
    var protocol = jQuery("#" + prefix + "protocol");
    var portVal = port.val();
    var protocolVal = protocol.val();
    if (protocolVal == "https") {
        if (!portVal || portVal == "80") {
            port.val("443");
        }
    } else {
        if (!portVal || portVal == "443") {
            port.val("80");
        }
    }
}

function validateNutanixPasswords() {
    var newClusterPasswordToSet = jQuery("#" + resVMPasswordName).length > 0;
    var newHostPasswordToSet = jQuery("#" + resVMHostPasswordName).length > 0;
    var isSSHKeyFieldEmpty = jQuery("#nutanix_ssh_key_path").val() === "";
    var error = false;
    
    if (isSSHKeyFieldEmpty || newClusterPasswordToSet || newHostPasswordToSet) {
        
        if (!(newHostPasswordToSet || isHostPasswordSet)) {
             jQuery("#nutanixHostPasswordRequired").show();
             error = true;
             jQuery("#apply").button('option', 'disabled', true);
        } else { 
            jQuery("#nutanixHostPasswordRequired").hide();
        }
        
        if (!(newClusterPasswordToSet || isClusterPasswordSet)) {
            jQuery("#nutanixClusterPasswordRequired").show();
            error = true;
            jQuery("#apply").button('option', 'disabled', true);
        } else {
            jQuery("#nutanixClusterPasswordRequired").hide();
        }
    }
    
    if(!error) {
        jQuery("#apply").button('option', 'disabled', false);
        jQuery("#nutanixHostPasswordRequired").hide();
        jQuery("#nutanixClusterPasswordRequired").hide();
    }
    
}

function checkNutanixHostDetails() {
    jQuery("#checkDetailsDialog").dialog("open");
    jQuery("#checkAHVHostDetailsSuccess").hide();
    jQuery("#checkAHVHostDetailsError").hide();
     
    var formtoken = jQuery("#formtoken").val();
    var formtokenid = jQuery("#formtokenid").val();
    
    var params = {
        "formtoken" : formtoken,
        "formtokenid" : formtokenid
    }
    
    var req = jQuery.ajax({
        url : '/AJAXCheckNutanixHostDetails',
        type : 'POST',
        data : params
    });

    req.success(function(data) {
        jQuery("#checkDetailsDialog").dialog("close");
        jQuery("#checkAHVHostDetailsSuccess").show();
    });

    req.error(function(data) {
        jQuery("#checkDetailsDialog").dialog("close");
        jQuery("#checkAHVHostDetailsError").show();
    });
}