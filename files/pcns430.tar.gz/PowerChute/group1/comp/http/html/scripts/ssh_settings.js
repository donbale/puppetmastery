/*
 * Copyright (c) 2018, Schneider Electric. All Rights Reserved.
 */

var resActionDialogTitle;
var resCloseButton;
var resOKButton;
var resCancelButton;
var resActionNameInUse;
var resRequiredField;
var resRangeValidation;
var resCredentialsGiven;
var resInvalidCommandFile;
var resInvalidSSHKeyFile;
var resReadFailError;
var resCreateFailError;
var resEditFailError;
var resDeleteFailError;
var resInvalidHostError;
var resInvalidCharacters;
var timeout = 10000;
var validator = null;
var dialog = null;

jQuery(document).ready(function() {
    initResourceStrings();
    initActionDialog();
    initActionFormValidation();
    initAddButton();
    initDeleteButtons();
    initEditButtons();
    initWaitDialog();

    updateNoActions();

});

function initAddButton() {
    jQuery("#addActionBtn").button({
        icons : {
            primary : "ui-icon-plusthick"
        }
    }).click(function() {
        jQuery("#actionDialog").dialog("open");
    });
}

function initEditButtons() {
    jQuery("#sshActionItem a.editBtn").button({
        icons : {
            primary : "ui-icon-pencil"
        },
        text : false
    }).click(function(event) {
        var index = jQuery(this).attr("index");
        showEditDialog(index);
    });
}

function initDeleteButtons() {
    jQuery("#sshActionItem a.deleteBtn").button({
        icons : {
            primary : "ui-icon-trash"
        },
        text : false
    }).click(function(event) {
        var index = jQuery(this).attr("index");
        deleteAction(index);
    });
}

function initResourceStrings() {
    resActionDialogTitle = jQuery("#resActionDialogTitle").text();
    resCloseButton = jQuery("#resCloseButton").text();
    resOKButton = jQuery("#resOKButton").text();
    resCancelButton = jQuery("#resCancelButton").text();
    resActionNameInUse = jQuery("#resActionNameInUse").text();
    resRangeValidation = jQuery("#resRangeValidation").text();
    resRequiredField = jQuery("#resRequiredField").text();
    resCredentialsGiven = jQuery("#resCredentialsGiven").text();
    resInvalidCommandFile = jQuery("#resInvalidCommandFile").text();
    resInvalidSSHKeyFile = jQuery("#resInvalidSSHKeyFile").text();
    resReadFailError = jQuery("#resReadFailError").text();
    resCreateFailError = jQuery("#resCreateFailError").text();
    resEditFailError = jQuery("#resEditFailError").text();
    resDeleteFailError = jQuery("#resDeleteFailError").text();
    resInvalidHostError = jQuery("#resInvalidHostError").text();
    resInvalidCharacters = jQuery("#resInvalidCharacters").text();
}

function updateNoActions() {
    if (jQuery("#actionsList li").length > 0) {
        jQuery("#noActionsDiv").hide();
    } else {
        jQuery("#noActionsDiv").show();
    }
}

function onDialogOK() {
    jQuery("#actionDialogForm").submit();
}

function onSubmit() {
    if (jQuery("#actionDialogForm").validate().form()) {
        var index = jQuery("#actionIndex").val();
        if (index >= 0) {
            editAction(index);
        } else {
            createAction();
        }
        resetActionForm();
        updateNoActions();
        jQuery("#actionDialog").dialog("close");
    }
}

function onDialogClose() {
    resetActionForm();
    jQuery("#actionDialog").dialog("close");
}

function initActionDialog() {
    jQuery("#actionDialog").dialog({
        autoOpen : false,
        modal : true,
        width : 570,
        title : resActionDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        beforeClose : function(event, ui) {
            resetActionForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : onDialogOK
                }, {
                    text : resCancelButton,
                    click : onDialogClose
                }
        ]
    });
}

function onRemoteValidation401() {
    // Timeout while trying to validate a file path. Close the dialog and refresh the page to redirect to login.
    jQuery("#actionDialog").dialog("close");
    window.location.reload(true);
}

function initActionFormValidation() {
    jQuery("#password").addClass("credential-group");
    jQuery("#sshKeyPath").addClass("credential-group");

    jQuery.validator.addMethod("checkActionNameInUse", function(value, element) {
        var current = this;
        var index = jQuery("#actionIndex").val();
        var noMatch = true;
        jQuery("#actionsList li .actionName").each(function(i) {
            var thisRef = jQuery(this);
            if ((i != index) && (jQuery.trim(value) === jQuery.trim(thisRef.text()))) {
                noMatch = false;
            }
        });

        return current.optional(element) || noMatch;
    }, resActionNameInUse);
    
    jQuery.validator.addMethod("notBlank", function(value, element){
        var blank = (jQuery.trim(value).length === 0);
        return this.optional(element) || !blank;
    }, resRequiredField);

    jQuery.validator.addMethod("checkValidHostname", function(value, element) {
        return this.optional(element) || isValidServerAddress(value);
    }, resInvalidHostError);

    jQuery.validator.addMethod("validchars", function(value, element) {

        return this.optional(element) || /^[\x20-\x3B\x3D\x3F-\x7E]+$/.test(value);
    }, resInvalidCharacters);

    jQuery.validator.addMethod("usascii", function(value, element) {

        return this.optional(element) || /^[\x20-\x7E]+$/.test(value);
    }, resInvalidCharacters);

    this.validator = jQuery("#actionDialogForm").validate({
        submitHandler : onSubmit,
        rules : {
            actionName : {
                required : true,
                notBlank: true,
                checkActionNameInUse : true,
                validchars : true
            },
            username : {
                required : true,
                notBlank: true,
                validchars : true
            },
            password : {
                required : false,
                usascii : true,
                require_from_group : [
                        1, ".credential-group"
                ]
            },
            sshKeyPath : {
                required : false,
                require_from_group : [
                        1, ".credential-group"
                ],
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    statusCode : {
                        401 : onRemoteValidation401
                    },
                    data : {
                        // readable check
                        executable : false,
                        param_name : "sshKeyPath",
                        formtoken : jQuery("#formtoken").val(),
                        formtokenid : jQuery("#formtokenid").val()
                    }
                }
            },
            sshKeyPassword : {
                required : false,
                usascii : true
            },
            hostAddress : {
                required : true,
                checkValidHostname : true
            },
            port : {
                required : true,
                digits : [
                        0, 65535
                ],
                range : [
                        0, 65535
                ]
            },
            cmdPath : {
                required : true,
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    statusCode : {
                        401 : onRemoteValidation401
                    },
                    data : {
                        // readable check
                        executable : false,
                        param_name : "cmdPath",
                        formtoken : jQuery("#formtoken").val(),
                        formtokenid : jQuery("#formtokenid").val()
                    }
                }
            },
            duration : {
                required : true,
                digits : [
                        0, 172800
                ],
                range : [
                        0, 172800
                ]
            },
            delay : {
                required : true,
                digits : [
                        0, 172800
                ],
                range : [
                        0, 172800
                ]
            },
            sshTrigger : {
                required : true
            },
            enabled : {
                required : true
            }
        },
        messages : {
            actionName : {
                required : resRequiredField,
                notBlank: resRequiredField,
                validchars : resInvalidCharacters,
                checkActionNameInUse : resActionNameInUse
            },
            username : {
                required : resRequiredField,
                notBlank: resRequiredField,
                validchars : resInvalidCharacters
            },
            password : {
                require_from_group : resCredentialsGiven,
                usascii : resInvalidCharacters
            },
            sshKeyPath : {
                remote : resInvalidSSHKeyFile,
                require_from_group : resCredentialsGiven
            },
            sshKeyPassword : {
                usascii : resInvalidCharacters
            },
            hostAddress : {
                required : resRequiredField,
                checkValidHostname : resInvalidHostError
            },
            port : {
                required : resRequiredField,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            cmdPath : {
                required : resRequiredField,
                remote : resInvalidCommandFile
            },
            duration : {
                required : resRequiredField,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            delay : {
                required : resRequiredField,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            sshTrigger : {
                required : resRequiredField
            },
            enabled : {
                required : resRequiredField
            }
        },
        errorPlacement : function(error, element) {
            error.appendTo(element.closest(".labelvaluediv"));
        }
    });
}

function resetActionForm() {
    jQuery("#actionIndex").val(-1);
    jQuery("#actionName").val("");
    jQuery("#username").val("");
    jQuery("#cmdPath").val("");
    jQuery("#hostAddress").val("");
    jQuery("#port").val(22);
    jQuery("#duration").val(120);
    jQuery("#delay").val(0);
    jQuery("#sshTrigger").val("after_host_shutdown")
    jQuery("#enabled").prop('checked', true);
    jQuery("#password").val("");
    jQuery("#sshKeyPath").val("");
    jQuery("#sshKeyPassword").val("");
    this.validator.resetForm();
}

function showEditDialog(index) {
    // Read action value from the server...
    jQuery("#waitDialog").dialog("open");
    var params = {
        action : "read",
        formtoken : jQuery("#formtoken").val(),
        formtokenid : jQuery("#formtokenid").val(),
        index : index
    };

    var req = jQuery.ajax({
        url : '/AJAXSshSettings',
        type : 'POST',
        data : params,
        timeout : timeout
    });

    req.success(function(data, txtStatus, xhr) {
        // Populate the dialog...
        jQuery("#actionIndex").val(data.index);
        jQuery("#actionName").val(data.name);
        jQuery("#username").val(data.username);
        jQuery("#cmdPath").val(data.commandFilePath);
        jQuery("#hostAddress").val(data.host);
        jQuery("#port").val(data.port);
        jQuery("#duration").val(data.duration);
        jQuery("#delay").val(data.delay);
        jQuery("#sshTrigger").val(data.trigger)
        jQuery("#enabled").prop('checked', data.enabled);

        if (data.password) {
            jQuery("#password").val(data.password);
        } else {
            jQuery("#password").val("");
        }

        if (data.sshKeyPath) {
            jQuery("#sshKeyPath").val(data.sshKeyPath);
        } else {
            jQuery("#sshKeyPath").val("");
        }

        if (data.sshKeyPassword) {
            jQuery("#sshKeyPassword").val(data.sshKeyPassword);
        } else {
            jQuery("#sshKeyPassword").val("");
        }

        jQuery("#waitDialog").dialog("close");
        jQuery("#actionDialog").dialog("open");

    });

    req.error(function(data, txtStatus, xhr) {
        if (data.status === 401) {
            onRemoteValidation401();
        } else {
            jQuery("#waitDialog").dialog("close");
            jQuery("#errorcontainer").text(resReadFailError);
            jQuery("#errorcontainer").show();
        }
    });
}

function editAction(index) {
    jQuery("#waitDialog").dialog("open");
    var params = {
        action : "edit",
        formtoken : jQuery("#formtoken").val(),
        formtokenid : jQuery("#formtokenid").val(),
        index : jQuery("#actionIndex").val(),
        name : jQuery("#actionName").val(),
        username : jQuery("#username").val(),
        commandFilePath : jQuery("#cmdPath").val(),
        host : jQuery("#hostAddress").val(),
        password : jQuery("#password").val(),
        sshKeyFile : jQuery("#sshKeyPath").val(),
        sshKeyPassword : jQuery("#sshKeyPassword").val(),
        port : jQuery("#port").val(),
        duration : jQuery("#duration").val(),
        delay : jQuery("#delay").val(),
        trigger : jQuery("#sshTrigger").val(),
        enabled : jQuery("#enabled").is(":checked")
    };

    var req = jQuery.ajax({
        url : '/AJAXSshSettings',
        type : 'POST',
        data : params,
        timeout : timeout
    });

    req.success(function(data, txtStatus, xhr) {
        jQuery("#waitDialog").dialog("close");
        resetActionForm();
        window.location.reload(true);
    });

    req.error(function(data) {
        jQuery("#waitDialog").dialog("close");
        jQuery("#errorcontainer").text(resEditFailError);
        jQuery("#errorcontainer").show();
    });
}

function deleteAction(index) {
    jQuery("#waitDialog").dialog("open");
    var params = {
        action : "delete",
        formtoken : jQuery("#formtoken").val(),
        formtokenid : jQuery("#formtokenid").val(),
        index : index
    };

    var req = jQuery.ajax({
        url : '/AJAXSshSettings',
        type : 'POST',
        data : params,
        timeout : timeout
    });

    req.success(function(data, txtStatus, xhr) {
        jQuery("#waitDialog").dialog("close");
        window.location.reload(true);
    });

    req.error(function(data, txtStatus, xhr) {
        if (data.status === 401) {
            onRemoteValidation401();
        } else {
            jQuery("#waitDialog").dialog("close");
            jQuery("#errorcontainer").text(resDeleteFailError);
            jQuery("#errorcontainer").show();
        }
    });
}

function createAction() {
    jQuery("#waitDialog").dialog("open");
    var params = {
        action : "create",
        formtoken : jQuery("#formtoken").val(),
        formtokenid : jQuery("#formtokenid").val(),
        index : jQuery("#actionIndex").val(),
        name : jQuery("#actionName").val(),
        username : jQuery("#username").val(),
        commandFilePath : jQuery("#cmdPath").val(),
        host : jQuery("#hostAddress").val(),
        password : jQuery("#password").val(),
        sshKeyFile : jQuery("#sshKeyPath").val(),
        sshKeyPassword : jQuery("#sshKeyPassword").val(),
        port : jQuery("#port").val(),
        duration : jQuery("#duration").val(),
        delay : jQuery("#delay").val(),
        trigger : jQuery("#sshTrigger").val(),
        enabled : jQuery("#enabled").is(":checked")
    };

    var req = jQuery.ajax({
        url : '/AJAXSshSettings',
        type : 'POST',
        data : params,
        timeout : timeout
    });

    req.success(function(data, txtStatus, xhr) {
        jQuery("#waitDialog").dialog("close");
        window.location.reload(true);
    });

    req.error(function(data) {
        jQuery("#waitDialog").dialog("close");
        jQuery("#errorcontainer").text(resCreateFailError);
        jQuery("#errorcontainer").show();
    });
}
