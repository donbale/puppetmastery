var eventLogAjaxUpdateId = null;
var eventLogAjaxUpdateErrorCount = 0;
var ajaxLogUrl = "/AJAXLog";
var oTable = null;
var resEventCount, resDisplay, resEventsTitle, resPaginationFirst, resCloseButton, resPaginationNext, resPaginationLast;
var resPaginationPrevious;
var resNoEventsLogged = "";
var MAX_AJAX_RETRIES = 5;
var scrollPos = 0;

jQuery( document ).ready( function () {

    resEventCount = jQuery( "#resEventCount" ).text();
    resDisplay = jQuery( "#resDisplay" ).text();
    resEventsTitle = jQuery( "#resEventsTitle" ).text();
    resPaginationFirst = jQuery( "#resPaginationFirst" ).text();
    resPaginationNext = jQuery( "#resPaginationNext" ).text();
    resPaginationLast = jQuery( "#resPaginationLast" ).text();
    resPaginationPrevious = jQuery( "#resPaginationPrevious" ).text();
    resNoEventsLogged = jQuery( "#resNoEventsLogged" ).text();
    resCloseButton = jQuery( "#resCloseButton" ).text();

    initEventLog();// init datatable
    clearEventLogAjaxUpdate();

    eventLogAjaxUpdateId = setInterval( function () {

        AJAXLog()
    }, 30000 );

    var theYes = jQuery( '#deleteYes' ).text();
    var theNo = jQuery( '#deleteNo' ).text();

    jQuery( "#deleteLogDialog" ).dialog( {
        resizable : false,
        height : 140,
        modal : true,
        autoOpen : false,
        closeText : resCloseButton,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        draggable : false
    } );

    jQuery( "#deleteLogDialog" ).dialog( "option", "buttons", [
            {
                text : theYes,
                click : function () {

                    deleteEventLog();
                    AJAXLog();
                    jQuery( this ).dialog( "close" );
                }
            }, {
                text : theNo,
                click : function () {

                    jQuery( this ).dialog( "close" );
                }
            }
    ] );
} );

function initEventLog () {

    var sScrolly = "400px";
    oTable = jQuery( "#EventLog" ).DataTable(
            {
                "language" : {
                    "infoEmpty" : "",
                    "info" : resEventCount,
                    "zeroRecords" : resNoEventsLogged,
                    "infoFiltered" : "",
                    "lengthMenu" : resDisplay + ' <select>' + '<option value="20">20</option>' +
                            '<option value="50">50</option>' + '<option value="100">100</option>' + '</select> ' +
                            resEventsTitle,
                    "paginate" : {
                        "first" : resPaginationFirst,
                        "next" : resPaginationNext,
                        "last" : resPaginationLast,
                        "previous" : resPaginationPrevious
                    }
                // '</select> events'
                },
                "columnDefs" : [
                        {
                            "columns.ClassName" : "Table_Date",
                            "aTargets" : [
                                0
                            ]
                        }, {
                            "columns.ClassName" : "Table_Time",
                            "aTargets" : [
                                1
                            ]
                        }, {
                            "columns.ClassName" : "Table_Event",
                            "aTargets" : [
                                2
                            ]
                        }
                ],
                "dom" : 'RC<"H"lfrip>t', // Specify exactly where in the DOM you want DataTables to inject the
                                            // various controls: http://datatables.net/usage/options#sDom
                "serverSide" : true,
                "destroy" : true,
                "pageLength" : 20,
                "jQueryUI" : true,
                "ordering" : false,
                "searching" : false,
                "scrollY" : sScrolly,
                "stateSave" : true,
                "paging" : true,
                "pagingType" : "full_numbers",
                "drawCallback" : function ( oSettings ) {

                    jQuery( ".dataTables_scrollBody" ).scrollTop( scrollPos );
                },
                "ajax" : {
                    "dataType" : 'json',
                    "type" : "POST",
                    "dataSrc" : "data",
                    "url" : ajaxLogUrl,
                    "data" : function ( d ) {//POST data

                        return $.extend( {}, d, {
                            "formtoken" : jQuery( "#formtoken" ).val(),
                            "formtokenid" : jQuery( "#formtokenid" ).val()
                        } );
                    },
                    "timeout" : 5000,
                    "error" : function ( data ) {

                        eventLogAjaxUpdateErrorCount++;
                        if ( eventLogAjaxUpdateErrorCount == MAX_AJAX_RETRIES ) {
                            clearEventLogAjaxUpdate();
                        }
                    }
                }
            } );
}

function clearEventLogAjaxUpdate () {

    if ( eventLogAjaxUpdateId != null ) {
        clearInterval( eventLogAjaxUpdateId );
        eventLogAjaxUpdateId = null;
    }
}

//This updates the LogTable section of the screen.
//The entire log is reloaded every time, but as the
//log doesn't get very big, and we do not generally have
//big loads, this is not an issue
function AJAXLog () {

    if ( oTable == null ) {
        return;
    }

    scrollPos = jQuery( ".dataTables_scrollBody" ).scrollTop();
    oTable.ajax.reload( null, false );//false means not to reset the current page
}

function deleteEventLog () {

    var params = {
        formtoken : jQuery( "#formtoken" ).val(),
        formtokenid : jQuery( "#formtokenid" ).val()
    };

    var req = jQuery.ajax( {
        url : '/eventlogdelete',
        type : 'POST',
        data : params,
        timeout : 5000
    } );

    req.success( function ( data ) {

        AJAXLog();
    } );

    req.error( function ( data ) {

        window.location.replace( "/login" );
    } );
}

function ConfirmDelete () {

    jQuery( "#deleteLogDialog" ).dialog( "open" );
}
