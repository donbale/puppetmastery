var dirty;
function confirmExit () {

    if ( dirty ) {
        return ( jQuery( "#blockNavigationWarning" ).text() );
    }
}

function blockNavigation () {

    jQuery( "input, select" ).change( function () {

        dirty = true;
    } );

    jQuery( "#next, #cancel, #previous" ).click( function () {

        dirty = false;
    } );
    window.onbeforeunload = confirmExit;
}

jQuery( document ).ready( function () {

    dirty = false;
    blockNavigation();
} );
