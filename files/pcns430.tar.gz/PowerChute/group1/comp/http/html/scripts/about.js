//This is called on load of the dialoge

//call to the server, and get the java details.

$("#HelpAJAX").load("/about");  //AJAXAbout.java


//This is used for applying JRE via Quick Status.  This is loaded in a dialoge, which
//means the script needs to be in common, because it might be on any page, and the 
//ajax load does not handle script elements from status.jsp
function sendJREUpdatePost(event) { 

    var CONFIRMA = $("#resUpgradeConfirmA").text();
	var CONFIRMB = $("#resUpgradeConfirmB").text();
    var RESTARTING = $("#resUpgradeRestarting").text();
    var CANCELED = $("#resUpgradeCanceled").text();
	
    event.stopImmediatePropagation();  //this should make sure no other events are called.
    event.preventDefault(); 
	
	var jre = document.getElementById('selectJRE').value;
    var r = confirm(CONFIRMA + jre + CONFIRMB );
    if (r == true) {
		
		 $.post("REST/updateJRE",
         {
           updateJRE: jre
         },
         function(data,status){
          setTimeout(function(){location.reload(true);},2*60000)
         })
		 
		 
		 document.body.style.cursor  = 'wait';
		 alert(RESTARTING);
		 window.location.replace("eventlog");
		  
    } else {
        alert(CANCELED);
    }
}