var dirty;

jQuery( document ).ready( function () {

    var activeAcc = parseInt( jQuery( "#activeAcc" ).val(), 10 );
    if ( isNaN( activeAcc ) ) {
        activeAcc = 0;
    }

    dirty = false;
    jQuery( "#applyOutletConfig, #resetOutletConfig" ).click( function ( event ) {

        dirty = false;
    } );

    // Mark the page as dirty if any input changes.
    jQuery( "input, select" ).change( function ( event ) {

        dirty = true;
    } );

    initWaitDialog();

    // show wait dialog on form submit
    jQuery( "#applyPhysicalSettings, #applyOutletConfig" ).click( function ( e ) {

        jQuery( "#waitDialog" ).dialog( "open" );
    } );

    window.onbeforeunload = confirmExit;
} );
