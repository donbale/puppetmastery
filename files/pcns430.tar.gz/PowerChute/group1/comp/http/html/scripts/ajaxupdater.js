var ajaxUpdateId = null;
var ajaxUpdateErrorCount = 0;

//number of retries before we give up...
var MAX_AJAX_RETRIES = 64; 
var btnsEnabled = false;
var ajaxApplyStatusErrorCount = 0;
var ajaxCfgWizUPSConfigErrorCount = 0;
var ajaxApplySOGStatusErrorCount = 0;
var ajaxConnectButtonErrorCount = 0;
var resError = null;

/* clear the ajax update flags and stops the setInterval */
function clearAjaxUpdate () {

    if ( ajaxUpdateId != null ) {
        clearInterval( ajaxUpdateId );
        ajaxUpdateId = null;
    }
}

/* style buttons */
function setButtonStyle () {

    jQuery( '#previous, #next, #cancel' ).button();
    openWaitDialog();
}

function ajaxError ( errorCounter ) {

    if ( errorCounter > MAX_AJAX_RETRIES ) {
        clearAjaxUpdate();
        jQuery( ".CfgWizardBody" ).html(
                "<div class='StatusLogFailure ui-state-error ui-corner-all'>" + resError + "</div>" );
        disable( jQuery( '#previous' ), false );
    }
}

/* callback for AJAXInitConnectUps */
function connectUpsCallback () {

    var status = false;
    var applyReq = jQuery.post( '/AJAXApplyStatus' );
    var cleanReq = null;
    applyReq.success( function ( data ) {

        jQuery( '#ApplyStatus' ).html( data );
        ajaxApplyStatusErrorCount = 0;
        cleanReq = jQuery.post( '/AJAXCfgWizUPSConfig', 'clean=0' );

        cleanReq.success( function ( data ) {

            status = data.status;
            if ( status == true ) { // stop periodical updaters
                clearAjaxUpdate();
            }
            ajaxCfgWizUPSConfigErrorCount = 0;
        } );

        cleanReq.error( function () {

            ajaxCfgWizUPSConfigErrorCount++;
            ajaxError( ajaxCfgWizUPSConfigErrorCount );
        } );
    } );

    applyReq.error( function () {

        ajaxApplyStatusErrorCount++;
        ajaxError( ajaxApplyStatusErrorCount );
    } );
}

/* callback for AJAXInitSetOGButton */
function setOGButtonCallback () {

    var status = false;

    if ( btnsEnabled == true ) {
        clearAjaxUpdate();// clear ajax call after the buttons are enabled
    }

    if ( btnsEnabled == false ) {
        disable( jQuery( '#previous' ), true );
        disable( jQuery( '#next' ), true );
        disable( jQuery( '#cancel' ), true );
    }

    var applyReq = jQuery.post( '/AJAXApplySOGStatus' );
    var cleanReq = null;
    var statusReq = null;

    applyReq.success( function ( data ) {

        jQuery( '#ApplyStatus' ).html( data );
        ajaxApplySOGStatusErrorCount = 0;
        cleanReq = jQuery.post( '/AJAXCfgWizUPSConfig', 'clean=0' );

        cleanReq.success( function ( data ) {

            status = data.status;
            ajaxCfgWizUPSConfigErrorCount = 0;
            if ( status == true ) {
                jQuery( '.StatusLogWarning' ).show(); // show any warning messages
                statusReq = jQuery.post( '/AJAXCfgWizUPSConfig', 'clean=3' );

                statusReq.success( function ( data ) {

                    // enable ogr buttons
                    ajaxCfgWizUPSConfigErrorCount = 0;
                    btnsEnabled = true;
                } );
                statusReq.error( function () {

                    ajaxCfgWizUPSConfigErrorCount++;
                    ajaxError( ajaxCfgWizUPSConfigErrorCount );
                } );
            }
        } );

        cleanReq.error( function ( data ) {

            ajaxCfgWizUPSConfigErrorCount++;
            ajaxError( ajaxCfgWizUPSConfigErrorCount );
        } );
    } );

    applyReq.error( function ( data ) {

        ajaxApplySOGStatusErrorCount++;
        ajaxError( ajaxApplySOGStatusErrorCount );
    } );

    setButtonStyle();
}

/* start AJAXInitConnectUps requests with an interval of 1000 milisecs */
function AJAXInitConnectUps () {

    clearAjaxUpdate();
    blockNavigation();

    disable( jQuery( '#next' ), true );
    disable( jQuery( '#previous' ), true );
    disable( jQuery( '#cancel' ), true );

    resError = jQuery( "#resErrorMessage" ).text();
    var req = jQuery.post( '/AJAXCfgWizUPSConfig', 'clean=1' );

    req.success( function ( data ) {

        ajaxCfgWizUPSConfigErrorCount = 0;
    } );

    req.error( function () {

        ajaxCfgWizUPSConfigErrorCount++;
        ajaxError( ajaxCfgWizUPSConfigErrorCount );
    } );

    setTimeout( "ajaxUpdate('/AJAXConnectButton','html','POST','3000','footerdiv',connectUpsCallback)", 1000 );
    ajaxUpdateId = setInterval( "ajaxUpdate('/AJAXConnectButton','html','POST','3000','footerdiv',connectUpsCallback)",
            3000 );
    jQuery( "#logContainer" ).hide();
    setTimeout( function () {

        initLog();
    }, 1000 );// wait one second to show the log
}

/* start AJAXInitSetOGButton requests with an interval of 1000 milisecs */
function AJAXInitSetOG () {

    clearAjaxUpdate();
    blockNavigation();
    btnsEnabled = false;

    resError = jQuery( "#resErrorMessage" ).text();

    var req = jQuery.post( '/AJAXCfgWizUPSConfig', 'clean=2' );

    req.success( function ( data ) {

        ajaxCfgWizUPSConfigErrorCount = 0;
    } );

    req.error( function () {

        ajaxCfgWizUPSConfigErrorCount++;
        ajaxError( ajaxCfgWizUPSConfigErrorCount );
    } );

    disable( jQuery( '#next' ), true );
    disable( jQuery( '#previous' ), true );
    disable( jQuery( '#cancel' ), true );

    setTimeout( "ajaxUpdate('/AJAXSetOGButton','html','POST','5000','footerdiv',setOGButtonCallback)", 1000 );
    ajaxUpdateId = setInterval( "ajaxUpdate('/AJAXSetOGButton','html','POST','5000','footerdiv',setOGButtonCallback)",
            5000 );
}

/* makes an ajax request using the parameters given */
function ajaxUpdate ( url, dataType, type, timeout, target, callback, errorCounter ) {

    var req = jQuery.ajax( {
        url : url,
        dataType : dataType,
        type : type,
        timeout : timeout
    } );

    req.success( function ( data ) {

        ajaxUpdateErrorCount = 0;
        jQuery( "#" + target ).html( data );
        setButtonStyle();
        if ( callback != null ) // call the callback function if provided
        callback();
    } );

    req.error( function () {

        ajaxUpdateErrorCount++;
        ajaxError( ajaxUpdateErrorCount );
    } );
}

/**
 * shows the connection log and hide button and hides the show log button
 */
function showLog () {

    jQuery( "#connectionLogDiv" ).show();
    jQuery( "#connectionLogDiv" ).empty();
    jQuery.ajax( {
        type : "POST",
        url : "/connectionlog",
        success : function ( data ) {

            jQuery( "#connectionLogDiv" ).html( data );
            jQuery( "#showLog" ).hide();
            jQuery( "#hideLog" ).show();
        }
    } );
}

/**
 * hides the connection log and hide button and shows the show log button
 */
function hideLog () {

    jQuery( "#connectionLogDiv" ).empty();
    jQuery( "#connectionLogDiv" ).hide();
    jQuery( "#hideLog" ).hide();
    jQuery( "#showLog" ).show();
}

/**
 * Initializes the show/hide connection log buttons
 */
function initLog () {

    jQuery( "#logContainer" ).show();
    jQuery( "#hideLog" ).hide();
    jQuery( "#showLog" ).click( function () {

        showLog();
    } );

    jQuery( "#hideLog" ).click( function () {

        hideLog();
    } );
}
