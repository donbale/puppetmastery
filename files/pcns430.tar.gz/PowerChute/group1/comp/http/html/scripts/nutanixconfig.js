var $next, $form, dirty, resRequiredFieldValidation, resValidServerValidation, resAttemptConnection, resNetworkError;
var resInvalidCredentials, resCouldNotLoadKey, connectionError, doServerCheck;

jQuery( document ).ready( function () {

    dirty = false;
    $form = jQuery( "form" );
    $next = jQuery( "#next" );
    doServerCheck = false;
    connectionError = jQuery( "#connectionError" );
    passwordAndKeyWarning = jQuery( "#passwordAndKeyWarning" );
    resRequiredFieldValidation = jQuery( "#requiredSpan" ).text();
    resValidServerValidation = jQuery( "#invalidIpSpan" ).text();
    resAttemptConnection = jQuery( "#attemptConnectionSpan" ).text();
    resInvalidCredentials = jQuery( "#invalidCredentialsSpan" ).text();
    resCouldNotLoadKey = jQuery( "#couldNotLoadKeySpan" ).text();
    resNetworkError = jQuery( "#networkErrorSpan" ).text();
    passwordOrKeyRequiredFieldValidation = jQuery( "#passwordOrKeyRequiredSpan" ).text();

    connectionError.hide();
    passwordAndKeyWarning.hide();

    jQuery( "input" ).on( "keyup paste change", function () {

        connectionError.hide();
        doServerCheck = true;
        validateNutanixForm();
        dirty = true;

        if ( $( "#nutanix_cluster_password" ).val() != "" && $( "#nutanix_ssh_key_path" ).val() != "" ) {
            passwordAndKeyWarning.show();
            $( "#nutanix_cluster_password" ).addClass( "yellowBorder" );
            $( "#nutanix_ssh_key_path" ).addClass( "yellowBorder" );
        }
        else {
            passwordAndKeyWarning.hide();
            $( "#nutanix_cluster_password" ).removeClass( "yellowBorder" );
            $( "#nutanix_ssh_key_path" ).removeClass( "yellowBorder" );
        }
    } );

    $( "#cancel, #previous" ).addClass( "cancel" );

    $( "#cancel, #previous" ).click( function () {

        doServerCheck = false;
        dirty = false;
    } );

    initNutanixValidation();
    validateNutanixForm();
} );

function initNutanixValidation () {

    $form.validate( {
        rules : {
            nutanix_cluster_ip : {
                required : true,
                checkValidServerAddress : resValidServerValidation
            },
            nutanix_cluster_password : {
                required : function ( element ) {
                    return jQuery( "#nutanix_ssh_key_path" ).val() === "";
                }
            },
            nutanix_ssh_key_path : {
                required : function ( element ) {
                    return jQuery( "#nutanix_cluster_password" ).val() === "";
                }
            },
            nutanix_ssh_key_passphrase : {
                required : false
            }
        },
        messages : {
            nutanix_cluster_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            nutanix_cluster_username : {
                required : resRequiredFieldValidation
            },
            nutanix_cluster_password : {
                required : passwordOrKeyRequiredFieldValidation
            },
            nutanix_ssh_key_path : {
                required : passwordOrKeyRequiredFieldValidation
            }
        },
        groups : {
            authMethod : "nutanix_cluster_password nutanix_ssh_key_path"
        },
        errorPlacement : function ( error, element ) {

            // If the error is related to the password or key path append after key path
            if ( $( element ).attr( 'id' ) === "nutanix_cluster_password" ||
                    $( element ).attr( 'id' ) === "nutanix_ssh_key_path" ) {
                error.appendTo( $( "#nutanix_ssh_key_path" ).closest( ".labelvaluediv" ) );
            }
            else {
                // display error message after the label-value-pair row
                error.appendTo( element.closest( ".labelvaluediv" ) );
            }
        },
        invalidHandler : function ( event, validator ) {

            // needed for handling remote validation error
            jQuery( "#next" ).button( 'option', 'disabled', true );
        },
        submitHandler : function ( form ) {

            if ( doServerCheck == true ) {
                // only for next
                checkServerAvailability( function ( result ) {

                    if ( result != null && result.isValid == 1 ) {
                        dirty = false;
                        window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                        doServerCheck = false;
                        $form.submit();
                    }
                } );
            }
            else {
                dirty = false;
                window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                form.submit();
            }
        },
    } );

    jQuery.validator.addMethod( "checkValidServerAddress", function ( address, element ) {

        var result = isValidServerAddress( address );
        // Only enable next button if there are no other fields on invalid
        // state
        if ( result == true && $form.validate().numberOfInvalids() == 0 ) {
            $next.button( 'option', 'disabled', false );
        }
        else {
            $next.button( 'option', 'disabled', true );
        }
        return this.optional( element ) || result;
    } );

    jQuery.validator.addMethod( "checkPwdSet", function ( value, element ) {

        if ( $( "#nutanix_cluster_password" ).val() != "" ) {
            return true;
        }
        return false;
    } );
}

function updateButtons () {

    if ( $form.validate().numberOfInvalids() > 0 ) {
        $next.button( 'option', 'disabled', true );
    }
    else {
        $next.button( 'option', 'disabled', false );
    }
}

function validateNutanixForm () {

    if ( $form.validate().form() ) {
        $form.validate().resetForm();
    }

    updateButtons();
}

// cfgwizard.js override to prevent Next button enabled with validation errors
function initValidation () {

    // This does the cookies check
    loginOnLoad();
}

function checkServerAvailability ( callback ) {

    connectionError.hide();

    var req = jQuery.post( "/AJAXCheckHostConnection", $form.serialize() );

    req.success( function ( result ) {

        if ( result == null || result.isValid == 0 ) {
            connectionError.text( resInvalidCredentials );
            connectionError.show();
            jQuery( "#waitDialog" ).dialog( "close" );
        }
        else if ( result.isValid == -1 ) {
            connectionError.text( resNetworkError );
            connectionError.show();
            jQuery( "#waitDialog" ).dialog( "close" );
        }
        else if ( result.isValid == -2 ) {
            connectionError.text( resCouldNotLoadKey );
            connectionError.show();
            jQuery( "#waitDialog" ).dialog( "close" );
        }
        else {
            setTimeout( function () {

                jQuery( "#waitDialog" ).dialog( "close" );
            }, 2000 );
        }

        callback( result );
    } );

    req.error( function ( data ) {

        connectionError.show();
        jQuery( "#waitDialog" ).dialog( "close" );
        return callback( false );
    } );
}
