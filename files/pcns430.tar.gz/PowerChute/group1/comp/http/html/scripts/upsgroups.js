var dirty, groupsDirty, resRequiredField, resInvalidPort, resOKButton, resCancelButton, resCloseButton;
var resUPSGroupDialogTitle, resUPSGroupNameInUse, resUPSGroupNameUSASCII, resIPDialogTitle, resInvalidIPAddress;
var resIPInUse;
var ipv4AddressRegEx = new RegExp(
        "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$" );
var ipv6AddressRegEx = new RegExp(
        "^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:)))(%.+)?\s*$" );
var removeGroup = null;
var resYesButton, resNoButton, upsConfigMode, max_ip;
var MODE_SINGLE = 1;
var MODE_REDUNDANT = 2;
var MODE_PARALLEL = 3;
var MODE_ADVANCED = 5;
var MAX_IP_REDUNDANT = 4;
var MAX_IP_PARALLEL = 9;

jQuery( document ).ready( function () {

    dirty = false;
    groupsDirty = false;
    upsConfigMode = jQuery( "#mode" ).text();

    if ( MODE_SINGLE == upsConfigMode && jQuery( "#ipv6" ).length > 0 ) {
        jQuery( "#upsip" ).width( 256 );
    }

    max_ip = MAX_IP_PARALLEL;
    if ( MODE_REDUNDANT == upsConfigMode ) {
        max_ip = MAX_IP_REDUNDANT;
    }

    jQuery( "input, select" ).change( function () {

        dirty = true;
    } );

    jQuery( "input, select" ).on( 'paste', function () {

        dirty = true;
    } );

    showHideAcceptCerts();
    setDefaultPort();
    jQuery( "#Protocol" ).change( function () {

        showHideAcceptCerts();
        setDefaultPort();
        validateGroupsForm();
    } );

    bindIPInputChange();
    if ( MODE_ADVANCED == upsConfigMode ) {
        bindGroupNameInputKeyPressAndChange();

        jQuery( "#singleupsradio" ).click( function () {

            switchToSingleUPS();
            updateNoIPError();
        } );

        jQuery( "#upsgroupradio" ).click( function () {

            updateNoIPError();
        } );
    }

    jQuery( "#previous" ).addClass( "cancel" );
    jQuery( "#cancel" ).addClass( "cancel" ).click( function ( event ) {

        jQuery( "#CfgWizardForm" )[ 0 ].reset();
        jQuery( "#CfgWizardForm" ).validate().resetForm();
        dirty = false;
        groupsDirty = false;
    } );

    initResourceStrings();
    initGroupsFormValidation();

    if ( MODE_ADVANCED == upsConfigMode ) {
        initUPSGroupsList();
        initUPSGroupDialog();
        initUPSGroupValidation();
    }

    if ( MODE_SINGLE != upsConfigMode ) {
        // IP List only for redundant/parallel/advanced
        initUPSIPList();
        initIPDialog();
        initIPValidation();
    }

    validateGroupsForm();
    if ( MODE_ADVANCED == upsConfigMode ) {
        updateNoGroupError();
        initDeleteGroupDialog();
    }

    if ( MODE_REDUNDANT == upsConfigMode || MODE_PARALLEL == upsConfigMode ) {
        updateNoIPError();
    }

    window.onbeforeunload = confirmExit;
} );

function showHideAcceptCerts () {

    if ( jQuery( "#Protocol" ).val() == "https" ) {
        jQuery( "#acceptcertsdiv" ).show();
    }
    else {
        jQuery( "#acceptcertsdiv" ).hide();
    }
}

function setDefaultPort () {

    var portVal = jQuery( "#Port" ).val();
    var protocolVal = jQuery( "#Protocol" ).val();
    if ( protocolVal == "https" ) {
        if ( !portVal || portVal == "80" ) {
            jQuery( "#Port" ).val( "443" );
        }
    }
    else {
        if ( !portVal || portVal == "443" ) {
            jQuery( "#Port" ).val( "80" );
        }
    }
}

function bindGroupNameInputKeyPressAndChange () {

    jQuery( "#upsGroupName" ).keypress( function ( event ) {

        var code = event.which;
        if ( code == 124 ) {
            event.preventDefault();
        }
    } ).bind( 'cut paste', function ( event ) {

        var pattern = new RegExp( '[|]+', 'g' ), input = jQuery( this ), value;
        setTimeout( function () {

            value = input.val();
            value = value.replace( pattern, '' );
            input.val( value );
        }, 100 );
    } );
}

function bindIPInputChange () {

    jQuery( "#upsip" ).bind( 'cut paste', function ( event ) {

        var parentForm = jQuery( this ).parents( "form" ).first();
        setTimeout( function () {

            parentForm.validate().form();
            updateButtons();
        }, 100 );
    } );
}

function initResourceStrings () {

    resRequiredField = jQuery( "#resRequiredField" ).text();
    resInvalidPort = jQuery( "#resInvalidPort" ).text();
    resOKButton = jQuery( "#resOKButton" ).text();
    resCancelButton = jQuery( "#resCancelButton" ).text();
    resCloseButton = jQuery( "#resCloseButton" ).text();
    resUPSGroupDialogTitle = jQuery( "#resUPSGroupDialogTitle" ).text();
    resUPSGroupNameInUse = jQuery( "#resUPSGroupNameInUse" ).text();
    resUPSGroupNameUSASCII = jQuery( "#resUPSGroupNameUSASCII" ).text();
    resIPDialogTitle = jQuery( "#resIPDialogTitle" ).text();
    resInvalidIPAddress = jQuery( "#resInvalidIPAddress" ).text();
    resIPInUse = jQuery( "#resIPInUse" ).text();
    resYesButton = jQuery( "#resYesButton" ).text();
    resNoButton = jQuery( "#resNoButton" ).text();
}

function initGroupsFormValidation () {

    jQuery.validator.addMethod( "checkValidPort", function ( value, element ) {

        var defaultPort = 80;
        if ( jQuery( "#Protocol" ).val() == "https" ) {
            defaultPort = 443;
        }

        return this.optional( element ) || ( value == defaultPort ) || ( ( value >= 5000 ) && ( value <= 32768 ) );
    }, resInvalidPort );

    if ( jQuery( "#ipv6" ).length > 0 ) {
        jQuery.validator.addMethod( "IPChecker", function ( value, element ) {

            return this.optional( element ) || ipv6AddressRegEx.test( value );
        }, resInvalidIPAddress );
    }
    else {
        jQuery.validator.addMethod( "IPChecker", function ( value, element ) {

            return this.optional( element ) || ipv4AddressRegEx.test( value );
        }, resInvalidIPAddress );
    }

    jQuery( "#CfgWizardForm" ).validate( {
        // ignore : [],
        rules : {
            Port : {
                required : true,
                digits : true,
                checkValidPort : true
            },
            upsip : {
                required : true,
                IPChecker : true
            }
        },
        messages : {
            Port : {
                required : resRequiredField,
                digits : resInvalidPort
            },
            upsip : {
                required : resRequiredField
            }
        },
        onkeyup : function ( element ) {

            jQuery( element ).valid();
            updateButtons();
        },
        onfocusout : function ( element ) {

            jQuery( element ).valid();
            updateButtons();
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            if ( MODE_ADVANCED == upsConfigMode ) {
                var groupsList = jQuery( "#upsGroupsList li" );
                if ( groupsList.length == 0 ) {
                    createHiddenInputField( 0, "upsgroup", "" );
                }
                else {
                    groupsList.each( function ( i ) {

                        var thisRef = jQuery( this );
                        var value = thisRef.children( ".upsGroupName" ).text();
                        value += "|";
                        value += thisRef.children( ".upsList" ).text();
                        createHiddenInputField( i, "upsgroup", value );
                    } );
                }
            }
            else if ( MODE_REDUNDANT == upsConfigMode || MODE_PARALLEL == upsConfigMode ) {
                createHiddenInputField( "", "upsip", createUPSListString() );
            }

            dirty = false;
            groupsDirty = false;
            window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
            form.submit();
        }
    } );
}

function updateNoGroupError () {

    if ( jQuery( "#upsGroupsList li" ).length > 0 ) {
        jQuery( "#nogroupsdiv" ).hide();
    }
    else {
        jQuery( "#nogroupsdiv" ).show();
    }

    updateButtons();
}

function updateNoIPError () {

    var numIP = jQuery( "#upsList li" ).length;
    if ( numIP > 0 ) {
        jQuery( "#noipdiv" ).hide();
        if ( MODE_ADVANCED == upsConfigMode ) {
            if ( jQuery( "#upsgroupradio" ).is( ":checked" ) ) {
                jQuery( "#addUPSBtn" ).button( 'option', 'disabled', false );
                if ( numIP > 1 ) {
                    jQuery( "#minipdiv" ).hide();
                }
                else {
                    jQuery( "#minipdiv" ).show();
                }
            }
            else {
                jQuery( "#minipdiv" ).hide();
                jQuery( "#addUPSBtn" ).button( 'option', 'disabled', true );
            }
        }
        else {
            if ( numIP > 1 ) {
                jQuery( "#minipdiv" ).hide();
                if ( numIP < max_ip ) {
                    jQuery( "#addUPSBtn" ).button( 'option', 'disabled', false );
                }
                else {
                    jQuery( "#addUPSBtn" ).button( 'option', 'disabled', true );
                }
            }
            else {
                jQuery( "#minipdiv" ).show();
            }
        }
    }
    else {
        jQuery( "#noipdiv" ).show();
        jQuery( "#minipdiv" ).hide();
        jQuery( "#addUPSBtn" ).button( 'option', 'disabled', false );
    }

    if ( MODE_ADVANCED != upsConfigMode ) {
        updateButtons();
    }
}

function updateButtons () {

    var validGroups = true, $next = jQuery( "#next" );
    if ( MODE_ADVANCED == upsConfigMode ) {
        validGroups = jQuery( "#upsGroupsList li" ).length > 0;
    }
    else if ( MODE_REDUNDANT == upsConfigMode || MODE_PARALLEL == upsConfigMode ) {
        validGroups = jQuery( "#upsList li" ).length > 1;
    }

    if ( jQuery( "#CfgWizardForm" ).valid() && validGroups ) {
        $next.button( 'option', 'disabled', false );
    }
    else {
        $next.button( 'option', 'disabled', true );
    }
}

function validateGroupsForm () {

    var formValid = jQuery( "#CfgWizardForm" ).validate().form();
    if ( MODE_REDUNDANT == upsConfigMode || MODE_PARALLEL == upsConfigMode ) {
        formValid = formValid && jQuery( "#upsList li" ).length > 1;
    }

    updateButtons();
    return formValid;
}

function initUPSGroupsList () {

    jQuery( "#upsGroupsList" ).sortable( {
        axis : "y",
        containment : "parent",
        items : "> li",
        cursor : "move",
        cursorAt : {
            top : 14
        }
    } );

    jQuery( "#addGroupBtn" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).click( function () {

        updateNoIPError();
        jQuery( "#upsGroupDialog" ).dialog( "open" );
    } );

    updateRemoveBtn( jQuery( "#upsGroupsList a.deleteBtn" ) );
    updateEditBtn( jQuery( "#upsGroupsList a.editBtn" ) );
}

function initUPSIPList () {

    jQuery( "#upsList" ).sortable( {
        axis : "y",
        containment : "parent",
        items : "> li",
        cursor : "move",
        cursorAt : {
            top : 14
        }
    } );

    jQuery( "#addUPSBtn" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).click( function () {

        jQuery( "#IPDialog" ).dialog( "open" );
    } );

    updateRemoveBtn( jQuery( "#upsList a.deleteBtn" ) );
    updateEditBtn( jQuery( "#upsList a.editBtn" ) );
}

function initUPSGroupDialog () {

    jQuery( "#upsGroupDialog" ).dialog( {
        autoOpen : false,
        modal : true,
        width : 514,
        title : resUPSGroupDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        beforeClose : function ( event, ui ) {

            resetUPSGroupForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : function () {

                        if ( validateUPSGroupForm() ) {
                            var theDialog = jQuery( this );
                            var index = jQuery( "#upsGroupIndex" ).val();
                            if ( index >= 0 ) {
                                updateUPSGroup( index );
                            }
                            else {
                                createUPSGroup();
                            }

                            groupsDirty = true;
                            updateNoGroupError();
                            theDialog.dialog( "close" );
                        }
                    }
                }, {
                    text : resCancelButton,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );
}

function initIPDialog () {

    jQuery( "#IPDialog" ).dialog( {
        autoOpen : false,
        modal : true,
        width : 514,
        title : resIPDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        beforeClose : function ( event, ui ) {

            resetIPForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : function () {

                        if ( validateIPForm() ) {
                            var theDialog = jQuery( this );
                            var index = jQuery( "#IPIndex" ).val();
                            if ( index >= 0 ) {
                                updateIP( index );
                            }
                            else {
                                createIP();
                            }

                            updateNoIPError();
                            updateRemoveBtn( jQuery( "#upsList li:last a.deleteBtn" ) );
                            updateEditBtn( jQuery( "#upsList li:last a.editBtn" ) );
                            theDialog.dialog( "close" );
                            if ( MODE_ADVANCED != upsConfigMode ) {
                                groupsDirty = true;
                            }
                        }
                    }
                }, {
                    text : resCancelButton,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );
}

function initUPSGroupValidation () {

    jQuery.validator.addMethod( "usascii", function ( value, element ) {

        return this.optional( element ) || /^[\x20-\x7B\x7D\x7E]+$/.test( value );
    }, resUPSGroupNameUSASCII );

    jQuery.validator.addMethod( "checkUPSGroupNameInUse", function ( value, element ) {

        var current = this;
        var index = jQuery( "#upsGroupIndex" ).val();
        var groupName = jQuery.trim( value );
        var noMatch = true;
        jQuery( "#upsGroupsList li .upsGroupName" ).each( function ( i ) {

            var thisRef = jQuery( this );
            if ( i != index ) {
                if ( value === thisRef.text() ) {
                    noMatch = false;
                }
            }
        } );

        return current.optional( element ) || noMatch;
    }, resUPSGroupNameInUse );

    jQuery( "#upsGroupForm" ).validate( {
        // ignore : [],
        rules : {
            upsGroupName : {
                required : true,
                usascii : true,
                checkUPSGroupNameInUse : true
            }
        },
        messages : {
            upsGroupName : {
                required : resRequiredField
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );
}

function validateUPSGroupForm () {

    var formValid = jQuery( "#upsGroupForm" ).validate().form(), numIP = jQuery( "#upsList li" ).length, ipsAdded;
    ipsAdded = numIP > 0;
    if ( jQuery( "#upsgroupradio" ).is( ":checked" ) ) {
        ipsAdded = numIP > 1;
    }

    return formValid && ipsAdded;
}

function resetUPSGroupForm () {

    jQuery( "#upsGroupForm" )[ 0 ].reset();
    jQuery( "#upsGroupForm" ).validate().resetForm();
    jQuery( "#upsGroupIndex" ).val( "-1" );
    jQuery( "#upsList" ).empty();
    jQuery( "#singleupsradio" ).prop( "checked", true );
}

function editUPSGroup ( li ) {

    var groupName = li.children( ".upsGroupName" ).text(), index = jQuery( "#upsGroupsList li" ).index( li ), upsListText = jQuery
            .trim( li.children( ".upsList" ).text() ), upsListArr;

    jQuery( "#upsGroupIndex" ).val( index );
    jQuery( "#upsGroupName" ).val( groupName );
    if ( upsListText.length > 0 ) {
        upsListArr = upsListText.split( "|" );
        jQuery.each( upsListArr, function ( i, value ) {

            createIPHTML( value );
        } );

        if ( upsListArr.length > 1 ) {
            jQuery( "#upsgroupradio" ).prop( "checked", true );
        }
        else {
            jQuery( "#singleupsradio" ).prop( "checked", true );
        }
    }

    updateNoIPError();
    jQuery( "#upsGroupDialog" ).dialog( "open" );
}

function checkIPInUse ( ip ) {

    var groupIndex = jQuery( "#upsGroupIndex" ).val(), upsIndex = jQuery( "#IPIndex" ).val(), upsListText = "", inUse = false, upsListArr;

    jQuery( "#upsList li .upsIP" ).each( function ( i ) {

        if ( i != upsIndex ) {
            if ( jQuery.trim( jQuery( this ).text().toLowerCase() ) == ip ) {
                inUse = true;
                return false;
            }
        }
    } );

    if ( !inUse && MODE_ADVANCED == upsConfigMode ) {
        jQuery( "#upsGroupsList li .upsList" ).each( function ( i ) {

            if ( i != groupIndex ) {
                if ( upsListText.length > 0 ) {
                    upsListText += "|";
                }

                upsListText += jQuery.trim( jQuery( this ).text() );
            }
        } );

        upsListArr = upsListText.split( "|" );
        jQuery.each( upsListArr, function ( i, value ) {

            if ( value.toLowerCase() == ip ) {
                inUse = true;
                return false;
            }
        } );
    }

    return inUse;
}

function updateUPSGroup ( index ) {

    var groupName = jQuery.trim( jQuery( "#upsGroupName" ).val() );
    jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsGroupName" ).text( groupName );

    var numIP = jQuery( "#upsList li" ).length;
    if ( numIP > 1 ) {
        jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsGroupName" ).removeClass( "UPSSetupSingle" );
        jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsGroupName" ).addClass( "UPSSetupGroup" );
    }
    else {
        jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsGroupName" ).removeClass( "UPSSetupGroup" );
        jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsGroupName" ).addClass( "UPSSetupSingle" );
    }

    jQuery( "#upsGroupsList li" ).eq( index ).children( ".upsList" ).text( createUPSListString() );
}

function createUPSGroup () {

    var groupName = jQuery.trim( jQuery( "#upsGroupName" ).val() );
    var numIP = jQuery( "#upsList li" ).length;

    var groupItemClass;
    if ( numIP > 1 ) {
        groupItemClass = "UPSSetupGroup";
    }
    else {
        groupItemClass = "UPSSetupSingle";
    }

    var html = "<li class=\"upsGroupItem ui-widget-content ui-corner-all\"> <span class=\"upsGroupName " +
            groupItemClass + "\"></span>" +
            "<a href=\"#\" class=\"editBtn\"></a><a href=\"#\" class=\"deleteBtn\"></a><span class=\"upsList\"></span></li>";
    jQuery( "#upsGroupsList" ).append( html );
    jQuery( "#upsGroupsList li .upsGroupName" ).last().text( groupName );
    jQuery( "#upsGroupsList li .upsList" ).last().text( createUPSListString() );
    updateRemoveBtn( jQuery( "#upsGroupsList li:last a.deleteBtn" ) );
    updateEditBtn( jQuery( "#upsGroupsList li:last a.editBtn" ) );
}

function createUPSListString () {

    var result = "";
    jQuery( "#upsList li .upsIP" ).each( function ( i ) {

        if ( result.length > 0 ) {
            result += "|";
        }

        result += jQuery( this ).text();
    } );

    return result;
}

function switchToSingleUPS () {

    jQuery( "#upsList li:first" ).nextAll( "li" ).remove();
}

function initIPValidation () {

    jQuery.validator.addMethod( "IPInUse", function ( value, element ) {

        return this.optional( element ) || !checkIPInUse( value.toLowerCase() );
    }, resIPInUse );

    jQuery( "#IPForm" ).validate( {
        // ignore : [],
        rules : {
            upsip : {
                required : true,
                IPChecker : true,
                IPInUse : true
            }
        },
        messages : {
            upsip : {
                required : resRequiredField
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );
}

function validateIPForm () {

    return jQuery( "#IPForm" ).validate().form();
}

function resetIPForm () {

    jQuery( "#IPForm" )[ 0 ].reset();
    jQuery( "#IPForm" ).validate().resetForm();
    jQuery( "#IPIndex" ).val( "-1" );
}

function editIP ( li ) {

    var ip = li.children( ".upsIP" ).text();
    var index = jQuery( "#upsList li" ).index( li );
    jQuery( "#IPIndex" ).val( index );
    jQuery( "#upsip" ).val( ip );
    jQuery( "#IPDialog" ).dialog( "open" );
}

function updateIP ( index ) {

    var ip = jQuery.trim( jQuery( "#upsip" ).val() );
    jQuery( "#upsList li" ).eq( index ).children( ".upsIP" ).text( ip );
}

function createIP () {

    var ip = jQuery.trim( jQuery( "#upsip" ).val() );
    createIPHTML( ip );
}

function createIPHTML ( ip ) {

    var html = "<li class=\"upsItem ui-widget-content ui-corner-all\"><span class=\"upsIP\"></span>"
            + "<a href=\"#\" class=\"editBtn\"></a><a href=\"#\" class=\"deleteBtn\"></a></li>";

    jQuery( "#upsList" ).append( html );
    jQuery( "#upsList li .upsIP" ).last().text( ip );
    updateRemoveBtn( jQuery( "#upsList li:last a.deleteBtn" ) );
    updateEditBtn( jQuery( "#upsList li:last a.editBtn" ) );
}

function updateRemoveBtn ( removeBtn ) {

    removeBtn.button( {
        icons : {
            primary : "ui-icon-trash"
        },
        text : false
    } ).click( function ( event ) {

        var parent = jQuery( this ).parent( "li" ), isUPSGroup = parent.hasClass( "upsGroupItem" );
        if ( isUPSGroup ) {
            removeGroup = parent;
            jQuery( '#deleteGroupDialog' ).dialog( "open" );
        }
        else {
            parent.remove();
            updateNoIPError();
        }
    } );
}

function updateEditBtn ( editBtn ) {

    editBtn.button( {
        icons : {
            primary : "ui-icon-pencil"
        },
        text : false
    } ).click( function ( event ) {

        var parent = jQuery( this ).parent( "li" );
        if ( parent.hasClass( "upsItem" ) ) {
            editIP( parent );
        }
        else {
            editUPSGroup( parent );
        }
    } );
}

function createHiddenInputField ( index, name, value ) {

    var id = name + index;
    var html = '<input type="hidden" name="' + name + '" value="" id="' + id + '"/>';
    jQuery( "#CfgWizardForm" ).append( html );
    jQuery( "#" + id ).val( value );
}

// cfgwizard.js override to prevent Next button enabled with validation errors
function initValidation () {

    // This does the cookies check
    loginOnLoad();
}

function initDeleteGroupDialog () {

    jQuery( "#deleteGroupDialog" ).dialog( {
        resizable : false,
        height : 140,
        closeText : resCloseButton,
        modal : true,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        autoOpen : false,
        draggable : false
    } );

    jQuery( "#deleteGroupDialog" ).dialog( "option", "buttons", [
            {
                text : resYesButton,
                click : function () {

                    if ( removeGroup != null ) {
                        removeGroup.remove();
                        groupsDirty = true;
                        removeGroup = null;
                        updateNoGroupError();
                    }
                    jQuery( this ).dialog( "close" );
                }
            }, {
                text : resNoButton,
                click : function () {

                    jQuery( this ).dialog( "close" );
                }
            }
    ] );
}
