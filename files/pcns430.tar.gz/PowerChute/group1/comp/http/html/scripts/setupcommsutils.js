var changeAdminPasswordDialog,
    changeVMPasswordDialog,
    changeVMPassphraseDialog,
    changeVMSshKeyPathDialog;

function setupAdminChangePasswordParams() {

    changeAdminPasswordDialog = {
        passwordDiv : "#passwordDiv",
        passwordForm : "#passwordForm",
        passwordDialogTitle : resPasswordDialogTitle,
        passwordError : "#pwerror",
        passwordName : resAdminPasswordName,
        ajaxURL : '/checkaccess',
        passwordMatchRuleName : "adminPasswordMatch",
        passwordsDoNotMatch : resPasswordsDoNotMatch,
        currentPassword : "#currentPassword",
        theNewPassword1 : "#newPassword1",
        theNewPassword2 : "#newPassword2"
    };
}

function setupVMChangePasswordParams() {

    changeVMPasswordDialog = {
        passwordDiv : "#vmpasswordDiv",
        passwordForm : "#vmpasswordForm",
        passwordDialogTitle : resVMPasswordDialogTitle,
        passwordError : "#vmpwerror",
        passwordName : resVMPasswordName,
        ajaxURL : '/checkvmaccess',
        passwordMatchRuleName : "vmPasswordMatch",
        passwordsDoNotMatch : resPasswordsDoNotMatch,
        currentPassword : "#vmcurrentPassword",
        theNewPassword1 : "#vmnewPassword1",
        theNewPassword2 : "#vmnewPassword2"
    };

    changeVMHostPasswordDialog = {
        passwordDiv : "#vmHostPasswordDiv",
        passwordForm : "#vmHostPasswordForm",
        passwordDialogTitle : resVMHostPasswordDialogTitle,
        passwordError : "#vmhostpwerror",
        passwordName : resVMHostPasswordName,
        ajaxURL : '/checkvmaccess',
        passwordMatchRuleName : "vmHostPasswordMatch",
        passwordsDoNotMatch : resPasswordsDoNotMatch,
        currentPassword : "#vmCurrentHostPassword",
        theNewPassword1 : "#vmNewHostPassword1",
        theNewPassword2 : "#vmNewHostPassword2",
    }

    changeVMPassphraseDialog = {
        passwordDiv : "#vmpassphraseDiv",
        passwordForm : "#vmpassphraseForm",
        passwordDialogTitle : resVMPassphraseDialogTitle,
        passwordError : "#vmpassphraseerror",
        passwordName : resVMPassphraseName,
        ajaxURL : '/checkvmaccess',
        passwordMatchRuleName : "vmPassphraseMatch",
        passwordsDoNotMatch : resPassphrasesDoNotMatch,
        currentPassword : "#vmcurrentPassphrase",
        theNewPassword1 : "#vmnewPassphrase1",
        theNewPassword2 : "#vmnewPassphrase2",
    }
}

function makeInitPasswordDialog(changePasswordDialog, resetPasswordForm, validatePasswordForm) {

    return function() {

        jQuery(changePasswordDialog.passwordDiv).dialog({
            autoOpen : false,
            modal : true,
            width : 512,
            title : changePasswordDialog.passwordDialogTitle,
            closeText : resCloseButton,
            draggable : false,
            resizable : false,
            position : {
                my : "center",
                at : "center",
                of : "#container"
            },
            beforeClose : function(event, ui) {

                resetPasswordForm();
            },
            buttons : [
                    {
                        text : resOKButton,
                        click : function() {

                            jQuery(changePasswordDialog.passwordError).hide();
                            if (validatePasswordForm()) {
                                var theDialog = jQuery(this);
                                var params = {
                                    formtoken : jQuery("#formtoken").val(),
                                    formtokenid : jQuery("#formtokenid").val(),
                                    currentpw : jQuery(changePasswordDialog.currentPassword).val() || "",
                                    is_nutanix : isNutanix,
                                    passwordName : changePasswordDialog.passwordName
                                };

                                var req = jQuery.ajax({
                                    url : changePasswordDialog.ajaxURL,
                                    type : 'POST',
                                    data : params,
                                    timeout : 5000
                                });

                                req.success(function(data) {
                                    setDirty(changePasswordDialog, true);
                                    createHiddenInputField(jQuery(pageForm), changePasswordDialog.passwordName, jQuery(changePasswordDialog.theNewPassword1).val());
                                    theDialog.dialog("close");
                                    validateForm(pageForm);
                                    if(isNutanix) {
                                        showHideNutanixPasswordWarnings();
                                    }
                                });

                                req.error(function(data) {
                                    jQuery(changePasswordDialog.passwordError).show();
                                });
                            }
                        }
                    }, {
                        text : resCancelButton,
                        click : function() {

                            setDirty(changePasswordDialog, false);
                            jQuery(this).dialog("close");
                            validateForm(pageForm);
                            if(isNutanix) {
                                showHideNutanixPasswordWarnings();
                            }
                        }
                    }
            ]
        });
    };
}

function setDirty(changePasswordDialog, isDirty) {
    switch (changePasswordDialog.passwordForm) {
        case "#passwordForm":
            passwordDirty = isDirty;
            break;
        case "#vmpasswordForm":
            vmpasswordDirty = isDirty;
            break;
        case "#vmHostPasswordForm":
            vmHostPasswordDirty = isDirty;
            break;
        case "#vmpassphraseForm":
            vmpassphraseDirty = isDirty;
            break;
    }
}

function makeResetPasswordForm(passwordForm, pwdError) {
    return function() {
        jQuery(passwordForm)[0].reset();
        jQuery(passwordForm).validate().resetForm();
        jQuery(pwdError).hide();
    };
}

function makeValidatePasswordForm(passwordForm) {
    return function() {
        if ($(passwordForm).validate().form()) {
            $(passwordForm).validate().resetForm();
            return true;
        }
        return false;
    };
}

function makePasswordMatchRule(changePasswordDialog) {
    jQuery.validator.addMethod(changePasswordDialog.passwordMatchRuleName, function(value, element) {

        var password1 = jQuery(changePasswordDialog.theNewPassword1).val();
        var password2 = jQuery(changePasswordDialog.theNewPassword2).val();
        if (jQuery.trim(password1).length > 0) {
            return this.optional(element) || (password1 == password2);
        } else {
            return true;
        }
    }, changePasswordDialog.passwordsDoNotMatch);
}

function blockNavigation(pageForm) {
    var selector = pageForm + " input, " + pageForm + " select";
    jQuery(selector).change(function() {
        dirty = true;
    });
    window.onbeforeunload = confirmExit;
}

function createHiddenInputField(form, name, value) {
    var html = '<input type="hidden" id="' + name + '" name="' + name + '" value="' + value + '"/>';
    form.append(html);
}

function checkNutanixConnection() {
    var formtoken = jQuery("#formtoken").val();
    var formtokenid = jQuery("#formtokenid").val();

    var data = {
        "formtoken" : formtoken,
        "formtokenid" : formtokenid,
        "is_nutanix" : true,
        "main_ui" : true
    };
    checkConnection(data);
}

function checkConnection(data) {
    var req = jQuery.post("/AJAXCheckHostConnection", data);
    var warningDiv = jQuery("#warningDiv");
    warningDiv.removeClass("ConnectionFailure").addClass("ConnectionStatusWait");
    warningDiv.text(resAttemptConnection);

    req.success(function(data) {
        if (data != null) {
            var valid = data.isValid;
            if (valid != 1) {
                warningDiv.removeClass("ConnectionStatusWait").addClass("ConnectionFailure");
                if (isHyperV) {
                    if (valid == 0) {
                        warningDiv.text(resNetworkError);
                    } else if (valid == -1) {
                        warningDiv.text(resPermissionsError);
                    }
                } else {
                    if (isVCenterManaged) {
                        showHideWebPluginDiv(data.webPluginSupported);
                        showHideLegacyPluginDiv(data.legacyPluginSupported);
                    }

                    warningDiv.text(resInvalidConnection);
                }
            } else {
                if (!isHyperV) {
                    if (isVCenterManaged) {
                        showHideWebPluginDiv(data.webPluginSupported);
                        showHideLegacyPluginDiv(data.legacyPluginSupported);
                    }
                }

                warningDiv.remove();
            }
        } else {
            warningDiv.remove();
        }
    });

    req.error(function(data) {
        warningDiv.removeClass("ConnectionStatusWait").addClass("ConnectionFailure");
        warningDiv.text(resInvalidConnection);
    });
}

function showHideNutanixPasswordWarnings() {
    var newClusterPasswordToSet = jQuery("#" + resVMPasswordName).length > 0;
    var newHostPasswordToSet = jQuery("#" + resVMHostPasswordName).length > 0;
    
    if (newClusterPasswordToSet || newHostPasswordToSet) {
        jQuery("#SshKeyPathWillBeDeletedWarning").show();
        jQuery("#passwordWillBeDeletedWarning").hide();
    } else {
        jQuery("#SshKeyPathWillBeDeletedWarning").hide();
        jQuery("#passwordWillBeDeletedWarning").hide();
    }
}
        