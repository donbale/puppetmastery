var $form, dirty;

jQuery( document ).ready( function () {

    initializeInventory();
} );

function initializeInventory () {

    var clusterImage = "images/cluster.gif", hostImage = "images/host.gif";

    dirty = false;
    $form = jQuery( "form" );
    if ( jQuery( "#hyperVFlag" ).length > 0 ) {
        clusterImage = "images/cluster_hyperv.png";
        hostImage = "images/host_hyperv.png";
    }

    jQuery( "#inventory" ).bind( "loaded.jstree", function ( event, data ) {

        jQuery( this ).jstree( "open_all" );
    } ).bind( "select_node.jstree", function ( event, data ) {

        selectHosts( jQuery( this ), event, data );
    } ).jstree(
            {
                "core" : {
                    "strings" : {
                        multiple_selection : jQuery( "#res_multiple_selection" ).text()
                    }
                },
                "themes" : {
                    "theme" : "default",
                    "dots" : false,
                    "icons" : true
                },
                "ui" : {
                    "selected_parent_close" : false,
                    "select_prev_on_delete" : false,
                    "disable_selecting_children" : true
                },
                "types" : {
                    "valid_children" : [
                            "datacenter", "datacenter-disabled", "cluster", "cluster-disabled", "host",
                            "host-disabled", "pcnshost", "pcnshost-disabled", "vcsahost", "vcsahost-disabled",
                            "vcsapcnshost", "vcsapcnshost-disabled"
                    ],
                    "types" : {
                        "datacenter" : {
                            "valid_children" : [
                                    "cluster", "cluster-disabled", "host", "host-disabled", "pcnshost",
                                    "pcnshost-disabled", "vcsahost", "vcsahost-disabled", "vcsapcnshost",
                                    "vcsapcnshost-disabled"
                            ],
                            "icon" : {
                                "image" : "images/datacenter.gif"
                            }
                        },
                        "host" : {
                            "valid_children" : "none",
                            "icon" : {
                                "image" : hostImage
                            }
                        },
                        "pcnshost" : {
                            "valid_children" : "none",
                            "icon" : {
                                "image" : "images/pwrchute.png"
                            }
                        },
                        "vcsahost" : {
                            "valid_children" : "none",
                            "icon" : {
                                "image" : "images/vsphere.png"
                            }
                        },
                        "vcsapcnshost" : {
                            "valid_children" : "none",
                            "icon" : {
                                "image" : "images/hybrid.png"
                            }
                        },
                        "cluster" : {
                            "valid_children" : [
                                    "host", "host-disabled", "pcnshost", "pcnshost-disabled", "vcsahost",
                                    "vcsahost-disabled", "vcsapcnshost", "vcsapcnshost-disabled"
                            ],
                            "icon" : {
                                "image" : clusterImage
                            }
                        },
                        "host-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : hostImage
                            }
                        },
                        "pcnshost-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : "images/pwrchute.png"
                            }
                        },
                        "vcsahost-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : "images/vsphere.png"
                            }
                        },
                        "vcsapcnshost-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : "images/hybrid.png"
                            }
                        },
                        "datacenter-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : "images/datacenter.gif"
                            }
                        },
                        "cluster-disabled" : {
                            "select_node" : false,
                            "icon" : {
                                "image" : clusterImage
                            }
                        }
                    }
                },
                "crrm" : {
                    "move" : {
                        "check_move" : function ( m ) {

                            return false;
                        }
                    }
                },
                "dnd" : {
                    "drop_target" : false,
                    "drag_target" : false
                },
                "plugins" : [
                        "themes", "html_data", "dnd", "crrm", "ui", "types"
                ]
            } );
}
function updateDeleteButton () {
    if ($("#vCenterErrorText").length <= 0) {
    	jQuery( "#deletebtn" ).button( "option", "disabled", jQuery( "#mappedlist" ).jstree( "get_selected" ).length == 0 );
    }
}

function updateNextButton () {

    var $next = jQuery( "#next" );
    if ( $next.length > 0 ) {
        // For nutanix, all hosts must be protected. Disable next until all hosts are mapped.
        if ( $( "#nutanixFlag" ).length > 0 ) {
            // In an advanced configuration, all host must also be protected by the same ups group/single ups.
            if ( $( "#advancedFlag" ).length > 0 ) {
                if ( allHostsMappedUnderSameGroup() ) {
                    $next.button( 'option', 'disabled', false );
                }
                else {
                    $next.button( 'option', 'disabled', true );
                }
            }
            else {
				clustersok = true;
				jQuery("#inventory .cluster").each(function() {
					mappedhosts = jQuery(this).find( ".host.mapped" ).length;
					hosts = jQuery(this).find( ".host" ).length;
				   
					if(mappedhosts==0 || mappedhosts==hosts){
						//its ok
					} else {
						clustersok = false;
					};
		
				});
	
				if(clustersok && jQuery( "#mappedlist li.host" ).length > 0){
					$next.button( 'option', 'disabled', false );
				} else {
					$next.button( 'option', 'disabled', true );
				};
            }
        }
        else {
        if ( jQuery( "#mappedlist li.host" ).length > 0 || jQuery( "#inventory li.host" ).length == 0 ) {
            $next.button( 'option', 'disabled', false );
        }
        else {
            $next.button( 'option', 'disabled', true );
        }
    }
}
}

function enableResetButton () {

    if ($("#vCenterErrorText").length <= 0) {
	    jQuery( "#resetbtn" ).button( "option", "disabled", false );
	    showHideValidation();
	    dirty = true;
	}
}

function enableApplyButton () {

    if ($("#vCenterErrorText").length <= 0) {
	    jQuery( "#applybtn" ).button( "option", "disabled", false );
	    showHideValidation();
	    dirty = true;
    }
}

function createHiddenInputField ( name, value ) {

    var html = '<input type="hidden" name="' + name + '" value="' + value + '"/>';
    $form.append( html );
}

function removeHosts () {

    var hosts = jQuery( "#mappedlist" ).jstree( "get_selected" );
    jQuery( "#inventory" ).jstree( "deselect_all" );
    hosts.each( function ( i, host ) {

        var $host = jQuery( host );
        var target = jQuery( "#inventory li.host[lnk='" + $host.attr( "lnk" ) + "']" );
        jQuery( "#mappedlist" ).jstree( "remove", $host );
        if ( target.length > 0 ) {
            target.removeClass( "mapped" );
            target.attr( "rel", target.attr( "rel" ).replace( "-disabled", "" ) );
            target.parents( "li.cluster, li.datacenter" ).each( function () {

                var thisRef = jQuery( this );
                thisRef.removeClass( "mapped" );
                thisRef.attr( "rel", thisRef.attr( "rel" ).replace( "-disabled", "" ) );
            } );

            jQuery( "#inventory" ).jstree( "select_node", target.find( "a" ), false );
        }
    } );
}

function moveHosts ( event, data ) {

    var rslt = data.rslt;
		
    if ( rslt.cy ) {
		// we copied host(s) from inventory to mappedlist
        jQuery.each( rslt.o, function ( i, host ) {
            // hide in inventory
            var $host = jQuery( host );
            var type = $host.attr( "rel" );
            if ( type == "host" || type == "pcnshost" || type == "vcsahost" || type == "vcsapcnshost" ) {
                jQuery( "#inventory" ).jstree( "deselect_node", host );
                $host.addClass( "mapped" ); // hide host in inventory
                $host.attr( "rel", type + "-disabled" );
                $host.parents( "li.cluster, li.datacenter" ).each( function () {

                    var thisRef = jQuery( this );
                    if ( thisRef.find( "li.host" ).not( ".mapped" ).length == 0 ) {
                        // hide datacenter and cluster if they have no visible hosts
                        thisRef.addClass( "mapped" );
                        thisRef.attr( "rel", thisRef.attr( "rel" ) + "-disabled" );
                    }
                    else {
                        return false;
                    }
                } );
            }
        } );
    }
    else {
        // we moved host(s) in mappedList
    }
}

function selectHosts ( tree, event, data ) {

    var node = jQuery( data.args[ 0 ] );
    var parent = node.parent();
    var relAttr = parent.attr( "rel" );
    if ( relAttr != "host" && relAttr != "pcnshost" && relAttr != "vcsahost" && relAttr != "vcsapcnshost" ) {
        tree.jstree( "deselect_node", node );
        parent.find( "li.host a" ).each( function () {

            var thisRef = jQuery( this );
            if ( !thisRef.parent().hasClass( "mapped" ) ) {
                tree.jstree( "select_node", thisRef, false );
            }
        } );
    }
}

function initVCenterCheckingDialog () {

    jQuery( ".checkConnectionDialog" ).dialog( {
        height : 140,
        width : 300,
        modal : true,
        closeOnEscape : false,
        closeText : "hide",
        resizable : false,
        draggable : false,
        autoOpen : true,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function () {

            var thisRef = $( this );
            // remove close button
            thisRef.parents( ".ui-dialog:first" ).find( ".ui-dialog-titlebar-close" ).remove();
            // set hourglass cursor
            thisRef.parents().find( ".ui-widget-overlay:first, .ui-dialog:first" ).css( "cursor", "wait" );
        }
    } );
}
