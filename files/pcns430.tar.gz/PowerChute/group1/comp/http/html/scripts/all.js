var heartBeatAjaxUpdateId = null;
var heartBeatAjaxUpdateErrorCount = 0;
var MAX_AJAX_RETRIES = 5;

function displayAboutWindow () {

    window.open( "about.html", 'About', 'width=520,height=350' );
}

function ShowHelp ( page ) {

    help_window = window.open( page, 'Help',
            'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable,width=960,height=600' );

    if ( navigator.appName == 'Netscape' ) {
        help_window.focus();
    }
    else {
        help_window.location.href = page;
    }

}

function initHeartBeat () {

    clearHeartBeatAjaxUpdate();
    heartBeatAjaxUpdate();
    heartBeatAjaxUpdateId = setInterval( function () {

        heartBeatAjaxUpdate()
    }, 12000 );
}

function initAJAXStatusIconTray () {

    statusIconTrayAjaxUpdate();
}

function clearHeartBeatAjaxUpdate () {

    if ( heartBeatAjaxUpdateId != null ) {
        clearInterval( heartBeatAjaxUpdateId );
        heartBeatAjaxUpdateId = null;
    }
}

function heartBeatAjaxUpdate () {

    var req = jQuery.ajax( {
        url : '/Heartbeat',
        type : 'POST',
        timeout : 3000
    } );

    req.success( function ( data ) {

        heartBeatAjaxUpdateErrorCount = 0;
    } );

    req.error( function () {

        heartBeatAjaxUpdateErrorCount++;
        if ( heartBeatAjaxUpdateErrorCount > MAX_AJAX_RETRIES ) {
            clearHeartBeatAjaxUpdate();
        }
    } );
}

function statusIconTrayAjaxUpdate () {

    var req = jQuery.ajax( {
        url : '/AJAXStatusIconTray',
        type : 'POST',
        timeout : 10000
    } );

    req.success( function ( data ) {

        jQuery( "#StatusIconTray" ).html( data );
    } );
}

function loginOnLoad () {

    var noCookies = jQuery( '#noCookies' ), date = new Date(), expires;

    if ( noCookies != null ) {
        document.cookie = "pcnstestcookie=on";
        if ( document.cookie.indexOf( 'pcnstestcookie' ) == -1 ) {
            noCookies.show();
        }
        else {
            date.setTime( date.getTime() - 86400000 );
            expires = "; expires=" + date.toGMTString();
            document.cookie = "pcnstestcookie=" + expires + "; path=/";
            noCookies.hide();
        }
    }
}
