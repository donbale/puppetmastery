// =============================================================
//
// This file contains scripts used for the Configuration wizard.
// Much of the code does validation, but there is alst
// a chunk that does the adding of extra fields for the
// NMC Ip addresses.
// =============================================================

// =============================================================
// Generic validation functions
// =============================================================

// Added for Host NMC mapping page for Virtualization support for VMware.
// HostNMCMappingPage.java file.
// Hyperlink have been associated for every entity in this page to perform
// mapping and below function disables the pop up to navigate away from the
// current page
function disableBeforeUnload () {

    window.onbeforeunload = null;
}

// Initialise the validation.
// This adds the functions to the elements
// This is run on load of the page.
function initValidation () {

    // alert('initValidation');

    // This does the cookies check
    loginOnLoad();

    jQuery( 'input[type="text"], input[type="password"]' ).on( "keyup", validate_Form );
    jQuery( 'input[type="radio"], input[type="checkbox"]' ).on( "change", validate_Form );
    jQuery( 'select' ).on( "change", validate_Form );
    jQuery( 'input[type="text"], input[type="password"]' ).on( "paste cut", function () {

        setTimeout( function () {

            validate_Form();
        }, 0 );
        // needs to be done this way, otherwise the paste/cut events are fired
        // before the text is in the texbox or before it is remove in the case of the cut event
    } );

    validate_Form();
}

// This is the generic form validation code.
// It calls the form specific validation function
function validate_Form () {

    elementsForms = document.getElementsByTagName( "form" );

    for ( var intCounter = 0; intCounter < elementsForms.length; intCounter++ ) {
        currentForm = elementsForms[ intCounter ];
        // alert('Form:' + currentForm.name);

        var validated = true;
        // Add each form to be validated here
        if ( currentForm.name == "Set Login" ) {
            validated = validate_Login();
        }
        else if ( currentForm.name == "Select Network Configuration" ) {
            validated = validate_UpsNetworkConfiguration();
        }
        else if ( currentForm.name == "Select IpConfiguration" ) {
            validated = validate_SelectIpConfiguration();
        }
        else if ( currentForm.name == "Select Ip" ) {
            validated = validate_SelectIp();
        }
        else if ( currentForm.name == "Ups Physical Configuration" ) {
            validated = validate_UpsPhysicalConfiguration();
        }
        // Validation performed for ESXiConfiguration in config wizard, added
        // for PCNS 3.1
        else if ( currentForm.name == "ESXiConfiguration" ) {
            validated = validate_ESXiConfiguration();
        }
        else
        // Validation performed for ESXiHostDetailsPage in config wizard, added
        // for PCNS 3.1
        if ( currentForm.name == "ESXi Host Details" ) {
            validated = validate_ESXiHostDetails();
        }
        else if ( currentForm.name == "TargetHostSelectionPage" ) {
            continue; // this page has its own validation script
        }
        else if ( currentForm.name == "HostNMCMappingPage" ) {
            continue; // this page has its own validation script
        }
        else if ( currentForm.name == "UPSGroupsPage" ) {
            return; // this page has its own validation script
        }
        else if ( currentForm.name == "CfgGroupsShutdownPage" ) {
            return; // this page has its own validation script
        }
        else if ( currentForm.name == "VMSettingsPage" ) {
            return; // this page has its own validation script
        }
        else if ( currentForm.name == "Connect" ) {
            validated = true;
        }
        else if ( currentForm.name == "SOGSelect" ) {
            validated = validate_SOGSelect();
        }
        else if ( currentForm.name == "SOGSet" ) {
            validated = true;
        }
        else if ( currentForm.name == "Misc" ) {
            validated = validate_MiscPage();
        }
        else if ( currentForm.name == "Final" ) {
            validated = false; // never go to the
            // next page from
            // Finised!
        }

        // Only enable the next button if it is validated.
        var nextButton = jQuery( '#next' );
        if ( validated ) {
            disable( nextButton, false );
        }
        else {
            disable( nextButton, true );
        }
    }
}

// =============================================================
// Validate each of the forms
// =============================================================

function validate_Login () {

    var isValid = true;
    // List of special characters supported in the password/username field.
    // var specialChars = /^[A-Za-z0-9_\" \"!\"#$%&'()\*+,-.\/:;<=>?@\\^`{|}\[\]~]$/;
    var resRequiredField = jQuery( "#resRequiredField" ).text();
    var resUsernameValidation = jQuery( "#resUsernameValidation" ).text();
    var resUnsupportedCharacter = jQuery( "#resUnsupportedCharacter" ).text();
    var resMaxLengthValidation = jQuery( "#resMaxLengthValidation" ).text();
    var resRangeValidation = jQuery( "#resRangeValidation" ).text();
    var resAuthPhraseRangeValidation = jQuery( "#resAuthPhraseRangeValidation" ).text();
    var resAuthPhraseValidation = jQuery( "#resAuthPhraseValidation" ).text();
    var specialChars = /^[\x20-\x3B\x3D\x3F-\x7E]+$/;
    var usascii = /^[\x20-\x7E]+$/;
    var authPhraseRegEx = /^\S.{13,30}\S$/;

    var name = document.getElementById( "User_input" );
    if ( ( name.value != '' ) ) {
        // Username should not be blank.
        if ( name.value.length < 1 ) {
            isValid = false;
        }
        // Usetname should not be above 64 ASCII Characters.
        if ( name.value.length > 10 ) {
            document.getElementById( 'User_validation' ).innerHTML = resUsernameValidation;
            setVisibile( "User_validation", true );
            isValid = false;
        }
        else {
            // check for extra special characters(For ex: �, �, �) in username field.
            if ( !specialChars.test( name.value ) ) {
                document.getElementById( 'User_validation' ).innerHTML = resUnsupportedCharacter;
                setVisibile( "User_validation", true );
                isValid = false;
            }
            else {
                // reset the id User_validation to "Required" since we
                // might have hit the innerHTML method for special
                // character above.
                document.getElementById( 'User_validation' ).innerHTML = resRequiredField;
                setVisibile( "User_validation", false );
            }
        }
    }
    else {
        document.getElementById( 'User_validation' ).innerHTML = resRequiredField;
        setVisibile( "User_validation", true );
        isValid = false;
    }

    var pass = document.getElementById( "Pass_input" );
    if ( pass.value != '' ) {

        // check for minimum password length. if pwd length is less than 3 then
        // disable the next button.
        if ( pass.value.length < 3 ) {
            document.getElementById( 'Pass_validation' ).innerHTML = resRangeValidation;
            setVisibile( "Pass_validation", true );
            isValid = false;
        }
        // check for maximum password length. if pwd length is greater than 32
        // then disable the next button and present the error message.
        if ( pass.value.length > 32 ) {
            document.getElementById( 'Pass_validation' ).innerHTML = resMaxLengthValidation;
            setVisibile( "Pass_validation", true );
            isValid = false;
        }
        // check for extra special characters(For ex: �, �, �) in password
        // field.
        // Pass value should be between 3-32 characters
        if ( pass.value.length > 2 && pass.value.length < 33 ) {
            if ( !usascii.test( pass.value ) ) {
                document.getElementById( 'Pass_validation' ).innerHTML = resUnsupportedCharacter;
                setVisibile( "Pass_validation", true );
                isValid = false;
            }
            else {
                // reset the id Pass_validation to "Required" since we
                // might have hit the innerHTML method for special
                // character above.
                document.getElementById( 'Pass_validation' ).innerHTML = resRequiredField;
                setVisibile( "Pass_validation", false );
            }
        }
    }
    else {
        document.getElementById( 'Pass_validation' ).innerHTML = resRequiredField;
        setVisibile( "Pass_validation", true );
        isValid = false;
    }

    var auth = document.getElementById( "AuthPhrase_input" );
    if ( auth.value != '' ) {
        if ( auth.value.length < 15 ) {
            document.getElementById( 'AuthPhrase_validation' ).innerHTML = resAuthPhraseRangeValidation;
            setVisibile( "AuthPhrase_validation", true );
            isValid = false;
        }
        if ( auth.value.length > 32 ) {
            document.getElementById( 'AuthPhrase_validation' ).innerHTML = resMaxLengthValidation
            setVisibile( "AuthPhrase_validation", true );
            isValid = false;
        }
        // Auth value should be between 15-32 characters
        if ( auth.value.length > 14 && auth.value.length < 33 ) {
            if ( ( !authPhraseRegEx.test( auth.value ) ) && ( auth.value.length > 14 ) && ( auth.value.length < 33 ) ) {
                document.getElementById( 'AuthPhrase_validation' ).innerHTML = resAuthPhraseValidation
                setVisibile( "AuthPhrase_validation", true );
                isValid = false;
                return;
            }
            else {
                // reset the id AuthPhrase_validation to "Required" since we
                // might have hit the innerHTML method for whitespace
                // character above.
                document.getElementById( 'AuthPhrase_validation' ).innerHTML = resRequiredField;
                setVisibile( "AuthPhrase_validation", false );
            }
        }
    }
    else {
        document.getElementById( 'AuthPhrase_validation' ).innerHTML = resRequiredField;
        setVisibile( "AuthPhrase_validation", true );
        isValid = false;
    }

    return isValid;
}

function validate_SelectIp () {

    // alert('validate_SelectIp');

    var isValid = true;

    var ip = document.getElementById( "RegisterIp_input" );
    // alert('option:' + ip.selectedIndex);

    if ( ip.selectedIndex != 0 ) {
        setVisibile( "RegisterIp_validation", false );
    }
    else {
        setVisibile( "RegisterIp_validation", true );
        isValid = false;
    }

    // alert('validate_SelectIp:' + isValid);
    return isValid;
}

// This function will pass the datacenter selected by the user to
// DatacenterAndClusterInfopage to retrieve all the cluster in the selected
// datacenter
function getClusterNames ( datacenterVal, inventoryOption ) {

    window.location = '/cfgwizard?datacenterVal=' + datacenterVal + '&inventoryOption=' + inventoryOption;
}

function validate_UpsPhysicalConfiguration () {

    return validate_radioButton( "UpsConfig" );
}

function validate_UpsNetworkConfiguration () {

    return validate_radioButton( "UpsNetworkConfig" );
}

function validate_ESXiConfiguration () {

    return validate_radioButton( "ESXIConfiguration" );
}

function validate_MiscPage () {

    return validate_radioButton( "TurnOff" );
}

// Validation added for ESXi Host Details page added for Virtualization support
// for PCNS 3.1
function validate_ESXiHostDetails () {

    var isValid = true;

    var serverIp = document.getElementById( "ESXiServerIP_input" );
    if ( serverIp.value == '' ) {
        isValid = false;
        setVisibile( "ESXiServerIP_validation", true );
    }
    else {
        setVisibile( "ESXiServerIP_validation", false );
    }

    var username = document.getElementById( "ESXiUserName_input" );
    if ( username.value == '' ) {
        isValid = false;
        setVisibile( "ESXiUserName_validation", true );
    }
    else {
        setVisibile( "ESXiUserName_validation", false );
    }

    var password = document.getElementById( "ESXiPassword_input" );
    if ( password.value == '' ) {
        isValid = false;
        setVisibile( "ESXiPassword_validation", true );
    }
    else {
        setVisibile( "ESXiPassword_validation", false );
    }

    return isValid;
}

function validate_SOGSelect () {

    // alert('validate_SOGSelect');
    var isValid = true;

    elementsInputs = document.getElementsByTagName( "SELECT" );
    id = 0;
    for ( var intCounter2 = 0; intCounter2 < elementsInputs.length; intCounter2++ ) {
        if ( elementsInputs[ intCounter2 ].id.indexOf( "UpsEntryOGs_combo_" ) == 0 ) {
            id++;
            if ( elementsInputs[ intCounter2 ].selectedIndex != 0 ) {
                setVisibile( "UpsEntryOGs_validation" + id, false );
            }
            else {
                setVisibile( "UpsEntryOGs_validation" + id, true );
                isValid = false;
            }
        }
    }

    return isValid;
}

function validate_SelectIpConfiguration () {

    var isValid = true;

    var unicast = document.getElementById( "Unicast" );
    var multicast = document.getElementById( "Multicast" );
    var unicast_value = document.getElementById( "UnicastAddress_input" );
    var multicast_value = document.getElementById( "MulticastAddress_input" );
    var multicastCheckbox = jQuery( "#multicast_input" );
    var showMulticast = false;
    if ( multicastCheckbox != null && multicastCheckbox.is( ":checked" ) ) showMulticast = true;

    if ( showMulticast ) {
        setVisibile( "MulticastAddress_label", true );
        setVisibile( "MulticastAddress_input", true );
        setVisibile( "MulticastAddress_note", true );
        setVisibile( "UnicastAddress_validation", true );
        setVisibile( "UnicastAddress_label", true );
        setVisibile( "UnicastAddress_input", true );
        setVisibile( "UnicastAddress_note", true );
        setVisibile( "IPv6NetworkConfig_note", true );
        var unicastSelected = ( unicast_value.selectedIndex != 0 );
        if ( unicastSelected ) setVisibile( "UnicastAddress_validation", false );
        if ( ( multicast_value.value != '' ) && ( unicastSelected == true ) ) {
            isIpValid = validate_ip( multicast_value.value );
            if ( isIpValid ) {
                setVisibile( "MulticastAddress_validation", false );
                isValid = true;
            }
            else {
                setVisibile( "MulticastAddress_validation", true );
                isValid = false;
            }
        }
        else if ( ( multicast_value.value == '' ) && ( unicastSelected == true ) ) {
            setVisibile( "MulticastAddress_validation", true );
            isValid = false;
        }
        else if ( ( multicast_value.value != '' ) && ( unicastSelected == false ) ) {
            setVisibile( "MulticastAddress_validation", false );
            isValid = false;
        }
        else {
            setVisibile( "MulticastAddress_validation", true );
            isValid = false;
        }
    }
    else {
        setVisibile( "UnicastAddress_label", true );
        setVisibile( "UnicastAddress_input", true );
        setVisibile( "UnicastAddress_note", true );
        setVisibile( "MulticastAddress_validation", false );
        setVisibile( "MulticastAddress_label", false );
        setVisibile( "MulticastAddress_input", false );
        setVisibile( "MulticastAddress_note", false );
        if ( unicast_value.selectedIndex != 0 ) {
            setVisibile( "UnicastAddress_validation", false );
            isValid = true;
        }
        else {
            setVisibile( "UnicastAddress_validation", true );
            isValid = false;
        }
    }

    return isValid;
}

// =============================================================
// Util functions
// =============================================================

function setVisibile ( id, visible ) {

    if ( visible ) {
        jQuery( "#" + id ).attr( 'style', 'visibility: visible;' );
    }
    else {
        jQuery( "#" + id ).attr( 'style', 'visibility: hidden;' );
    }
}

function validate_string ( field, length ) {

}

function validate_int ( text, min, max ) {

    var regex = /^[\d]*$/
    if ( text.search( regex ) != -1 ) {
        // it is all digits
        var i = parseInt( text );

        if ( ( i >= min ) && ( i <= max ) ) {
            return true;
        }
    }
    return false;
}

// Checks that one of the buttons is checked
function validate_radioButton ( buttonName ) {

    elements = document.getElementsByName( buttonName );

    for ( var intCounter = 0; intCounter < elements.length; intCounter++ ) {
        if ( elements[ intCounter ].checked ) {
            return true;
        }
    }

    return false;
}

function validate_ip ( text ) {

    var ipv4 = document.getElementById( "IPv4" );
    var ipv6 = document.getElementById( "IPv6" );
    if ( ipv6 != null ) {
        var regex = /^((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?$/
    }
    if ( ipv4 != null ) {
        var regex = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
    }
    if ( text.search( regex ) != -1 ) {
        return true;
    }
    else {
        return false;
    }
}

function disable ( element, value ) {

    element.button( 'option', 'disabled', value );
}

function findPosition ( oLink ) {

    if ( oLink.offsetParent ) {
        for ( var posX = 0, posY = 0; oLink.offsetParent; oLink = oLink.offsetParent ) {
            posX += oLink.offsetLeft;
            posY += oLink.offsetTop;
        }
        return [
                posX, posY
        ];
    }
    else {
        return [
                oLink.x, oLink.y
        ];
    }
}

function getParent ( el, pTagName ) {

    if ( el == null )
        return null;
    else if ( el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase() ) // Gecko
        // bug,
        // supposed
        // to be
        // uppercase
        return el;
    else
        return getParent( el.parentNode, pTagName );
}

function format ( str ) {

    var args = arguments;
    return str.replace( /{(\d)}/g, function ( r, n ) {

        return args[ +n + 1 ];
    } );
}

// enlarge the ups config images
function enlargeImages () {

    initLightbox();
}

function initLightbox () {

    jQuery( ".UpsConfig_img" ).click( function () {

        jQuery( "#" + this.id + "_lb" ).dialog( "open" );
    } );

    var resCloseButton = jQuery( "#resCloseButton" ).text();

    jQuery( ".lightboximg" ).each( function () {

        var thisRef = jQuery( this );
        thisRef.dialog( {
            autoOpen : false,
            modal : true,
            width : thisRef.width() + 32,
            height : thisRef.height() + 56,
            draggable : false,
            resizable : false,
            show : "scale",
            hide : "fade",
            closeText : resCloseButton,
            position : {
                my : "center",
                at : "center",
                of : "#container"
            },
            open : function ( event, ui ) {

                jQuery( ".ui-widget-overlay" ).click( function () {

                    thisRef.dialog( "close" );
                } );
            }
        } );
    } );
}

/*
 * Show/Hide advanced configuration message
 */
function showHideAdvancedConfigMsg () {

    var obj = jQuery( 'input:radio[name=UpsConfig]:checked' );
    var infoDiv = jQuery( "#infomsg" );
    if ( obj != null && obj.length > 0 && obj.val() == "5" ) {//if advanced option was chosen display the info msg
        infoDiv.show();
    }
    else {
        infoDiv.hide();
    }
}

/*
 * Add callback on ups config screen radio buttons
 * so showHideAdvancedConfigMsg is called on change
 */
function addUpsModeCallback () {

    jQuery( 'input:radio[name=UpsConfig]' ).change( function () {

        showHideAdvancedConfigMsg();
    } );
}

function openWaitDialog () {

    jQuery( ".wizardButton" ).click( function ( e ) {

        jQuery( ".waitDialog" ).dialog( "open" );
    } );
}

jQuery( document ).ready( function () {

    initWaitDialog();
    jQuery( ".waitDialog" ).dialog( "close" );
    dirty = false;
    enlargeImages();
    openWaitDialog();
    if ( jQuery( 'input:radio[name=UpsConfig]' ).length > 0 ) {
        addUpsModeCallback();
        showHideAdvancedConfigMsg();
    }
} );
