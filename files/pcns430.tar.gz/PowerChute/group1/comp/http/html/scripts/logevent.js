function initLogging () {

    initLogEventValidation();
    initWaitDialog();
    validateForm();
}

function initLogEventValidation () {

    $form.validate( {
        rules : {},
        messages : {},
        // errorContainer: jQuery("#errorcontainer"),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );
}
