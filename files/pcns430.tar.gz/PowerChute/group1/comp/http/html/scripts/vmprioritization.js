var $form, resRequiredFieldValidation, resRangeValidation, resDigitsValidation, resDurationGreaterThanZero;
var resMultipleSelection, resInventoryLoading;

jQuery(document).ready(function() {

    $form = jQuery("#vmprioritizationform");
    var activeAcc = parseInt(jQuery("#activeAcc").val(), 10);
    if (isNaN(activeAcc)) {
        activeAcc = 0;
    }

    resRequiredFieldValidation = jQuery("#resRequiredFieldValidation").text();
    resRangeValidation = jQuery("#resRangeValidation").text();
    resDigitsValidation = jQuery("#resDigitsValidation").text();
    resMultipleSelection = jQuery("#resMultipleSelection").text();
    resInventoryLoading = jQuery("#resInventoryLoading").text();
    resPriorityLoading = jQuery("#resPriorityLoading").text();

    jQuery("#VMPrioritizationEnabled").change(function() {
        showHideAccordion();
        validateVMPrioritizationForm();
    });

    jQuery("#resetVMPrioritization").addClass("cancel").click(function() {

        $form[0].reset();
        jQuery("#accordionDiv .vmduration").each(function() {

            jQuery(this).rules("remove");
        });

        $form.validate().resetForm();
        dirty = false;
        showHideAccordion();
        jQuery("#waitDialog").dialog("open");
        createHiddenInputField("resetVMPrioritization", "resetVMPrioritization");
        $form.submit();
    });

    jQuery("#accordionDiv").accordion({
        heightStyle : "content",
        active : activeAcc
    });

    jQuery("#deletebtn").button({
        disabled : true
    }).click(function() {

        removeVMs();
        dirty = true;
        updateDeleteButton();
        validateVMPrioritizationForm();
    });

    initPriorityTree();
    initInventoryTree();
    initWaitDialog();
    initFormValidation();
    showHideAccordion();
    validateVMPrioritizationForm();
});

function initInventoryTree() {

	jQuery("#applyVMPrioritization").prop( "disabled", true );
    jQuery("#inventory").bind("loaded.jstree", function(event, data) {

        jQuery(this).jstree("open_all");
    }).bind("select_node.jstree", function(event, data) {

        selectVMs(jQuery(this), event, data);
    }).bind('loaded.jstree', function(e, data) {
		validateVMPrioritizationForm();
    }).jstree({
        "core" : {
            "strings" : {
                multiple_selection : resMultipleSelection,
                loading : resInventoryLoading
            }
        },
        "themes" : {
            "theme" : "default",
            "dots" : false,
            "icons" : true
        },
        "ui" : {
            "selected_parent_close" : false,
            "select_prev_on_delete" : false,
            "disable_selecting_children" : true
        },
        "types" : {
            "valid_children" : [
                    "datacenter", "datacenter-disabled", "cluster", "cluster-disabled", "vm", "vm-disabled", "vcsa", "vcsa-disabled", "vapp", "vapp-disabled"
            ],
            "types" : {
                "datacenter" : {
                    "valid_children" : [
                            "cluster", "cluster-disabled"
                    ],
                    "icon" : {
                        "image" : "images/datacenter.gif"
                    }
                },
                "cluster" : {
                    "valid_children" : [
                            "vm", "vm-disabled", "vcsa", "vcsa-disabled", "vapp", "vapp-disabled"
                    ],
                    "icon" : {
                        "image" : "images/cluster.gif"
                    }
                },
				"vm" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vm.png"
                    }
                },
                "vcsa" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vsphere.png"
                    }
                },
                "vapp" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vapp.png"
                    }
                },
                "datacenter-disabled" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/datacenter.gif"
                    }
                },
                "cluster-disabled" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/cluster.gif"
                    }
                },
                "vm-disabled" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/vm.png"
                    }
                },
				"witness" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/vmwitness.png"
                    }
                },
                "vcsa-disabled" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/vsphere.png"
                    }
                },
                "vapp-disabled" : {
                    "select_node" : false,
                    "icon" : {
                        "image" : "images/vapp.png"
                    }
                }
            }
        },
        "crrm" : {
            "move" : {
                "check_move" : function(m) {

                    return false;
                }
            }
        },
        "dnd" : {
            "drop_target" : false,
            "drag_target" : false
        },
        "html_data" : {
            "ajax" : {
                "url" : "/ajaxvmlist?list=inventory",
                "data" : {
                    formtoken : jQuery("#formtoken").val(),
                    formtokenid : jQuery("#formtokenid").val()
                },
                "type" : "POST",
                "timeout" : 90000,
                "success" : function(data) {
		
					jQuery("#applyVMPrioritization").prop( "disabled", false );
					
                    if (data === "99") {
                        jQuery("#vCenterConnectionError").show();
                    } else if (data === "98") {
                        jQuery("#noVMsFound").show();
                    } else {
                        return data;
                    }
                },
                "error" : function(data) {

                    var node = jQuery("#inventory a.jstree-loading").parent();
                    if (node.length > 0) {
                        jQuery("#inventory").jstree("remove", node);
                    }

                    jQuery("#vCenterConnectionError").show();
                }
            }
        },
        "plugins" : [
                "themes", "html_data", "dnd", "crrm", "ui", "types"
        ]
    });
}

function initPriorityTree() {
    jQuery("#prioritylist").bind("loaded.jstree", function(event, data) {

        jQuery(this).jstree("open_all");
    }).bind("move_node.jstree", function(event, data) {

        moveVMs(event, data);
        dirty = true;
        updateDeleteButton();
        validatePriorityList();
        validateVMPrioritizationForm();
    }).bind("select_node.jstree", function(event, data) {

        selectVMs(jQuery(this), event, data);
        validatePriorityList();
        updateDeleteButton();
    }).bind("deselect_node.jstree", function(event, data) {

        updateDeleteButton();
     }).bind('loaded.jstree', function(e, data) {
		validateVMPrioritizationForm();
    }).jstree({
        "core" : {
            "strings" : {
                multiple_selection : resMultipleSelection,
                loading : resPriorityLoading
            }
        },
        "themes" : {
            "theme" : "default",
            "dots" : false,
            "icons" : true
        },
        "ui" : {
            "selected_parent_close" : false,
            "select_prev_on_delete" : false,
            "disable_selecting_children" : true
        },
        "types" : {
            "valid_children" : [
                    "priority-high", "priority-medium", "priority-low", "priority-group1", "priority-group2"
            ],
            "types" : {
                "priority-high" : {
                    "valid_children" : [
                            "vm", "vcsa", "vapp"
                    ],
                    "icon" : {
                        "image" : "images/priority_high.png"
                    }
                },
                "priority-medium" : {
                    "valid_children" : [
                            "vm", "vcsa", "vapp"
                    ],
                    "icon" : {
                        "image" : "images/priority_medium.png"
                    }
                },
                "priority-low" : {
                    "valid_children" : [
                            "vm", "vcsa", "vapp"
                    ],
                    "icon" : {
                        "image" : "images/priority_low.png"
                    }
                },
                "priority-group1" : {
                    "valid_children" : [
                            "vm", "vcsa", "vapp"
                    ],
                    "icon" : {
                        "image" : "images/priority_low.png"
                    }
                },
                "priority-group2" : {
                    "valid_children" : [
                            "vm", "vcsa", "vapp"
                    ],
                    "icon" : {
                        "image" : "images/priority_low.png"
                    }
                },
                "vm" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vm.png"
                    }
                },
                "vcsa" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vsphere.png"
                    }
                },
                "vapp" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vapp.png"
                    }
                }
            }
        },
        "crrm" : {
            "move" : {
                "always_copy" : "multitree", // create a copy if move is between trees
                "check_move" : function(m) {

                    // only allow unmapped vm's to be moved
                    var $target = jQuery(m.o[0]);
                    return ($target.hasClass("vm") || $target.hasClass("vcsa") || $target.hasClass("vapp")) && !($target.hasClass("mapped"));
                }
            }
        },
        "dnd" : {
            "drop_target" : false,
            "drag_target" : false
        },
        "html_data" : {
            "ajax" : {
                "url" : "/ajaxvmlist?list=priority",
                "data" : {
                    formtoken : jQuery("#formtoken").val(),
                    formtokenid : jQuery("#formtokenid").val()
                },
                "type" : "POST",
                "timeout" : 90000,
                "success" : function(data) {

                    if (data === "99") {
                        jQuery("#vCenterConnectionError").show();
                    } else if (data === "98") {
                        jQuery("#noVMsFound").show();
                    } else {
                        return data;
                    }
                },
                "error" : function(data) {

                    var node = jQuery("#prioritylist a.jstree-loading").parent();
                    if (node.length > 0) {
                        jQuery("#prioritylist").jstree("remove", node);
                    }

                    jQuery("#vCenterConnectionError").show();
                }
            }
        },
        "plugins" : [
                "themes", "html_data", "dnd", "crrm", "ui", "types"
        ]
    });
}

function updateDeleteButton() {
    jQuery("#deletebtn").button("option", "disabled", jQuery("#prioritylist").jstree("get_selected").length == 0);
}

function removeVMs() {
    var vMs = jQuery("#prioritylist").jstree("get_selected");
    jQuery("#inventory").jstree("deselect_all");
    vMs.each(function(i, vM) {

        var $VM = jQuery(vM);
        jQuery("#prioritylist").jstree("remove", $VM);
        var type = $VM.attr("rel");
        var target = jQuery("#inventory li." + type + "[data-vmname='" + $VM.data("vmname") + "']");

        if (target.length > 0) {
            target.removeClass("mapped");
            target.attr("rel", target.attr("rel").replace("-disabled", ""));
            target.parents("li.cluster, li.datacenter").each(function() {

                var thisRef = jQuery(this);
                thisRef.removeClass("mapped");
                thisRef.attr("rel", thisRef.attr("rel").replace("-disabled", ""));
            });
        }
    });
    validatePriorityList();
}

function moveVMs(event, data) {
    var rslt = data.rslt;
    if (rslt.cy) {
        // we copied vm(s) from inventory to priority list
        jQuery.each(rslt.o, function(i, vM) {

            // hide in inventory
            var $VM = jQuery(vM);
            if ($VM.hasClass("vm") || $VM.hasClass("vcsa") || $VM.hasClass("vapp")) {
                jQuery("#inventory").jstree("deselect_node", vM);
                $VM.addClass("mapped"); // hide VM in inventory
                $VM.attr("rel", $VM.attr("rel") + "-disabled");
                $VM.parents("li.cluster, li.datacenter").each(function() {

                    var thisRef = jQuery(this);
                    // hide datacenter and cluster if they have no visible VM's
                    var noVMs = (thisRef.find("li.vm").not(".mapped").length == 0);
                    var noVapps = (thisRef.find("li.vapp").not(".mapped").length == 0)
                    var noVCSA = (thisRef.find("li.vcsa").not(".mapped").length == 0)
                    if (noVMs && noVapps && noVCSA) {
                        thisRef.addClass("mapped");
                        thisRef.attr("rel", thisRef.attr("rel") + "-disabled");
                    } else {
                        return false;
                    }
                });
            }
        });
    }
}

function selectVMs(tree, event, data) {
    var node = jQuery(data.args[0]);
    var parent = node.parent();
    if (!(parent.hasClass("vm") || parent.hasClass("vcsa") || parent.hasClass("vapp"))) {
        tree.jstree("deselect_node", node);
        var mapper = function() {

            var thisRef = jQuery(this);
            if (!thisRef.parent().hasClass("mapped")) {
                tree.jstree("select_node", thisRef, false);
            }
        }
        parent.find("li.vm a").each(mapper);
        parent.find("li.vcsa a").each(mapper);
        parent.find("li.vapp a").each(mapper);
    }
}

function validatePriorityList() {
    if (checkVirtualAppPriorities()) {
        jQuery("#prioritylist").removeClass("ui-state-error");
        jQuery("#prioritylist").closest(".prioritycontent").prev(".priorityheader").removeClass("errorheader");
        jQuery("#priorityListError").hide();
    } else {
        jQuery("#prioritylist").addClass("ui-state-error");
        jQuery("#prioritylist").closest(".prioritycontent").prev(".priorityheader").addClass("errorheader");
        jQuery("#priorityListError").show();
    }
}

function checkVirtualAppPriorities() {
    var groupList = [
            "group2", "group1", "low", "medium", "high"
    ];

    // Assume VCSA is not selected until we find it.
    // Default priority for VCSA is the highest priority group.
    var vcsaPriority = 4;

    // Assume vapps are not selected until we find them, i.e. in the
    // unproritized group
    var vappPriority = -1;

    for (var i = 0; i < groupList.length; i++) {
        if (jQuery("#prioritylist li.priority-" + groupList[i]).has("li.vcsa").length > 0) {
            vcsaPriority = i;
        }
        if (jQuery("#prioritylist li.priority-" + groupList[i]).has("li.vapp").length > 0) {
            vappPriority = i;
        }
    }

    // Ensure that vcsa is greater than or equal to the highest vapp.
    var valid = (vcsaPriority >= vappPriority);
    if (valid) {
        jQuery("#priorityListValid").val(0)
    } else {
        jQuery("#priorityListValid").val(1)
    }

    return valid;
}

function initFormValidation() {
    $form.validate({
        ignore : ".ignore",
        errorContainer : jQuery("#errorcontainer"),
        errorPlacement : function(error, element) {

            // display error message after the label-value-pair row
            error.appendTo(element.closest(".labelvaluediv"));
        },
        highlight : function(element, errorClass, validClass) {

            jQuery(element).addClass(errorClass).removeClass(validClass);
            jQuery(element).closest(".durationscontent").prev(".durationsheader").addClass("errorheader");
        },
        unhighlight : function(element, errorClass, validClass) {

            var elementRef = jQuery(element), hasError = elementRef.hasClass(errorClass);
            elementRef.removeClass(errorClass).addClass(validClass);
            if (hasError) {
                removeErrorHeader(elementRef.closest(".durationscontent"));
            }
        },
        submitHandler : function(form) {

            // store active accordion page
            var activeAcc = jQuery("#accordionDiv").accordion("option", "active");
            jQuery("#activeAcc").val(activeAcc);

            // apply button clicked and form validated
            dirty = false;
            postVMs();
            jQuery("#waitDialog").dialog("open");
            form.submit();
        }
    });

    jQuery("#priorityListCheck").rules("add", {
        required : true,
        equalTo : "#priorityListValid"
    });

    jQuery("#accordionDiv .vmduration").each(function() {

        jQuery(this).rules("add", {
            required : true,
            range : [
                    0, 172800
            ],
            digits : [
                    0, 172800
            ],
            messages : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            }
        });
    });

    jQuery('#accordionDiv .vmduration').blur(function(event) {
        validateVMPrioritizationForm();
    });
}

function removeErrorHeader(durationsContent) {
    if (durationsContent.length > 0) {
        if (durationsContent.find("error").length == 0) {
            durationsContent.prev(".durationsheader").removeClass("errorheader");
        }
    }
}

function validateVMPrioritizationForm() {
            var haveZeroDuration = 0;
            jQuery('#accordionDiv .vmduration.vmshutdown').each(function() {

                var value = jQuery(this).val();

				//check if there are vms mapped to this group
				//get name  replace SHUTDOWN with ""
				
			   var priority = jQuery(this).attr('id').replace("SHUTDOWN", "");
			   
				//data-priority=GROUP_1
               //check how many are in the list.
			   
			   var count = jQuery('#prioritylist [data-priority$="'+priority+'"] ul li').size();
			   
			   // warn if value is zero
                if ( (parseInt(count, 10) > 0) && (parseInt(value, 10) == 0)) {
                    haveZeroDuration += 1;
                    jQuery(this).addClass('ui-state-highlight');
                } else {
                    jQuery(this).removeClass('ui-state-highlight');
                }

                if (haveZeroDuration > 0 && jQuery("#VMPrioritizationEnabled").is(":checked")) {
                    jQuery("#warningcontainer").show();
                } else {
                    jQuery("#warningcontainer").hide();
                }
            });

    if ($form.validate().form()) {
        $form.validate().resetForm();
    }
}

function showHideAccordion() {
    if (jQuery("#VMPrioritizationEnabled").is(":checked")) {
        jQuery("#accordionDiv .vmduration").removeClass("ignore");
        jQuery("#accordionDiv").show();
    } else {
        jQuery("#accordionDiv").hide();
        jQuery("#accordionDiv .vmduration").addClass("ignore");
    }
}

function postVMs() {
    var types = [
            "vm", "vcsa", "vapp"
    ];
    for (var i = 0; i < types.length; i++) {
        var type = types[i];

        jQuery("#prioritylist li.priority-high").find("li." + type).each(function() {

            createHiddenInputField("vmhigh", jQuery(this).data("vmname"));
        });

        jQuery("#prioritylist li.priority-medium").find("li." + type).each(function() {

            createHiddenInputField("vmmedium", jQuery(this).data("vmname"));
        });

        jQuery("#prioritylist li.priority-low").find("li." + type).each(function() {

            createHiddenInputField("vmlow", jQuery(this).data("vmname"));
        });

        jQuery("#prioritylist li.priority-group1").find("li." + type).each(function() {

            createHiddenInputField("vmgroup1", jQuery(this).data("vmname"));
        });

        jQuery("#prioritylist li.priority-group2").find("li." + type).each(function() {

            createHiddenInputField("vmgroup2", jQuery(this).data("vmname"));
        });
    }

}

function createHiddenInputField(name, value) {
    var html = '<input type="hidden" name="' + name + '" value="' + value + '"/>';
    $form.append(html);
}
