var oTable = null;
var resEventCount = "";
var closeDialog = null;
var $form = null;
var resCloseButton, resApply, resCancel, resHelp;

function initDatatable () {

    var sScrolly = "438px"; // fitting the menu height
    oTable = jQuery( "#ConfigureEvents" ).DataTable( {
        "language" : {
            "info" : resEventCount
        },
        "dom" : 'RC<"H"lfrip>t', // Specify exactly where in the DOM you want DataTables to inject the various
        // controls: http://datatables.net/usage/options#sDom
        "processing" : false, // processing indicator enabled when the table is being processed
        "serverSide" : false, // table processing is done in the server
        "bDestroy" : true, // Replace a DataTable which matches the given selector and replace it with one which has
        // the properties of the new initialisation object passed.
        "jQueryUI" : true, // use jQuery ui style
        "ordering" : false, // sorting disabled
        "searching" : false, // filtering disabled
        "scrollY" : sScrolly, // size of the vertical scrollbar in pixels
        "paging" : false
    // pagination enabled
    } );
}

jQuery( document ).ready( function () {

    resEventCount = jQuery( "#resEventCount" ).text();
    resCloseButton = jQuery( "#resCloseButton" ).text();
    resApply = jQuery( "#resApply" ).text();
    resCancel = jQuery( "#resCancel" ).text();
    resHelp = jQuery( "#resHelp" ).text();
    initDatatable();

    jQuery( ".cfgEventIcon" ).tooltip( {
        position : {
            my : "left bottom-2",
            at : "left+20 top"
        },
        show : "fade",
        hide : "fade"
    } );

    jQuery( ".evtbutton" ).click( function () {

        openEventDialog( jQuery( this ) );
    } );

    initEventDialog();
} );

function initEventDialog () {

    var dialog = jQuery( "#eventDialog" ).dialog( {
        resizable : false,
        height : 260,
        width : 700,
        modal : true,
        autoOpen : false,
        closeText : resCloseButton,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        draggable : false,
        iconButtons : [
            {
                text : resHelp,
                icon : "ui-icon-help",
                click : function ( e ) {
                    
                    jQuery( "#aHelpUrl" ).trigger( "click" );
                    
                }
            }
        ],
        buttons : [
                {
                    text : resApply,
                    id : "Apply",
                    click : function () {

                        $form.submit();
                    }
                }, {
                    text : resCancel,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ],
        close : function ( event, ui ) {

            jQuery( this ).dialog( "close" );
        }
    } );

}

function reloadPage () {

    setTimeout( function () {

        self.location.href = '/selectevents';
    }, 3000 );
}

function openEventDialog ( element ) {

    var action = element.attr( "data-action" ), options = {
        "OID" : element.attr( "data-oid" ),
        "Action" : action
    }, parentDiv = jQuery( "#evtCfgData" ), resActionName, req;

    req = jQuery.post( '/DisplayEventDetails', options );
    req.success( function ( data ) {

        parentDiv.empty();
        parentDiv.append( data );
        resActionName = jQuery( '#resActionName' ).html();
        // var help = jQuery('#helpDiv');
        jQuery( '.newbutton' ).button();
        $form = jQuery( "#" + action );
        if ( action == 'Log' ) {
            initLogging();
        }
        else if ( action == 'RunCommandFile' ) {
            initRunCommandFile();
        }
        else if ( action == 'Shutdown' ) {
            initCfgShutdown();
        }
        else if ( action == 'NotifyUsers' ) {
            initNotifyUser();
        }
        jQuery( "#eventDialog" ).dialog( 'option', 'title', resActionName );
        jQuery( "#eventDialog" ).dialog( "open" );
    } );

    req.error( function ( data ) {

        self.location.href = '/';
    } );
}

//validate page upon page load
function validateForm () {

    // force a form validation
    if ( $form.validate().form() ) {
        // if the form is valid we reset it to prevent immediate vaidation on keyup and focusout
        $form.validate().resetForm();
    }
}
