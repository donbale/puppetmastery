var resRequiredFieldValidation, resRangeValidation, resInvalidCommand, dirty;

jQuery( document ).ready( function () {

    var activeAcc = parseInt( jQuery( "#activeAcc" ).val(), 10 );
    if ( isNaN( activeAcc ) ) {
        activeAcc = 0;
    }

    dirty = false;
    resRequiredFieldValidation = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();
    resInvalidCommand = jQuery( "#resInvalidCmdFile" ).text();

    jQuery( "#maindiv" ).accordion( {
        heightStyle : "content",
        active : activeAcc
    } );

    jQuery( "#SingleTurnOff" ).click( function () {

        showHideSingleTurnOffDelay();
        validateForm();
    } );

    jQuery( "#TurnOffNone, #TurnOffUPS, #TurnOffSOG" ).click( function () {

        showHideSingleTurnOffOptions();
        validateForm();
    } );

    jQuery( "#cmdFileDelayCheckbox" ).click( function () {

        showHideCmdFileDelay( jQuery( this ) );
        validateForm();
    } );

    jQuery( "#notifyenablecheckbox" ).click( function () {

        showHideNotificationOptions();
        validateForm();
    } );

    jQuery( "#resetShutdownSettings" ).click( function ( event ) {

        event.preventDefault();
        jQuery( "#shutdownsettingsform" )[ 0 ].reset();
        jQuery( "#shutdownsettingsform" ).validate().resetForm();
        dirty = false;
        showHideSingleTurnOffOptions();
        showHideNotificationOptions();
        showHideCmdFileDelay( jQuery( "#cmdFileDelayCheckbox" ) );
    } );

    // Mark the page as dirty if any input changes.
    jQuery( "input, select" ).change( function ( event ) {

        dirty = true;
    } );

    initValidation();
    showHideSingleTurnOffOptions();
    showHideNotificationOptions();
    showHideCmdFileDelay( jQuery( "#cmdFileDelayCheckbox" ) );
    initWaitDialog();

    window.onbeforeunload = confirmExit;
    validateForm();
} );

function initValidation () {

    jQuery( "#shutdownsettingsform" ).validate( {
        ignore : ".ignore",
        rules : {
            SingleTurnOffDelay : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            CmdFileDuration : {
                required : function ( element ) {

                    return jQuery( "#cmdFilePath" ).val().length > 0;
                },
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            cmdFileDelay : {
                required : function ( element ) {

                    return jQuery( "#cmdFileDelayCheckbox" ).is( ":checked" );
                },
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            notifyInterval : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            cmdFilePath : {
                required : function ( element ) {

                    return jQuery( element ).val().length > 0;
                },
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    data : {
                        formtoken : jQuery( "#formtoken" ).val(),
                        formtokenid : jQuery( "#formtokenid" ).val()
                    }
                }
            }
        },
        messages : {
            SingleTurnOffDelay : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            CmdFileDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            cmdFileDelay : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            notifyInterval : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            cmdFilePath : {
                required : resRequiredFieldValidation,
                remote : resInvalidCommand
            }
        },
        errorContainer : jQuery( "#errorcontainer" ),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            // store active accordion page
            var activeAcc = jQuery( "#maindiv" ).accordion( "option", "active" );
            jQuery( "#activeAcc" ).val( activeAcc );

            // apply button clicked and form validated
            dirty = false;
            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );

    jQuery( "#cmdFilePath" ).change( function () {

        // clear the invalid cmdfile error when it is changed
        jQuery( "#cmdfile_invalid" ).remove();
    } );
}

function showHideSingleTurnOffOptions () {

    if ( jQuery( "#TurnOffNone" ).is( ":checked" ) ) {
        jQuery( "#SingleTurnOffDelay" ).addClass( "ignore" );
        jQuery( "#singleturnoffdiv" ).hide();
    }
    else if ( jQuery( "#TurnOffUPS" ).is( ":checked" ) || jQuery( "#TurnOffSOG" ).is( ":checked" ) ) {
        jQuery( "#singleturnoffdiv" ).show();
        showHideSingleTurnOffDelay();
    }
}

function showHideSingleTurnOffDelay () {

    if ( jQuery( "#SingleTurnOff" ).is( ":checked" ) ) {
        jQuery( "#SingleTurnOffDelay" ).removeClass( "ignore" );
        jQuery( "#singleturnOffdelaydiv" ).show();
    }
    else {
        jQuery( "#SingleTurnOffDelay" ).addClass( "ignore" );
        jQuery( "#singleturnOffdelaydiv" ).hide();
    }
}

function showHideNotificationOptions () {

    if ( jQuery( "#notifyenablecheckbox" ).is( ":checked" ) ) {
        jQuery( "#notifyInterval" ).removeClass( "ignore" );
        jQuery( "#notifysettings" ).show();
    }
    else {
        jQuery( "#notifyInterval" ).addClass( "ignore" );
        jQuery( "#notifysettings" ).hide();
    }
}

function showHideCmdFileDelay ( checkbox ) {

    if ( checkbox.is( ":checked" ) ) {
        jQuery( "#cmdFileDelay" ).removeClass( "ignore" );
        jQuery( "#cmdfiledelayDiv" ).show();
    }
    else {
        jQuery( "#cmdFileDelay" ).addClass( "ignore" );
        jQuery( "#cmdfiledelayDiv" ).hide();
    }
}

// validate page upon page load
function validateForm () {

    // force a form validation
    if ( jQuery( "#shutdownsettingsform" ).validate().form() ) {
        // if the form is valid we reset it to prevent immediate vaidation on
        // keyup and focusout
        jQuery( "#shutdownsettingsform" ).validate().resetForm();
    }
}
