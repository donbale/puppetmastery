var $next, $form, dirty, resRequiredFieldValidation, resValidServerValidation, resAttemptConnection, resNetworkError;
var resPermissionsError, connectionError, doServerCheck;

jQuery( document ).ready( function () {

    dirty = false;
    doServerCheck = false;
    $form = jQuery( "form" );
    $next = jQuery( "#next" );
    connectionError = jQuery( "#connectionError" );
    resRequiredFieldValidation = jQuery( "#requiredSpan" ).text();
    resValidServerValidation = jQuery( "#invalidIpSpan" ).text();
    resAttemptConnection = jQuery( "#attemptConnectionSpan" ).text();
    resNetworkError = jQuery( "#networkErrorSpan" ).text();
    resPermissionsError = jQuery( "#permissionsErrorSpan" ).text();
    initConnectionDialog();
    connectionError.hide();

    jQuery( "#SCVMMIpName" ).on( "propertychange keyup input paste", function () {

        connectionError.hide();
        doServerCheck = true;
    } );

    jQuery( "input" ).change( function () {

        dirty = true;
    } );

    $( "#cancel, #previous" ).addClass( "cancel" );

    $( "#cancel, #previous" ).click( function () {

        doServerCheck = false;
    } );

    jQuery( 'input:radio[name=scvmmManaged]' ).change( function () {

        showHideSCVMMServerIp();
        validateSCVMMForm();
    } );

    window.onbeforeunload = confirmExit;
    initSCVMMValidation();
    showHideSCVMMServerIp();
    validateSCVMMForm();
} );

function showHideSCVMMServerIp () {

    var obj = jQuery( "input:radio[name=scvmmManaged]:checked" );
    if ( obj.length > 0 ) {
        var id = obj.attr( "id" )
        if ( id == "theYes" ) {
            doServerCheck = true;
            jQuery( "#server" ).show();
        }
        else if ( id == "theNo" ) {
            doServerCheck = false;
            jQuery( "#server" ).hide();
        }
    }
    else {
        // none selected
        doServerCheck = false;
        jQuery( "#server" ).hide();
    }
}

function initSCVMMValidation () {

    $form.validate( {
        rules : {
            SCVMMIpName : {
                required : true,
                checkValidServerAddress : true
            }
        },
        messages : {
            SCVMMIpName : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            }
        },
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        invalidHandler : function ( event, validator ) {

            // needed for handling remote validation error
            jQuery( "#next" ).button( 'option', 'disabled', true );
        },
        submitHandler : function ( form ) {

            if ( doServerCheck == true ) {
                // only for next
                checkServerAvailability( function ( result ) {

                    jQuery( "#waitDialog" ).dialog( "close" );
                    if ( result == true ) {
                        dirty = false;
                        window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                        doServerCheck = false;
                        $form.submit();
                    }
                } );
            }
            else {
                dirty = false;
                window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                form.submit();
            }
        }

    } );
    jQuery.validator.addMethod( "checkValidServerAddress", function ( address, element ) {

        var result = isValidServerAddress( address );
        jQuery( "#next" ).button( 'option', 'disabled', !result );
        return this.optional( element ) || result;
    } );

}

function updateButtons () {

    var isOptionSelected = jQuery( "input:radio[name=scvmmManaged]:checked" ).length > 0;
    if ( $form.validate().numberOfInvalids() > 0 || !isOptionSelected ) {
        $next.button( 'option', 'disabled', true );
    }
    else {
        $next.button( 'option', 'disabled', false );
    }
}

function validateSCVMMForm () {

    if ( $form.validate().form() ) {
        $form.validate().resetForm();
    }

    updateButtons();
}

// cfgwizard.js override to prevent Next button enabled with validation errors
function initValidation () {

    // This does the cookies check
    loginOnLoad();
}

function checkServerAvailability ( callback ) {

    connectionError.hide();

    jQuery( ".connectionDialog" ).dialog( "open" );
    var req = jQuery.post( "/AJAXCheckHostConnection", $form.serialize() );
    var isValid = false;
    req.success( function ( result ) {

        if ( result != null ) {
            isValid = result.isValid;
        }
        if ( isValid == 0 ) {
            connectionError.text( resNetworkError );
            connectionError.show();
            jQuery( ".connectionDialog" ).dialog( "close" );
        }
        else if ( isValid == -1 ) {
            connectionError.text( resPermissionsError );
            connectionError.show();
            jQuery( ".connectionDialog" ).dialog( "close" );
        }
        else {
            setTimeout( function () {

                jQuery( ".connectionDialog" ).dialog( "close" );
            }, 2000 );
        }
        callback( isValid );
    } );

    req.error( function ( data ) {

        connectionError.show();
        jQuery( ".connectionDialog" ).dialog( "close" );
        return callback( false );
    } );
}

function initConnectionDialog () {

    jQuery( ".connectionDialog" ).dialog( {
        height : 140,
        width : 300,
        modal : true,
        closeOnEscape : false,
        closeText : "hide",
        resizable : false,
        draggable : false,
        autoOpen : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function () {

            var thisRef = $( this );
            // remove close button
            thisRef.parents( ".ui-dialog:first" ).find( ".ui-dialog-titlebar-close" ).remove();
            // set hourglass cursor
            thisRef.parents().find( ".ui-widget-overlay:first, .ui-dialog:first" ).css( "cursor", "wait" );
        }
    } );
}
