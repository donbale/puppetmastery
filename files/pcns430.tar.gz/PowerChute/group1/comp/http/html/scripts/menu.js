var resCloseButton, resAboutTitle;
jQuery( document ).ready( function () {

    resCloseButton = jQuery( "#resCloseButton" ).text();
    resAboutTitle = jQuery( "#resAboutTitle" ).text();
    jQuery( "#menu div.mainlevel" ).click( function ( event ) {

        var thisRef = jQuery( this ), menuLink = thisRef.children( "a.mainlevel" );

        if ( menuLink.hasClass( "closedmenu" ) ) {
            menuLink.removeClass( "closedmenu" ).addClass( "openmenu" );
            thisRef.next( "ul.menuList" ).removeClass( "closedmenu" ).addClass( "openmenu" );
        }
        else {
            menuLink.removeClass( "openmenu" ).addClass( "closedmenu" );
            thisRef.next( "ul.menuList" ).removeClass( "openmenu" ).addClass( "closedmenu" );
        }

        event.stopImmediatePropagation();
        event.preventDefault();
    } );

    if ( !jQuery( "#menu" ).hasClass( "japanese" ) ) {
        initAJAXStatusIconTray();
    }
    initAboutDialog();
    jQuery( "#about" ).click( function () {

        jQuery( "#aboutDialog" ).dialog( "open" );
    } );
} );

function initAboutDialog () {

    jQuery( "#aboutDialog" ).dialog( {
        height : 550,
        modal : false,
        width : 620,
        closeOnEscape : true,
        closeText : resCloseButton,
        title : resAboutTitle,
        resizable : false,
        draggable : true,
        autoOpen : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function () {

            jQuery( "#aboutContainer" ).load( 'about.html' );
        },
        buttons : [
            {
                text : resCloseButton,
                click : function () {

                    jQuery( this ).dialog( "close" );
                }
            }
        ]
    } );
}
