jQuery( document ).ready( function () {

    jQuery( "input[name=user]" ).focus();
    loginOnLoad();
} );
