var oTable = null;
var resAgentCount, resNoAgents, resAgents, resProcessing;
var agentsUrl = "/AJAXConnectedServers";

function initDatatable () {

    var sScrolly = "420px"; // fitting menu's height

    oTable = jQuery( "#servers" ).DataTable( {
        "language" : {
            "infoEmpty" : "",
            "info" : resAgentCount,
            "zeroRecords" : resNoAgents,
            "infoFiltered" : "",
            "processing" : resProcessing
        },
        "dom" : 'RC<"H"lfrip>t', // Specify exactly where in the DOM you want DataTables to inject the various
                                    // controls: http://datatables.net/usage/options#sDom
        "serverSide" : true,
        "destroy" : true,
        "jQueryUI" : true,
        "ordering" : false,
        "searching" : false,
        "scrollY" : sScrolly,
        "stateSave" : true,
        "paging" : false,
        "processing" : true,
        "ajax" : {
            "dataType" : 'json',
            "type" : "POST",
            "dataSrc" : "data",
            "url" : agentsUrl,
            "data" : function ( d ) {

                return $.extend( {}, d, {
                    "formtoken" : jQuery( "#formtoken" ).val(),
                    "formtokenid" : jQuery( "#formtokenid" ).val()
                } );
            },
            "error" : function ( data ) {

                jQuery( "#servers_processing" ).hide();
            },
            "timeout" : 30000
        }
    } );
}

jQuery( document ).ready( function () {

    resAgentCount = jQuery( "#resAgentCount" ).text();
    resNoAgents = jQuery( "#resNoAgents" ).text();
    resAgents = jQuery( "#resAgents" ).text();
    resProcessing = jQuery( "#resProcessing" ).text();
    initDatatable();
} );
