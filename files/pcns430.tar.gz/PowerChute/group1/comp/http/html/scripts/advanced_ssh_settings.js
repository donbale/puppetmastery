jQuery(document).ready(function() {
    jQuery("#resetButton").click(function() {
        jQuery("#advancedsshsettingsForm")[0].reset();
        jQuery("#advancedsshsettingsForm").validate().resetForm();
        
    });
    
    initWaitDialog();
    
    jQuery("#apply").click(function() {
        jQuery("#waitDialog").dialog("open");
        jQuery("#advancedsshsettingsForm").submit();
    });
    
    updateNoActions();
    
    jQuery(".checkbox").click(function() {
        updateSelActionNotEnabled();
    });
    updateSelActionNotEnabled();
 
    
    
});

function updateNoActions() {
    if (jQuery("#actionsList li").length > 0) {
        jQuery("#noActionsToSelectDiv").hide();
        jQuery("#resetButton").show();
        jQuery("#apply").show();
    } else {
        jQuery("#noActionsToSelect").show();
        jQuery("#resetButton").hide();
        jQuery("#apply").hide();
    }
}

function updateSelActionNotEnabled() {
    var sshActions = jQuery("#actionsList li");
    
    jQuery("#selActionNotEnabled").hide();
        
    for (var i =0; i < sshActions.length; i++) {
        var isActionEnabled = jQuery(sshActions[i]).find('img').length;
        var isActionSelected = jQuery(sshActions[i]).find(".checkbox:checked").length;
        
        if(isActionEnabled < isActionSelected) {
            jQuery("#selActionNotEnabled").show();
            break;
        } 
    }   
}