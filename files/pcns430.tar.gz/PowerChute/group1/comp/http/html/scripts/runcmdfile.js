var resRequiredFieldValidation, resRangeValidation, resInvalidCmdFile;
var $form = null;

jQuery( document ).ready( function () {

} );

function initRunCommandFile () {

    $form = jQuery( "#RunCommandFile" );
    $delay = jQuery( "#Delay" );
    $param = jQuery( "#paramValue" );
    $interval = jQuery( "#Interval" );
    $cmdFilePath = jQuery( "#cmdFilePath" );
    resRequiredFieldValidation = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();
    resInvalidCmdFile = jQuery( "#resInvalidCmdFile" ).text();

    jQuery( ".newbutton" ).button();

    jQuery( "#Enable" ).click( function () {

        jQuery( "#cmdfile_invalid" ).remove();
        showHideRunCmdFileOptions();
    } );

    initRunCmdFileValidation();
    showHideRunCmdFileOptions();

    initWaitDialog();
    validateForm();
}

function initRunCmdFileValidation () {

    $form.validate( {
        ignore : ".ignore",
        rules : {
            Interval : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            Delay : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            paramValue : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            cmdFilePath : {
                required : function ( element ) {

                    return jQuery( "#Enable" ).is( ":checked" );
                },
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    data : {
                        formtoken : jQuery( "#formtoken" ).val(),
                        formtokenid : jQuery( "#formtokenid" ).val()
                    }
                }
            }
        },
        messages : {
            Interval : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            Delay : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            paramValue : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            cmdFilePath : {
                required : resRequiredFieldValidation,
                remote : resInvalidCmdFile
            },
        },
        // errorContainer: jQuery("#errorcontainer"),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );

    jQuery( "#cmdFilePath" ).change( function () {

        // clear the invalid cmdfile error when it is changed
        jQuery( "#cmdfile_invalid" ).remove();
    } );
}

function showHideRunCmdFileOptions () {

    if ( jQuery( "#Enable" ).is( ":checked" ) ) {
        jQuery( "#settingsdiv" ).show();
        $delay.removeClass( "ignore" );
        $param.removeClass( "ignore" );
        $interval.removeClass( "ignore" );
        $cmdFilePath.removeClass( "ignore" );
        $form.validate().resetForm();
    }
    else {
        $delay.addClass( "ignore" );
        $param.addClass( "ignore" );
        $interval.addClass( "ignore" );
        $cmdFilePath.addClass( "ignore" );
        jQuery( "#settingsdiv" ).hide();
    }
}
