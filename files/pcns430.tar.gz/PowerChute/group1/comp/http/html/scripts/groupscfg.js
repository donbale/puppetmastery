var dirty, resRequiredFieldValidation, resRangeValidation, resInvalidCommandFileValidation, $form, $next;

jQuery( document ).ready( function () {

    dirty = false;
    resRequiredFieldValidation = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();
    resInvalidCommandFileValidation = jQuery( "#resInvalidCommandFileValidation" ).text();
    $form = jQuery( "form" );
    $next = jQuery( "#next" );

    var activeAcc = parseInt( jQuery( "#activeAcc" ).val(), 10 );
    if ( isNaN( activeAcc ) ) {
        activeAcc = 0;
    }

    jQuery( "input, select" ).change( function () {

        dirty = true;
    } );

    jQuery( "#maindiv" ).accordion( {
        heightStyle : "content",
        active : activeAcc
    } );

    jQuery( "#notifyenablecheckbox" ).change( function () {

        showHideNotificationOptions();
        validateGroupsForm();
    } );

    jQuery( ".cmdFileCheckbox" ).change( function () {

        showHideCmdFile( jQuery( this ) );
        validateGroupsForm();
    } );

    jQuery( ".cmdFileDelayCheckbox" ).change( function () {

        showHideCmdFileDelay( jQuery( this ) );
        validateGroupsForm();
    } );

    jQuery( ".shutdownVirtualHostsCheckbox" ).change( function () {

        var thisRef = jQuery( this );
        updateLocalMachineCheckbox( thisRef );
        if ( thisRef.hasClass( "physical" ) ) {
            showHideCmdFile( thisRef.parents( ".labelvaluediv" ).prevAll( ".cmdFileCheckboxDiv" ).find( "input" ) );
        }

        validateGroupsForm();
    } );

    jQuery( ".shutdownLocalMachineCheckbox" ).change( function () {

        updateShutdownWarning( jQuery( this ) );
    } );

    jQuery( "#previous" ).addClass( "cancel" );
    jQuery( "#cancel" ).addClass( "cancel" ).click( function () {

        $form[ 0 ].reset();
        $form.validate().resetForm();
        dirty = false;
        updateCmdFile();
        showHideNotificationOptions();
    } );

    jQuery( "#resetShutdownSettings" ).click( function ( event ) {

        event.preventDefault();
        $form[ 0 ].reset();
        $form.validate().resetForm();
        dirty = false;
        updateRedundancySettings();
        updateCmdFile();
        showHideNotificationOptions();
        updateVirtualHostsCheckbox();
        validateGroupsForm();
    } );

    jQuery( ".upsRequiredDiv select" ).change( function () {

        updateNoOfRedundantUPSSetting( jQuery( this ) );
    } );

    showHideShutdownWarning();
    initFormValidation();
    updateCmdFile();
    showHideNotificationOptions();
    updateRedundancySettings();
    updateVirtualHostsCheckbox();
    validateGroupsForm();
    initWaitDialog();
    window.onbeforeunload = confirmExit;
} );

function showHideShutdownWarning () {

    jQuery( ".shutdownLocalMachineCheckbox" ).each( function ( i ) {

        updateShutdownWarning( jQuery( this ) );
    } );
}

function updateShutdownWarning ( checkbox ) {

    var warningDiv = checkbox.closest( ".labelvaluediv" ).parent().find( ".pcnsWarning" );
    if ( checkbox.is( ":checked" ) ) {
        warningDiv.hide();
    }
    else {
        warningDiv.show();
    }
}

function updateCmdFile () {

    jQuery( ".cmdFileCheckbox" ).each( function ( i ) {

        showHideCmdFile( jQuery( this ) );
    } );
}

function showHideCmdFile ( checkbox ) {

    var pathDiv = checkbox.parents( ".labelvaluediv" ).next(), durationDiv = pathDiv.next(), pathInput = pathDiv
            .find( "input" ), durationInput = durationDiv.find( "input" ), shutdownVirtualHostsCheckbox = durationDiv
            .parent().find( ".shutdownVirtualHostsCheckbox" ), shutdownVirtualHosts = true, physical = false, delayDiv = durationDiv
            .next( ".cmfFileDelayDiv" ), delayCheckbox, delayInput;

    if ( shutdownVirtualHostsCheckbox.length > 0 ) {
        shutdownVirtualHosts = shutdownVirtualHostsCheckbox.is( ":checked" );
        physical = shutdownVirtualHostsCheckbox.hasClass( "physical" )
    }

    if ( delayDiv.length > 0 ) {
        delayCheckbox = delayDiv.find( ".cmdFileDelayCheckbox" );
        delayInput = delayDiv.find( ".cmdfiledelay" );
    }

    if ( checkbox.is( ":checked" ) ) {
        pathInput.removeClass( "ignore" );
        durationInput.removeClass( "ignore" );
        pathDiv.show();
        durationDiv.show();
        if ( delayDiv.length > 0 ) {
            if ( physical ) {
                if ( shutdownVirtualHosts ) {
                    showHideCmdFileDelay( delayCheckbox );
                    delayDiv.show();
                }
                else {
                    delayInput.addClass( "ignore" );
                    delayDiv.hide();
                }
            }
            else {
                showHideCmdFileDelay( delayCheckbox );
                delayDiv.show();
            }
        }
    }
    else {
        pathInput.addClass( "ignore" );
        durationInput.addClass( "ignore" );
        pathDiv.hide();
        durationDiv.hide();
        if ( delayDiv.length > 0 ) {
            delayInput.addClass( "ignore" );
            delayDiv.hide();
        }
    }
}

function showHideCmdFileDelay ( checkbox ) {

    var delayInputDiv = checkbox.parents( ".labelvaluediv" ).next(), delayInput = delayInputDiv.find( "input" );

    if ( checkbox.is( ":checked" ) ) {
        delayInput.removeClass( "ignore" );
        delayInputDiv.show();
    }
    else {
        delayInput.addClass( "ignore" );
        delayInputDiv.hide();
    }
}

function showHideNotificationOptions () {

    if ( jQuery( "#notifyenablecheckbox" ).is( ":checked" ) ) {
        jQuery( "#notifyInterval" ).removeClass( "ignore" );
        jQuery( "#notifysettings" ).show();
    }
    else {
        jQuery( "#notifyInterval" ).addClass( "ignore" );
        jQuery( "#notifysettings" ).hide();
    }
}

function updateRedundancySettings () {

    updateNoOfRedundantUPSSetting( jQuery( ".upsRequiredDiv select" ) );
}

function updateNoOfRedundantUPSSetting ( upsRequiredInput ) {

    var upsRequired, upsRedundantDiv, redundancyLostDiv, upsTotal, thisRef;
    upsRequiredInput.each( function () {

        thisRef = jQuery( this );
        upsRequired = parseInt( thisRef.val(), 10 );
        upsRedundantDiv = thisRef.parents( ".labelvaluediv" ).next();
        upsTotal = parseInt( upsRedundantDiv.next().find( ".value" ).text(), 10 );
        upsRedundantDiv.find( ".value" ).text( upsTotal - upsRequired );
        redundancyLostDiv = upsRedundantDiv.nextAll( ".redundancyLostDiv" )
        if ( upsRequired < upsTotal ) {
            redundancyLostDiv.show();
        }
        else {
            redundancyLostDiv.hide();
        }
    } );
}

function updateVirtualHostsCheckbox () {

    jQuery( ".shutdownVirtualHostsCheckbox" ).each( function ( i ) {

        updateLocalMachineCheckbox( jQuery( this ) );
    } );
}

function updateLocalMachineCheckbox ( virtualhostscheckbox ) {

    var localmachinediv = virtualhostscheckbox.closest( ".labelvaluediv" ).prev( ".labelvaluediv" );
    var localmachinecheckbox = localmachinediv.find( ".shutdownLocalMachineCheckbox" );
    var localmachinelabel = localmachinediv.find( "label" );
    var warningDiv = virtualhostscheckbox.closest( ".labelvaluediv" ).parent().find( ".pcnsWarning" );
    if ( virtualhostscheckbox.is( ":checked" ) ) {
        localmachinecheckbox.removeAttr( "disabled" );
        localmachinelabel.removeClass( "disabled" );
        if ( localmachinecheckbox.is( ":checked" ) ) {
            warningDiv.hide();
        }
        else {
            warningDiv.show();
        }
    }
    else {
        localmachinecheckbox.removeAttr( "checked" );
        localmachinecheckbox.attr( "disabled", "disabled" );
        localmachinelabel.addClass( "disabled" );
        warningDiv.hide();
    }
}

function initFormValidation () {

    jQuery.validator.addClassRules( "cmdfilepath", {
        required : function ( element ) {

            return jQuery( element ).parents( ".labelvaluediv" ).prevAll().find( ".cmdFileCheckbox" ).is( ":checked" );
        },
        remote : {
            url : "/verifyfile",
            type : "post",
            data : {
                formtoken : jQuery( "#formtoken" ).val(),
                formtokenid : jQuery( "#formtokenid" ).val()
            }
        }
    } );

    jQuery.validator.addClassRules( "cmdfileduration", {
        required : function ( element ) {

            return jQuery( element ).parents( ".labelvaluediv" ).prevAll().find( ".cmdFileCheckbox" ).is( ":checked" );
        },
        range : [
                0, 172800
        ],
        digits : [
                0, 172800
        ]
    } );

    jQuery.validator.addClassRules( "cmdfiledelay", {
        required : function ( element ) {

            return jQuery( element ).parents( ".labelvaluediv" ).prevAll().find( ".cmdFileDelayCheckbox" ).is(
                    ":checked" );
        },
        range : [
                0, 172800
        ],
        digits : [
                0, 172800
        ]
    } );

    $form.validate( {
        ignore : ".ignore",
        rules : {
            notifyInterval : {
                required : true,
                range : [
                        0, 7200
                ],
                digits : [
                        0, 7200
                ]
            }
        },
        messages : {
            notifyInterval : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            }
        },
        onkeyup : function ( element, event ) {

            if ( $next.length > 0 ) {
                jQuery( element ).valid();
                updateButtons();
            }
            else {
                jQuery.validator.defaults.onkeyup.call( this, element, event );
            }
        },
        onfocusout : function ( element, event ) {

            if ( $next.length > 0 ) {
                jQuery( element ).valid();
                updateButtons();
            }
            else {
                jQuery.validator.defaults.onfocusout.call( this, element, event );
            }
        },
        errorContainer : jQuery( "#errorcontainer" ),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            // store active accordion page
            var activeAcc = jQuery( "#maindiv" ).accordion( "option", "active" );
            jQuery( "#activeAcc" ).val( activeAcc );

            // apply button clicked and form validated
            dirty = false;
            window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );

    jQuery( ".cmdfilepath" ).each( function () {

        jQuery( this ).rules( "add", {
            messages : {
                required : resRequiredFieldValidation,
                remote : resInvalidCommandFileValidation
            }
        } );
    } );

    jQuery( ".cmdfileduration" ).each( function () {

        jQuery( this ).rules( "add", {
            messages : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            }
        } );
    } );

    jQuery( ".cmdfiledelay" ).each( function () {

        jQuery( this ).rules( "add", {
            messages : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            }
        } );
    } );
}

function updateButtons () {

    if ( $next.length > 0 ) {
        if ( $form.validate().numberOfInvalids() > 0 ) {
            $next.button( 'option', 'disabled', true );
        }
        else {
            $next.button( 'option', 'disabled', false );
        }
    }
}

function validateGroupsForm () {

    if ( $form.validate().form() ) {
        $form.validate().resetForm();
    }

    updateButtons();
}

//cfgwizard.js override to prevent Next button enabled with no groups configured
function initValidation () {

    // This does the cookies check
    loginOnLoad();
}
