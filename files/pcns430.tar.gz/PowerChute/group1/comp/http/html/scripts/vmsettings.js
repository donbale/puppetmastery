var resRequiredFieldValidation, resRangeValidation, resDigitsValidation, $form, $next, $apply, $reset, $hyperVData, isHyperV, isManaged, $res, isNutanixAHV;

jQuery(document).ready(function() {
    initialize();
});

function initialize() {
    $form = jQuery("form");
    $next = jQuery("#next");
    $res = jQuery("#res");
    isManaged = false;

    isNutanixAHV = jQuery("#isNutanixAHV").length > 0;
    $hyperVData = jQuery("#hyperVData");
    isHyperV = ($hyperVData.length > 0);
    if (isHyperV) {
        isManaged = $hyperVData.attr("data-managed");
    }

    $apply = jQuery("#applyVMSettings");
    $reset = jQuery("#resetVMSettings");
    if (isHyperV == true) {
        initClusterDialog();
        jQuery("#checkClusterDialog").dialog("open");
        $next.button('option', 'disabled', true);
        $apply.hide();
        $reset.hide();
        displayHyperVVMSettings();
    } else {
        initSettings();
        initVCenterCheckingDialog();
        if ($res.length > 0) {
            jQuery("#checkConnectionDialog").dialog("open");
            loadPage();
        }
        jQuery("#checkConnectionDialog").dialog("open");
        loadDRS();

    }
}

function initSettings() {
    var activeAcc = parseInt(jQuery("#activeAcc").val(), 10);

    if (isNaN(activeAcc)) {
        activeAcc = 0;
    }

    dirty = false;
    resRequiredFieldValidation = jQuery("#resRequiredFieldValidation").text();
    resRangeValidation = jQuery("#resRangeValidation").text();
    resDigitsValidation = jQuery("#resDigitsValidation").text();

    jQuery("#maindiv").accordion({
        heightStyle : "content",
        active : activeAcc
    });

    jQuery("#previous").addClass("cancel");
    jQuery("#cancel").addClass("cancel").click(function() {
        $form[0].reset();
        $form.validate().resetForm();
        dirty = false;
        showHideVMMigrationOptions();
        showHideVAppStartupOptions();
        if (isNutanixAHV) {
            showHideVMStartupDuration();
        } else {
            showHideVMStartupOptions();
        }
        showHideCvmStartupDuration();
        showHideAfsShutdownOptions();
        showHideOngoingReplicationAbortDelayDuration();
    });

    jQuery("#resetVMSettings").click(function(event) {
        $form[0].reset();
        $form.validate().resetForm();
        dirty = false;
        showHideVMMigrationOptions();
        showHideVAppStartupOptions();
        if (isNutanixAHV) {
            showHideVMStartupDuration();
        } else {
            showHideVMStartupOptions();
        }
        showHideCvmStartupDuration();
        showHideAfsShutdownOptions();
        showHideOngoingReplicationAbortDelayDuration();

        if (isHyperV || jQuery("#multitree").length > 0) {
            jQuery("#waitDialog").dialog("open");
            createHiddenInputField("resetVMSettings", "resetVMSettings");
            $form.submit();
        }
    });

    if (!(isHyperV || jQuery("#multitree").length > 0)) {
        jQuery("#resetVMSettings").addClass("cancel");
    }

    jQuery("#hvstopclustercheckbox").click(function() {
        showHideStopCluster();
        validateVMSettingsForm();
    });

    jQuery("#vmmigrationcheckbox").click(function() {
        showHideVMMigrationOptions();
        validateVMSettingsForm();
    });

    jQuery("#vmmigrationtargetcheckbox").click(function() {
        showHideMigrationTargetHosts();
        validateVMSettingsForm();
    });

    if (!isNutanixAHV) {
        jQuery("#vmshutdowncheckbox").click(function() {
            showHideVMStartupOptions();
            validateVMSettingsForm();
        });
    }

    jQuery("#vmstartupcheckbox").click(function() {
        showHideVMStartupDuration();
        validateVMSettingsForm();
    });

    jQuery("#vappshutdowncheckbox").click(function() {
        showHideVAppStartupOptions();
        validateVMSettingsForm();
    });

    jQuery("#vappstartupcheckbox").click(function() {
        showHideVAppStartupDuration();
        validateVMSettingsForm();
    });

    jQuery("#vmenableHostMaintenance").click(function() {
        showHideSCVMMOptions();
        validateVMSettingsForm();
    });

    jQuery("#delayMaintModeCheckbox").click(function() {
        showHideDelayMaintenanceModeOptions();
        showHideVMMigrationOptions();
        validateVMSettingsForm();
    });
    jQuery("#enableFTTCheckbox").click(function() {
        showHideFTTOptions();
        validateVMSettingsForm();
    });

    jQuery("#cvmstartupcheckbox").click(function() {
        showHideCvmStartupDuration();
        validateVMSettingsForm();
    });

    jQuery("#afsshutdowncheckbox").click(function() {
        showHideAfsShutdownOptions();
        validateVMSettingsForm();
    });

    jQuery("#afsstartupcheckbox").click(function() {
        showHideAfsStartupDuration();
        validateVMSettingsForm();
    });

    jQuery("#ongoingreplicationabortdelaycheckbox").click(function() {
        showHideOngoingReplicationAbortDelayDuration();
        validateVMSettingsForm();
    });

    initFormValidation();
    showHideVMMigrationOptions();
    if (isNutanixAHV) {
        showHideVMStartupDuration();
    } else {
        showHideVMStartupOptions();
    }
    showHideStopCluster();
    showHideSCVMMOptions();
    showHideDelayMaintenanceModeOptions();
    showHideFTTOptions();
    showHideCvmStartupDuration();
    showHideAfsShutdownOptions();
    showHideOngoingReplicationAbortDelayDuration();
    initWaitDialog();
    initializeCheckboxes();
    validateVMSettingsForm();
}

function initFormValidation() {
    var maxFTTValue = parseInt(jQuery(".maxFTTValue").val());
    $form.validate({
        ignore : ".ignore",
        rules : {
            vSanFTTLevel : {
                required : function(element) {

                    return jQuery("#enableFTTCheckbox").is(":checked");
                },
                range : [
                        0, maxFTTValue
                ],
                digits : true

            },
            vSanSyncTimeout : {
                required : function(element) {

                    return jQuery("#enableFTTCheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            vmmigrationDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            vmshutdownDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            vmstartupDuration : {
                required : function(element) {

                    return jQuery("#vmstartupcheckbox").is(":checked") && jQuery("#vmshutdowncheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            vappshutdownDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            vappstartupDuration : {
                required : function(element) {

                    return jQuery("#vappstartupcheckbox").is(":checked") && jQuery("#vappshutdowncheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            vcsashutdownDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            vmmaintenanceDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            vmHostMaintenanceDelayTimeout : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            cvmShutdownDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            cvmStartupDuration : {
                required : function(element) {

                    return jQuery("#cvmstartupcheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            afsShutdownDuration : {
                required : function(element) {

                    return jQuery("#afsshutdowncheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            afsStartupDuration : {
                required : function(element) {

                    return jQuery("#afsstartupcheckbox").is(":checked") && jQuery("#afsshutdowncheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            ongoingReplicationAbortDelayDuration : {
                required : function(element) {

                    return jQuery("#ongoingreplicationabortdelaycheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            clusterShutdownDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            clusterStartupDuration : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : true
            },
            hvStopClusterDuration : {
                required : function(element) {
                    return jQuery("#hvstopclustercheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            },
            hvStartClusterDuration : {
                required : function(element) {
                    return jQuery("#hvstopclustercheckbox").is(":checked");
                },
                range : [
                        0, 172800
                ],
                digits : true
            }

        },
        messages : {
            vSanFTTLevel : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vSanSyncTimeout : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vmmigrationDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vmshutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vmstartupDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vappshutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vappstartupDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vcsashutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vmmaintenanceDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            vmHostMaintenanceDelayTimeout : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            cvmShutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            cvmStartupDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            afsShutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            afsStartupDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            ongoingReplicationAbortDelayDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            clusterShutdownDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            clusterStartupDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            hvStopClusterDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            },
            hvStartClusterDuration : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resDigitsValidation
            }
        },
        onkeyup : function(element, event) {

            if ($next.length > 0) {
                jQuery(element).valid();
                updateButtons();
            } else {
                jQuery.validator.defaults.onkeyup.call(this, element, event);
            }
        },
        onfocusout : function(element, event) {

            if ($next.length > 0) {
                jQuery(element).valid();
                updateButtons();
            } else {
                jQuery.validator.defaults.onfocusout.call(this, element, event);
            }
        },
        errorContainer : jQuery("#errorcontainer"),
        errorPlacement : function(error, element) {

            // display error message after the label-value-pair row
            error.appendTo(element.closest(".labelvaluediv"));
        },
        submitHandler : function(form) {

            // store active accordion page
            var activeAcc = jQuery("#maindiv").accordion("option", "active");
            jQuery("#activeAcc").val(activeAcc);

            // apply button clicked and form validated
            dirty = false;
            window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
            postTargetHosts();
            jQuery("#waitDialog").dialog("open");
            form.submit();
        }
    });
}

function showHideDelayMaintenanceModeOptions() {

    if (jQuery("#delayMaintModeCheckbox").is(":checked")) {
        jQuery("#vmHostMaintenanceDelayTimeout").removeClass("ignore");
        jQuery("#hostMaintModeDurationDiv").show();
    } else {
        jQuery("#vmHostMaintenanceDelayTimeout").addClass("ignore");
        jQuery("#hostMaintModeDurationDiv").hide();
    }
}

function showHideSCVMMOptions() {

    if (jQuery("#vmenableHostMaintenance").is(":checked")) {
        jQuery("#vmmaintenanceDuration").removeClass("ignore");
        jQuery("#hostMaintenanceDurationDiv").show();
    } else {
        jQuery("#vmmaintenanceDuration").addClass("ignore");
        jQuery("#hostMaintenanceDurationDiv").hide();
    }

}

function postTargetHosts() {

    // Hyper-V stand-alone host migration target hosts
    jQuery("#mappedlist li.host").each(function() {

        createHiddenInputField("targetHost", jQuery(this).attr("lnk"));
    });
}

function createHiddenInputField(name, value) {

    var html = '<input type="hidden" name="' + name + '" value="' + value + '"/>';
    $form.append(html);
}

function showHideCvmStartupDuration() {
    if (jQuery("#cvmstartupcheckbox").is(":checked")) {
        jQuery("#cvmStartupDuration").removeClass("ignore");
        jQuery("#cvmStartupDurationDiv").show();
    } else {
        jQuery("#cvmStartupDuration").addClass("ignore");
        jQuery("#cvmStartupDurationDiv").hide();
    }
}

function showHideAfsShutdownOptions() {
    if (jQuery("#afsshutdowncheckbox").is(":checked")) {
        jQuery("#afsShutdownDuration").removeClass("ignore");
        jQuery("#afsShutdownDurationDiv").show();
        jQuery("#nutanixAFSDisabledWarning").hide();
        jQuery("#afsStartupEnableDiv").show();
        jQuery("#afsstartupcheckbox").prop('checked', true);
        if (jQuery("#afsstartupcheckbox").is(":checked")) {
            jQuery("#afsStartupDuration").removeClass("ignore");
            jQuery("#afsStartupDurationDiv").show();
        } else {
            jQuery("#afsStartupDuration").addClass("ignore");
            jQuery("#afsStartupDurationDiv").hide();
        }
    } else {
        jQuery("#afsShutdownDuration").addClass("ignore");
        jQuery("#afsStartupDuration").addClass("ignore");
        jQuery("#afsShutdownDurationDiv").hide();
        jQuery("#nutanixAFSDisabledWarning").show();
        jQuery("#afsstartupcheckbox").prop('checked', false);
        jQuery("#afsStartupDurationDiv").hide();
    }
}

function showHideAfsStartupDuration() {
    if (jQuery("#afsstartupcheckbox").is(":checked")) {
        jQuery("#afsStartupDuration").removeClass("ignore");
        jQuery("#afsStartupDurationDiv").show();
    } else {
        jQuery("#afsStartupDuration").addClass("ignore");
        jQuery("#afsStartupDurationDiv").hide();
    }
}

function showHideOngoingReplicationAbortDelayDuration() {
    if (jQuery("#ongoingreplicationabortdelaycheckbox").is(":checked")) {
        jQuery("#ongoingReplicationAbortDelayDuration").removeClass("ignore");
        jQuery("#ongoingReplicationAbortDelayDurationDiv").show();
        jQuery("#nutanixPDDisabledWarning").hide();
    } else {
        jQuery("#ongoingReplicationAbortDelayDuration").addClass("ignore");
        jQuery("#ongoingReplicationAbortDelayDurationDiv").hide();
        jQuery("#nutanixPDDisabledWarning").show();
    }
}

function showHideVMMigrationOptions() {
    if (jQuery("#vmmigrationcheckbox").is(":checked")) {
        jQuery("#vmmigrationWarn").hide();
        jQuery("#vmmigrationDuration").removeClass("ignore");
        jQuery("#vmmigrationDurationDiv").show();
        jQuery("#theVMMigrationTargetEnabledDiv").show();
        if (jQuery("#vmmigrationtargetcheckbox").is(":checked")) {
            jQuery("#multitree").show();
            jQuery("#hostListsContainer").show();
        } else {
            jQuery("#multitree").hide();
            jQuery("#hostListsContainer").hide();
        }
    } else {
        if (jQuery("#isDRSFullyAuto").text() == "true" && !(jQuery("#delayMaintModeCheckbox").is(":checked"))) {
            jQuery("#vmmigrationWarn").show();
        } else {
            jQuery("#vmmigrationWarn").hide();
        }
        jQuery("#vmmigrationDuration").addClass("ignore");
        jQuery("#vmmigrationTargetHost").addClass("ignore");
        jQuery("#vmmigrationDurationDiv").hide();
        jQuery("#theVMMigrationTargetEnabledDiv").hide();
        jQuery("#multitree").hide();
        jQuery("#hostListsContainer").hide();
    }
}

function showHideFTTOptions() {
    if (jQuery("#enableFTTCheckbox").is(":checked")) {
        jQuery("#fttLevelDiv").show();
        jQuery("#vSanFTTLevel").removeClass("ignore");

        jQuery("#shutdownAllClusterVMsDiv").show();
        jQuery("#shutdownAllClusterVMsCheckbox").removeClass("ignore");
    } else {
        jQuery("#fttLevelDiv").hide();
        jQuery("#vSanFTTLevel").addClass("ignore");

        jQuery("#shutdownAllClusterVMsDiv").hide();
        jQuery("#shutdownAllClusterVMsCheckbox").addClass("ignore");
    }
}
function showHideVMStartupOptions() {
    if (jQuery("#vmshutdowncheckbox").is(":checked")) {
        jQuery("#vmshutdownDuration").removeClass("ignore");
        jQuery("#vmshutdownDurationDiv").show();
        jQuery("#forcevappshutdownEnableDiv").show();
        jQuery("#vmstartupEnableDiv").show();
        if (jQuery("#vmstartupcheckbox").is(":checked")) {
            jQuery("#vmstartupDuration").removeClass("ignore");
            jQuery("#vmstartupDurationDiv").show();
        } else {
            jQuery("#vmstartupDuration").addClass("ignore");
            jQuery("#vmstartupDurationDiv").hide();
        }
    } else {
        jQuery("#vmshutdownDuration").addClass("ignore");
        jQuery("#vmstartupDuration").addClass("ignore");
        jQuery("#vmshutdownDurationDiv").hide();
        jQuery("#vmstartupEnableDiv").hide();
        jQuery("#vmstartupDurationDiv").hide();
        jQuery("#forcevappshutdownEnableDiv").hide();
    }
}

function showHideStopCluster() {
    if (jQuery("#hvstopclustercheckbox").is(":checked")) {

        jQuery("#hvstopclusterDuration").removeClass("ignore");
        jQuery("#hvstopclusterDurationDiv").show();

        jQuery("#hvstartclusterDuration").removeClass("ignore");
        jQuery("#hvstartclusterDurationDiv").show();

        jQuery("#maindiv").accordion("option", {
            active : 2
        });

        // jQuery(".vmMigrationDiv, .vmStartupDiv").hide();

    } else {
        jQuery("#hvstopclusterDuration").addClass("ignore");
        jQuery("#hvstopclusterDurationDiv").hide();

        jQuery("#hvstartclusterDuration").addClass("ignore");
        jQuery("#hvstartclusterDurationDiv").hide();

        // jQuery(".vmMigrationDiv, .vmStartupDiv").show();

    }
}

function showHideMigrationTargetHosts() {
    if (jQuery("#vmmigrationtargetcheckbox").is(":checked")) {
        jQuery("#hostListsContainer").show();
        jQuery("#multitree").show();
    } else {
        jQuery("#hostListsContainer").hide();
        jQuery("#multitree").hide();
    }
}

function showHideVMStartupDuration() {
    if (jQuery("#vmstartupcheckbox").is(":checked")) {
        jQuery("#vmstartupDuration").removeClass("ignore");
        jQuery("#vmstartupDurationDiv").show();
    } else {
        jQuery("#vmstartupDuration").addClass("ignore");
        jQuery("#vmstartupDurationDiv").hide();
    }
}

function showHideVAppStartupOptions() {
    if (jQuery("#vappshutdowncheckbox").is(":checked")) {
        jQuery("#forcevappshutdownEnableDiv").show();
        jQuery("#vappshutdownDuration").removeClass("ignore");
        jQuery("#vappshutdownDurationDiv").show();
        jQuery("#vappstartupEnableDiv").show();
        if (jQuery("#vappstartupcheckbox").is(":checked")) {
            jQuery("#vappstartupDuration").removeClass("ignore");
            jQuery("#vappstartupDurationDiv").show();
        } else {
            jQuery("#vappstartupDuration").addClass("ignore");
            jQuery("#vappstartupDurationDiv").hide();
        }
    } else {
        jQuery("#vappshutdownDuration").addClass("ignore");
        jQuery("#vappstartupDuration").addClass("ignore");
        jQuery("#forcevappshutdownEnableDiv").hide();
        jQuery("#vappshutdownDurationDiv").hide();
        jQuery("#vappstartupEnableDiv").hide();
        jQuery("#vappstartupDurationDiv").hide();
    }
}

function showHideVAppStartupDuration() {
    if (jQuery("#vappstartupcheckbox").is(":checked")) {
        jQuery("#vappstartupDuration").removeClass("ignore");
        jQuery("#vappstartupDurationDiv").show();
    } else {
        jQuery("#vappstartupDuration").addClass("ignore");
        jQuery("#vappstartupDurationDiv").hide();
    }
}

function updateButtons() {
    if ($next.length > 0) {
        if ($form.validate().numberOfInvalids() > 0) {
            $next.button('option', 'disabled', true);
        } else {
            $next.button('option', 'disabled', false);
        }
    }
}

function validateVMSettingsForm() {
    // Show a warning if Delay Host Maintenance is not selected in a vsan environment
    var delayMaintModeChecked = jQuery("#delayMaintModeCheckbox").is(":checked");
    var vsanEnabled = (jQuery("#vsanEnabled").val() == "1");

    if (!delayMaintModeChecked && vsanEnabled) {
        jQuery("#delayHostMaintModeDisabledWarning").show();
    } else {
        jQuery("#delayHostMaintModeDisabledWarning").hide();
    }

    if ($form.validate().form()) {
        $form.validate().resetForm();
    }

    updateButtons();
}

function initializeCheckboxes() {
    var webPluginChk = jQuery("#vspherewebpluginheckbox");
    var legacyPluginChk = jQuery("#vspherepluginheckbox");
    var webPlugin = webPluginChk.is(':checked');
    var legacyPlugin = legacyPluginChk.is(':checked');

    if (webPlugin == true) {
        legacyPluginChk.attr('disabled', 'disabled');
    } else if (legacyPlugin == true) {
        webPluginChk.attr('disabled', 'disabled');
    } else {
        webPluginChk.removeAttr('disabled');
        legacyPluginChk.removeAttr('disabled');
    }

    legacyPluginChk.on('change', function() {

        var checked = legacyPluginChk.is(":checked");
        if (checked == true) {
            webPluginChk.attr('disabled', 'disabled');
        } else {
            webPluginChk.removeAttr('disabled');
        }
    });

    webPluginChk.on('change', function() {

        var checked = webPluginChk.is(":checked");
        if (checked == true) {
            legacyPluginChk.attr('disabled', 'disabled');
        } else {
            legacyPluginChk.removeAttr('disabled');
        }
    });

}

function displayHyperVVMSettings() {
    var isGlobalVal = $hyperVData.attr("isGlobal");
    var isWizardPageVal = $hyperVData.attr("isWizardPage");
    var isManagedVal = $hyperVData.attr("data-managed");



    var targetDiv = (isWizardPageVal == "true") ? "#CfgWizardBody" : "#maindiv";

	if ($("#setup").length > 0) {
		console.log("individual setup" + $("#setup").val());
		
		
		var options = {
			isGlobal : isGlobalVal,
			isWizardPage : isWizardPageVal,
			isManaged : isManagedVal,
			setup : $("#setup").val()
		}    	
		
		var req = jQuery.post('/HyperVVMSettings', options);
	} else {
		console.log("global setup");
		var options = {
			isGlobal : isGlobalVal,
			isWizardPage : isWizardPageVal,
			isManaged : isManagedVal
		}    	
		var req = jQuery.post('/HyperVVMSettings', options);
	}
    req.success(function(data) {

        if (isWizardPageVal == "true") {
            jQuery(".CfgWizardBody").html(data);
        } else {
            jQuery("#settingsDiv").html(data);
            $apply.show();
            $reset.show();
        }
        initSettings();
        if (isManagedVal != "true") {
            initTargetHosts();
        }
        jQuery("#checkClusterDialog").dialog("close");

        // Mark the page as dirty if any input changes.
        jQuery("input, select").change(function(event) {
            dirty = true;
        });

    });

}

// cfgwizard.js override to prevent Next button enabled with validation errors
function initValidation() {
    // This does the cookies check
    loginOnLoad();
}

function initClusterDialog() {
    jQuery("#checkClusterDialog").dialog({
        height : 140,
        width : 300,
        modal : true,
        closeOnEscape : false,
        closeText : "hide",
        resizable : false,
        draggable : false,
        autoOpen : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function() {

            var thisRef = $(this);
            // remove close button
            thisRef.parents(".ui-dialog:first").find(".ui-dialog-titlebar-close").remove();
            // set hourglass cursor
            thisRef.parents().find(".ui-widget-overlay:first, .ui-dialog:first").css("cursor", "wait");
        }
    });
}

function loadPage() {
    var options = {
        "ismainui" : jQuery("#res").data("ismainui"),
        "isvmsettings" : jQuery("#res").data("isvmsettings")

    };

    var req = jQuery.post('/AJAXTargetHostSelection', options);
    var parentDiv = jQuery("#hostListsContainer");
    req.success(function(data) {

        setTimeout(function() {

            // showHideMigrationTargetHosts();
            showHideVMMigrationOptions();
            parentDiv.html(data);
            initTargetHosts();
            if (isHyperV) {
                jQuery("#checkClusterDialog").dialog("close");
            } else {
                jQuery("#checkConnectionDialog").dialog("close");
            }
        }, 2000);
    });
}

function loadDRS() {
    if (!isHyperV) {

        var options = {
            "setup" : jQuery('[name="setup"]').val()
        };

        var req = jQuery.post('/AJAXisDRSFullyManaged', options);
        var parentDiv = jQuery("#vmmigrationWarn");
        parentDiv.hide();
        req.success(function(data) {

            setTimeout(function() {

                parentDiv.append(data);
                showHideVMMigrationOptions();
                jQuery("#checkConnectionDialog").dialog("close");
            }, 2000);
        });
    }
}

function initVCenterCheckingDialog() {
    jQuery("#checkConnectionDialog").dialog({
        height : 140,
        width : 300,
        modal : true,
        closeOnEscape : false,
        closeText : "hide",
        resizable : false,
        draggable : false,
        autoOpen : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function() {

            var thisRef = $(this);
            // remove close button
            thisRef.parents(".ui-dialog:first").find(".ui-dialog-titlebar-close").remove();
            // set hourglass cursor
            thisRef.parents().find(".ui-widget-overlay:first, .ui-dialog:first").css("cursor", "wait");
        }
    });
}
