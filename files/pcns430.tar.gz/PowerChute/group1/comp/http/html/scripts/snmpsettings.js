var resRequiredFieldValidation;
var resRangeValidation;
var resRequiredField;
var resInvalidIPAddress;
var resInvalidPassword;
var resPortInUseValidation;
var resInvalidPasswordLong;
var resUnique;
var resOKButton;
var resCancelButton;
var resCloseButton;
var resProfileDialogTitle;
var resTrapDialogTitle;
var resTrapReceiverDialogTitle;
var resTrapTestSuccess;
var resTrapTestFail;
var $form;
var $apply;
var $reset;
var $res;

jQuery( document ).ready( function () {

    initialize();
} );

function initialize () {

    // window.alert("initialize");
    $form = jQuery( "form" );
    $res = jQuery( "#res" );

    $apply = jQuery( "#applyVMSettings" );
    $reset = jQuery( "#resetVMSettings" );

    initResourceStrings();

    initSettings();

    initv1ProfilesList();
    initv1ProfileDialog();
    initv1ProfileDialogValidation();

    initv3ProfilesList();
    initv3ProfileDialog();
    initv3ProfileDialogValidation();

    initTrapReceiversList();
    initTrapDialogs();
    initTrapDialogValidation();

    // If the password fields are empty, browser will try to fill them
    // which causes the page to be dirty.
    // Put in place holder text, we fill it in later dynamically later.
    jQuery( "#authPass" ).val( ".." );
    jQuery( "#privPass" ).val( ".." );

	//This checks if the defaul port is valid
	jQuery("#SNMPDiscoveryPort").valid();
	
}

function initSettings () {

    var activeAcc = parseInt( jQuery( "#activeAcc" ).val(), 10 );

    if ( isNaN( activeAcc ) ) {
        activeAcc = 0;
    }

    dirty = false;

    jQuery( "#maindiv" ).accordion( {
        heightStyle : "content",
        active : activeAcc
    } );

    initFormValidation();
}

function initFormValidation () {

    $form.validate( {
        ignore : ".ignore",
        rules : {
            SNMPDiscoveryPort : {
                required: true,
                maxlength: 5,
                digits: true,
                range: [0, 65535],
                remote:{
                    url : "/checkPort",
                    type : "post",
                    data : {
                        param_name : "SNMPDiscoveryPort",
                        formtoken : jQuery("#formtoken").val(), 
                        formtokenid : jQuery("#formtokenid").val()
                    }
                }
            }
        },
        messages : {
            SNMPDiscoveryPort : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                remote : resPortInUseValidation
            }
        },
        onkeyup : function ( element, event ) {

            jQuery.validator.defaults.onkeyup.call( this, element, event );
        },
        onfocusout : function ( element, event ) {

            jQuery.validator.defaults.onfocusout.call( this, element, event );
        },
        errorContainer : jQuery( "#errorcontainer" ),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            // store active accordion page
            var activeAcc = jQuery( "#maindiv" ).accordion( "option", "active" );
            jQuery( "#activeAcc" ).val( activeAcc );

            // apply button clicked and form validated
            dirty = false; // used by navigation.sh to block leaving without saving.
            jQuery( "#waitDialog" ).dialog( "open" ); // This shows a dialog while saving is happening.

            createHiddenInputField( "V1ProfilesReturn", createv1ProfileListString() );
            createHiddenInputField( "V3ProfilesReturn", createv3ProfileListString() );
            createHiddenInputField( "TrapReceiversReturn", createTrapReceiversListString() );
            copyTrapDialogsToForm();

            form.submit();
        }
    } );
}

function escapeHtml ( text ) {

    'use strict';

    // window.alert("type:" + text + "=" + typeof text);
    if ( typeof text == "string" ) {
        // we only do replace for strings. Anything else that happens to be
        // passed into this is just returned
        return text.replace( /[\"&<>]/g, function ( a ) {

            return {
                '"' : '&quot;',
                '&' : '&amp;',
                '<' : '&lt;',
                '>' : '&gt;'
            }[ a ];
        } );
    }
    else {
        return text;
    }
}

function createHiddenInputField ( name, value ) {

    var html = '<input type="hidden" name="' + escapeHtml( name ) + '" value="' + escapeHtml( value ) + '"/>';
    $form.append( html );
}

// ---------------------------------------------------------------------------------
// SNMP V1 Profiles table
// we have the v1ProfilesList which is the list of everything
// v1ProfileDialog: which is the pop up to create the profile
// v1ProfileForm: This the content of the Dialog
// ---------------------------------------------------------------------------------
function initv1ProfilesList () {

    jQuery( "#v1ProfilesList" ).sortable( {
        axis : "y",
        containment : "parent",
        items : "> li",
        cursor : "move",
        cursorAt : {
            top : 14
        }
    } );

    jQuery( "#addv1ProfilesBtn" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).off( 'click.apc' ).on( 'click.apc', function () {

        jQuery( "#v1ProfileDialog #access" ).val( "READONLY" );
        jQuery( "#v1ProfileDialog #nms" ).val( "0.0.0.0" );
        jQuery( "#v1ProfileDialog" ).dialog( "open" );
    } );

    updateRemoveBtn( jQuery( "#v1ProfilesList a.deleteBtn" ) );
    updateV1EditBtn( jQuery( "#v1ProfilesList a.editBtn" ) );

    updateV1addBtn();
}

function updateRemoveBtn ( removeBtn ) {

    removeBtn.button( {
        icons : {
            primary : "ui-icon-trash"
        },
        text : false
    } ).off( 'click.apc' ).on( 'click.apc', function ( event ) {

        var parent = jQuery( this ).parent( "li" );
        parent.remove();
        dirty = true;
        updateV1addBtn();
        updateV3addBtn(); // this function is used by both
    } );
}

function updateV1addBtn () {

    var profileCount = $( "#v1ProfilesList li" ).length;

    if ( profileCount >= 5 ) {
        jQuery( "#addv1ProfilesBtn" ).button( "option", "disabled", true );
    }
    else {
        jQuery( "#addv1ProfilesBtn" ).button( "option", "disabled", false );
    }
}

function updateV1EditBtn ( editBtn ) {

    editBtn.button( {
        icons : {
            primary : "ui-icon-pencil"
        },
        text : false
    } ).off( 'click.apc' ).on( 'click.apc', function ( event ) {

        var parent = jQuery( this ).parent( "li" );
        var community = parent.children( ".v1Profile" ).text();
        var nms = parent.children( ".nms" ).text();
        var access = parent.children( ".access" ).text();
        var index = jQuery( "#v1ProfilesList li" ).index( parent );

        jQuery( "#v1ProfileIndex" ).val( index );
        jQuery( "#community" ).val( community );
        jQuery( "#nms" ).val( nms );
        jQuery( "#access" ).val( access );
        jQuery( "#v1ProfileDialog" ).dialog( "open" );

    } );

}

// Run the dialog to change the profile
function initv1ProfileDialog () {

    jQuery( "#v1ProfileDialog" ).dialog( {
        autoOpen : false,
        modal : true,
        width : 514,
        title : resProfileDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        beforeClose : function ( event, ui ) {

            resetV1ProfileForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : function () {

                        if ( jQuery( "#v1ProfileForm" ).validate().form() ) {
                            var theDialog = jQuery( this );
                            var index = jQuery( "#v1ProfileIndex" ).val();
                            if ( index >= 0 ) {
                                updateV1Profile( index );
                            }
                            else {
                                createV1Profile();
                            }

                            updateRemoveBtn( jQuery( "#v1ProfilesList li:last a.deleteBtn" ) );
                            updateV1EditBtn( jQuery( "#v1ProfilesList li:last a.editBtn" ) );
                            theDialog.dialog( "close" );
                        }
                    }
                }, {
                    text : resCancelButton,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );
}

function initv1ProfileDialogValidation () {

    // set it up right on load
    if ( $( "#SNMPV1Enabled" ).prop( 'checked' ) ) {
        jQuery( "#V1Profiles" ).show();
    }
    else {
        jQuery( "#V1Profiles" ).hide();
    }

    $( "#SNMPV1Enabled" ).change( function () {

        if ( $( this ).prop( 'checked' ) ) {
            jQuery( "#V1Profiles" ).show();
        }
        else {
            jQuery( "#V1Profiles" ).hide();
        }
    } );

    jQuery.validator.addMethod( "UniqueCommunity", function ( value, element ) {

        var index = jQuery( "#v1ProfileIndex" ).val(); // -1 for new users
        var existingIndex = jQuery( "#v1ProfilesList .v1Profile" ).filter( function () {

            return $( this ).text().toLowerCase() == value.toLowerCase();
        } ).parent().index();
        if ( existingIndex == -1 ) {
            // it doesnt already exist
            return true;
        }
        else {
            // it does exist, is it this one?
            return index == existingIndex;
        }
    }, resUnique );

    jQuery( "#v1ProfileForm" ).validate( {
        // ignore : [],
        rules : {
            community : {
                required : true,
                maxlength : 15,
                UniqueCommunity : true
            },
            nms : {
                required : true,
                IPChecker : true
            }
        },
        messages : {
            community : {
                required : resRequiredField
            },
            nms : {
                required : resRequiredField
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );
}

// Do the changes to the profile
function resetV1ProfileForm () {

    jQuery( "#v1ProfileForm" )[ 0 ].reset();
    jQuery( "#v1ProfileForm" ).validate().resetForm();
    jQuery( "#v1ProfileIndex" ).val( "-1" );
}

function updateV1Profile ( index ) {

    // window.alert("updateV1Profile");
    var community = jQuery.trim( jQuery( "#community" ).val() );
    var nms = jQuery.trim( jQuery( "#nms" ).val() );
    var access = jQuery.trim( jQuery( "#access" ).val() );
    jQuery( "#v1ProfilesList li" ).eq( index ).children( ".v1Profile" ).text( community );
    jQuery( "#v1ProfilesList li" ).eq( index ).children( ".nms" ).text( nms );
    jQuery( "#v1ProfilesList li" ).eq( index ).children( ".access" ).text( access );
}

function createV1Profile () {

    // window.alert("createV1Profile");
    var community = jQuery.trim( jQuery( "#community" ).val() );
    var nms = jQuery.trim( jQuery( "#nms" ).val() );
    var access = jQuery.trim( jQuery( "#access" ).val() );

    var html = "<li class=\"v1ProfilesItem ui-widget-content ui-corner-all\">" + "<span class=\"v1Profile\"></span>"
            + "<span class=\"nms\"></span>" + "<span class=\"access\"></span>"
            + "<a href=\"#\" class=\"editBtn\"></a><a href=\"#\" class=\"deleteBtn\"></a></li>";

    jQuery( "#v1ProfilesList" ).append( html );
    // these just set the last in the list. because we appended.
    jQuery( "#v1ProfilesList li .v1Profile" ).last().text( community );
    jQuery( "#v1ProfilesList li .nms" ).last().text( nms );
    jQuery( "#v1ProfilesList li .access" ).last().text( access );
    updateRemoveBtn( jQuery( "#v1ProfilesList li:last a.deleteBtn" ) );
    updateV1EditBtn( jQuery( "#v1ProfilesList li:last a.editBtn" ) );

    updateV1addBtn();
}

function createv1ProfileListString () {

    var result = "";
    jQuery( "#v1ProfilesList li" ).each( function ( i ) {

        if ( result.length > 0 ) {
            result += "\r\n";
            // need to use delimiters that can not be in code. \r seems to be converted to \r\n somewhere in the process
        }

        var community = $( this ).children( ".v1Profile" ).text();
        var nms = $( this ).children( ".nms" ).text();
        var access = $( this ).children( ".access" ).text();

        result += community + "\t" + nms + "\t" + access;
    } );

    // window.alert("ProfileList: " + result);
    return result;
}

// ---------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------
// SNMP V3 Profiles table
// we have the v3ProfilesList which is the list of everything
// v3ProfileDialog: which is the pop up to create the profile
// v3ProfileForm: This the content of the Dialog
// ---------------------------------------------------------------------------------
function initv3ProfilesList () {

    jQuery( "#v3ProfilesList" ).sortable( {
        axis : "y",
        containment : "parent",
        items : "> li",
        cursor : "move",
        cursorAt : {
            top : 14
        }
    } );

    jQuery( "#addv3ProfilesBtn" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).off( 'click.apc' ).on( 'click.apc', function () {

        // window.alert("pressed");
        jQuery( "#v3ProfileDialog #authProtocol" ).val( "NONE" );
        jQuery( "#v3ProfileDialog #authPass" ).prop( "disabled", true );
        jQuery( "#v3ProfileDialog #privProtocol" ).val( "NONE" );
        jQuery( "#v3ProfileDialog #privPass" ).prop( "disabled", true );
        jQuery( "#v3ProfileDialog #privProtocol" ).prop( "disabled", true );
        jQuery( "#v3ProfileDialog" ).dialog( "open" );
    } );

    updateRemoveBtn( jQuery( "#v3ProfilesList a.deleteBtn" ) ); // Note: this is used in common with v1
    updateV3EditBtn( jQuery( "#v3ProfilesList a.editBtn" ) );

    updateV3addBtn();

}

function updateV3addBtn () {

    var profileCount = $( "#v3ProfilesList li" ).length;

    if ( profileCount >= 5 ) {
        jQuery( "#addv3ProfilesBtn" ).button( "option", "disabled", true );
    }
    else {
        jQuery( "#addv3ProfilesBtn" ).button( "option", "disabled", false );
    }
}

function updateV3EditBtn ( editBtn ) {

    editBtn.button( {
        icons : {
            primary : "ui-icon-pencil"
        },
        text : false
    } ).off( 'click.apc' ).on( 'click.apc', function ( event ) {

        var parent = jQuery( this ).parent( "li" );
        var user = parent.children( ".v3Profile" ).text();
        var authProt = parent.children( ".authProtocol" ).text();
        var authPass = parent.children( ".authPass" ).text();
        var privProt = parent.children( ".privProtocol" ).text();
        var privPass = parent.children( ".privPass" ).text();
        var access = parent.children( ".v3access" ).text();
        var index = jQuery( "#v3ProfilesList li" ).index( parent );

        jQuery( "#v3ProfileIndex" ).val( index );
        jQuery( "#v3user" ).val( user );
        jQuery( "#authProtocol" ).val( authProt );
        jQuery( "#authPass" ).val( authPass );
        jQuery( "#privProtocol" ).val( privProt );
        jQuery( "#privPass" ).val( privPass );
        jQuery( "#v3access" ).val( access );
        jQuery( "#v3ProfileDialog" ).dialog( "open" );

    } );
}

// Run the dialog to change the profile
function initv3ProfileDialog () {

    jQuery( "#v3ProfileDialog" ).dialog( {
        autoOpen : false,
        modal : true,
        width : 514,
        title : resProfileDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function ( event, ui ) {

            if ( jQuery( "#authProtocol" ).val() == "NONE" ) {
                jQuery( "#privProtocol" ).val( "NONE" );
                jQuery( "#privProtocol" ).prop( "disabled", true );
                jQuery( "#privPass" ).prop( "disabled", true );
                jQuery( "#privPass" ).val( null );

                jQuery( "#authPass" ).prop( "disabled", true );
                jQuery( "#authPass" ).val( null );
            }
            else {
                jQuery( "#privProtocol" ).prop( "disabled", false );
                jQuery( "#authPass" ).prop( "disabled", false );
            }

            if ( jQuery( "#privProtocol" ).val() == "NONE" ) {
                jQuery( "#privPass" ).prop( "disabled", true );
                jQuery( "#privPass" ).val( null );
            }
            else {
                jQuery( "#privPass" ).prop( "disabled", false );
            }

        },
        beforeClose : function ( event, ui ) {

            resetV3ProfileForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : function () {

                        if ( jQuery( "#v3ProfileForm" ).validate().form() ) {
                            var theDialog = jQuery( this );
                            var index = jQuery( "#v3ProfileIndex" ).val();
                            if ( index >= 0 ) {
                                updateV3Profile( index );
                            }
                            else {
                                createV3Profile();
                            }

                            updateRemoveBtn( jQuery( "#v3ProfilesList li:last a.deleteBtn" ) );
                            updateV3EditBtn( jQuery( "#v3ProfilesList li:last a.editBtn" ) );
                            theDialog.dialog( "close" );
                        }
                    }
                }, {
                    text : resCancelButton,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );
}

function initv3ProfileDialogValidation () {

    // set it up right on load
    if ( $( "#SNMPV3Enabled" ).prop( 'checked' ) ) {
        jQuery( "#V3Profiles" ).show();
    }
    else {
        jQuery( "#V3Profiles" ).hide();
    }

    $( "#SNMPV3Enabled" ).change( function () {

        if ( $( this ).prop( 'checked' ) ) {
            jQuery( "#V3Profiles" ).show();
        }
        else {
            jQuery( "#V3Profiles" ).hide();
        }
    } );

    jQuery( "#authProtocol" ).change( function () {

        if ( $( this ).val() == "NONE" ) {
            jQuery( "#privProtocol" ).val( "NONE" );
            jQuery( "#privProtocol" ).prop( "disabled", true );
            jQuery( "#privPass" ).prop( "disabled", true );
            jQuery( "#privPass" ).val( null );

            jQuery( "#authPass" ).prop( "disabled", true );
            jQuery( "#authPass" ).val( null );
        }
        else {
            jQuery( "#privProtocol" ).prop( "disabled", false );
            jQuery( "#authPass" ).prop( "disabled", false );
        }

        jQuery( "#v3ProfileForm" ).valid();
    } );

    jQuery( "#privProtocol" ).change( function () {

        if ( $( this ).val() == "NONE" ) {
            jQuery( "#privPass" ).prop( "disabled", true );
            jQuery( "#privPass" ).val( null );
        }
        else {
            jQuery( "#privPass" ).prop( "disabled", false );
        }

        jQuery( "#v3ProfileForm" ).valid();
    } );

    jQuery.validator.addMethod( "IPChecker", function ( value, element ) {

        return this.optional( element ) || isValidServerAddress( value );
    }, resInvalidIPAddress );

    jQuery.validator.addMethod( "UniqueName", function ( value, element ) {

        var index = jQuery( "#v3ProfileIndex" ).val(); // -1 for new users
        var existingIndex = jQuery( "#v3ProfilesList .v3Profile" ).filter( function () {

            return $( this ).text().toLowerCase() == value.toLowerCase();
        } ).parent().index();
        if ( existingIndex == -1 ) {
            // it doesnt already exist
            return true;
        }
        else {
            // it does exist, is it this one?
            return index == existingIndex;
        }
    }, resUnique );

    jQuery( "#v3ProfileForm" ).validate( {
        // ignore : [],
        rules : {
            v3user : {
                required : true,
                UniqueName : true,
                maxlength : 32
            },
            authPass : {
                required : function ( element ) {

                    return $( "#authProtocol" ).val() != "NONE";
                },
                minlength : {
                    param : 8,
                    depends : function ( element ) {

                        return $( "#authProtocol" ).val() != "NONE";
                    }
                },
                maxlength : {
                    param : 32,
                    depends : function ( element ) {

                        return $( "#authProtocol" ).val() != "NONE";
                    }
                }
            },
            privPass : {
                required : function ( element ) {

                    return $( "#privProtocol" ).val() != "NONE";
                },
                minlength : {
                    param : 8,
                    depends : function ( element ) {

                        return $( "#privProtocol" ).val() != "NONE";
                    }
                },
                maxlength : {
                    param : 32,
                    depends : function ( element ) {

                        return $( "#authProtocol" ).val() != "NONE";
                    }
                }
            }

        },
        messages : {
            v3user : {
                required : resRequiredField
            },

            authPass : {
                required : resRequiredField,
                minlength : jQuery.validator.format( resInvalidPassword ),
                maxlength : jQuery.validator.format( resInvalidPasswordLong )
            },
            privPass : {
                required : resRequiredField,
                minlength : jQuery.validator.format( resInvalidPassword ),
                maxlength : jQuery.validator.format( resInvalidPasswordLong )
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );
}

// Do the changes to the profile
function resetV3ProfileForm () {

    jQuery( "#v3ProfileForm" )[ 0 ].reset();
    jQuery( "#v3ProfileForm" ).validate().resetForm();
    jQuery( "#v3ProfileIndex" ).val( "-1" );
}

function updateV3Profile ( index ) {

    // window.alert("updateV1Profile");
    var community = jQuery.trim( jQuery( "#v3user" ).val() );
    var authProt = jQuery.trim( jQuery( "#authProtocol" ).val() );
    var authPass = jQuery.trim( jQuery( "#authPass" ).val() );
    var privProt = jQuery.trim( jQuery( "#privProtocol" ).val() );
    var privPass = jQuery.trim( jQuery( "#privPass" ).val() );
    var access = jQuery.trim( jQuery( "#v3access" ).val() );

    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".v3Profile" ).text( community );
    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".authProtocol" ).text( authProt );
    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".authPass" ).text( authPass );
    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".privProtocol" ).text( privProt );
    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".privPass" ).text( privPass );
    jQuery( "#v3ProfilesList li" ).eq( index ).children( ".v3access" ).text( access );
}

function createV3Profile () {

    // window.alert("createV1Profile");
    var community = jQuery.trim( jQuery( "#v3user" ).val() );

    var authProt = jQuery.trim( jQuery( "#authProtocol" ).val() );
    var authPass = jQuery.trim( jQuery( "#authPass" ).val() );
    var privProt = jQuery.trim( jQuery( "#privProtocol" ).val() );
    var privPass = jQuery.trim( jQuery( "#privPass" ).val() );

    var access = jQuery.trim( jQuery( "#v3access" ).val() );

    var html = "<li class=\"v3ProfilesItem ui-widget-content ui-corner-all\">" + "<span class=\"v3Profile\"></span>"
            + "<span class=\"authProtocol\"></span>" + "<span class=\"authPass\"></span>"
            + "<span class=\"privProtocol\"></span>" + "<span class=\"privPass\"></span>"
            + "<span class=\"v3access\"></span>"
            + "<a href=\"#\" class=\"editBtn\"></a><a href=\"#\" class=\"deleteBtn\"></a></li>";

    jQuery( "#v3ProfilesList" ).append( html );
    // these just set the last in the list. because we appended.
    jQuery( "#v3ProfilesList li .v3Profile" ).last().text( community );
    jQuery( "#v3ProfilesList li .authProtocol" ).last().text( authProt );
    jQuery( "#v3ProfilesList li .authPass" ).last().text( authPass );
    jQuery( "#v3ProfilesList li .privProtocol" ).last().text( privProt );
    jQuery( "#v3ProfilesList li .privPass" ).last().text( privPass );
    jQuery( "#v3ProfilesList li .v3access" ).last().text( access );
    updateRemoveBtn( jQuery( "#v3ProfilesList li:last a.deleteBtn" ) );
    updateV3EditBtn( jQuery( "#v3ProfilesList li:last a.editBtn" ) );

    updateV3addBtn();

}

function createv3ProfileListString () {

    var result = "";
    jQuery( "#v3ProfilesList li" ).each( function ( i ) {

        if ( result.length > 0 ) {
            result += "\r\n";
        }

        var community = $( this ).children( ".v3Profile" ).text();
        var authProt = $( this ).children( ".authProtocol" ).text();
        var authPass = $( this ).children( ".authPass" ).text();
        var privProt = $( this ).children( ".privProtocol" ).text();
        var privPass = $( this ).children( ".privPass" ).text();
        var access = $( this ).children( ".v3access" ).text();

        result += community + "\t" + authProt + "\t" + authPass + "\t" + privProt + "\t" + privPass + "\t" + access;
    } );

    // window.alert("ProfileList: " + result);
    return result;
}

// ------------------------------------------------------------------

function initTrapReceiversList () {

    jQuery( "#trapReceiversList" ).sortable( {
        axis : "y",
        containment : "parent",
        items : "> li",
        cursor : "move",
        cursorAt : {
            top : 14
        }
    } );

    jQuery( "#addTrapReceiverBtn" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).off( 'click.apc' ).on( 'click.apc', function () {

        jQuery( "#trapReceiverDialog #nmsEnable" ).prop( 'checked', "true" );
        jQuery( "#trapReceiverDialog #nmsPort" ).val( "162" );
        jQuery( "#trapReceiverDialog" ).dialog( "open" );

    } );

    updateRemoveBtn( jQuery( "#trapReceiversList a.deleteBtn" ) ); // Note: this is used in common with v1
    updateTrapEditBtn( jQuery( "#trapReceiversList a.editBtn" ) );
}

function updateTrapEditBtn ( editBtn ) {

    editBtn.button( {
        icons : {
            primary : "ui-icon-pencil"
        },
        text : false
    } ).off( 'click.apc' ).on( 'click.apc', function ( event ) {

        var parent = jQuery( this ).parent( "li" );
        var enable = parent.children( ".nmsEnable" ).text();
        var nms = parent.children( ".nmsIP" ).text();
        var port = parent.children( ".nmsPort" ).text();
        var type = parent.children( ".nmsType" ).text();
        var profile = parent.children( ".nmsProfile" ).text();
        var index = jQuery( "#trapReceiversList li" ).index( parent );

        jQuery( "#nmsEnable" ).prop( 'checked', enable == "true" );
        jQuery( "#nmsIP" ).val( nms );
        jQuery( "#nmsPort" ).val( port );
        jQuery( "#nmsEnable" ).val( enable );

        $( 'input[name=nmsType]' ).val( [
            type
        ] );

        if ( type == "V1" ) {
            jQuery( "#nmsV1User" ).val( profile );
            jQuery( "#nmsV3User" ).val( "" );
        }
        else {

            jQuery( "#nmsV1User" ).val( "" );

            // we have to add it as an option so we can set it
            // in the load of the form, we update all of the options
            // to match the current user profile list
            $( '#nmsV3User' ).append( new Option( profile ) );
            jQuery( "#nmsV3User" ).val( profile );

        }

        jQuery( "#trapReceiverIndex" ).val( index );

        jQuery( "#trapReceiverDialog" ).dialog( "open" );
    } );
}

function onlyDigits ( input ) {

    input.keydown( function ( e ) {

        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray( e.keyCode, [
                46, 8, 9, 27, 13, 110
        ] ) !== -1 ||
        // Allow: Ctrl+A, Command+A
        ( e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||
        // Allow: home, end, left, right, down, up
        ( e.keyCode >= 35 && e.keyCode <= 40 ) ) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number and stop the keypress
        if ( ( e.shiftKey || ( e.keyCode < 48 || e.keyCode > 57 ) ) && ( e.keyCode < 96 || e.keyCode > 105 ) ) {
            e.preventDefault();
        }
    } );
}

// Run the dialog to change the profile
function initTrapDialogs () {

    jQuery( "#CriticalTrapEnabledBtn" ).toggleClass( "set",
            jQuery( "#CriticalTrapDialog #trapEnabled" ).is( ':checked' ) );

    jQuery( "#CriticalTrapEnabledBtn" ).off( 'click.apc' ).on( 'click.apc', function () {

        jQuery( "#CriticalTrapDialog" ).dialog( "open" );
    } );

    jQuery( "#CriticalTrapDialog" ).dialog(
            {
                autoOpen : false,
                modal : true,
                width : 514,
                title : resTrapDialogTitle,
                closeText : resCloseButton,
                draggable : false,
                resizable : false,
                position : {
                    my : "center",
                    at : "center",
                    of : "#container"
                },
                close : function ( event, ui ) {

                    if ( event.originalEvent ) {
                        // the X in the title bar was clicked
                        $( "#CriticalTrapForm" )[ 0 ].reset();
                    }
                },
                buttons : [
                        {
                            text : resOKButton,
                            click : function () {

                                if ( jQuery( "#CriticalTrapForm" ).validate().form() ) {
                                    jQuery( "#CriticalTrapEnabledBtn" ).toggleClass( "set",
                                            jQuery( "#CriticalTrapDialog #trapEnabled" ).is( ':checked' ) );
                                    jQuery( this ).dialog( "close" );
                                }
                            }
                        }, {
                            text : resCancelButton,
                            click : function () {

                                $( "#CriticalTrapForm" )[ 0 ].reset();
                                jQuery( this ).dialog( "close" );

                            }
                        }
                ]
            } );

    jQuery( "#CommTrapEnabledBtn" ).toggleClass( "set", jQuery( "#CommTrapDialog #trapEnabled" ).is( ':checked' ) );

    jQuery( "#CommTrapEnabledBtn" ).off( 'click.apc' ).on( 'click.apc', function () {

        jQuery( "#CommTrapDialog" ).dialog( "open" );
    } );

    jQuery( "#CommTrapDialog" ).dialog(
            {
                autoOpen : false,
                modal : true,
                width : 514,
                title : resTrapDialogTitle,
                closeText : resCloseButton,
                draggable : false,
                resizable : false,
                position : {
                    my : "center",
                    at : "center",
                    of : "#container"
                },
                close : function ( event, ui ) {

                    if ( event.originalEvent ) {
                        // the X in the title bar was clicked
                        $( "#CommTrapForm" )[ 0 ].reset();
                    }
                },
                buttons : [
                        {
                            text : resOKButton,
                            click : function () {

                                if ( jQuery( "#CommTrapForm" ).validate().form() ) {
                                    jQuery( "#CommTrapEnabledBtn" ).toggleClass( "set",
                                            jQuery( "#CommTrapDialog #trapEnabled" ).is( ':checked' ) );
                                    jQuery( this ).dialog( "close" );
                                }
                            }
                        }, {
                            text : resCancelButton,
                            click : function () {

                                $( "#CommTrapForm" )[ 0 ].reset();
                                jQuery( this ).dialog( "close" );
                            }
                        }
                ]
            } );

    jQuery( "#trapReceiverDialog" ).dialog( {
        autoOpen : false,
        modal : true,
        width : 514,
        title : resTrapReceiverDialogTitle,
        closeText : resCloseButton,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function ( event, ui ) {

            var orgVal = $( '#nmsV3User' ).val();

            // remove all of the existing ones, and refresh. Incase new ones have been
            // added to the list
            $( '#nmsV3User' ).find( 'option' ).remove();

            // Add a blank option, for when none is selected
            $( '#nmsV3User' ).append( new Option( "" ) );

            jQuery( "#v3ProfilesList li" ).each( function ( i ) {

                var community = $( this ).children( ".v3Profile" ).text();
                // Work Around for JQuery IE8 issue https://bugs.jquery.com/ticket/1641
                var o = new Option( community );
                $( o ).html( community );
                $( '#nmsV3User' ).append( o );
            } );

            $( '#nmsV3User' ).val( orgVal );

        },
        beforeClose : function ( event, ui ) {

            resetTrapReceiverForm();
        },
        buttons : [
                {
                    text : resOKButton,
                    click : function () {

                        if ( jQuery( "#trapReceiverForm" ).validate().form() ) {
                            var theDialog = jQuery( this );
                            var index = jQuery( "#trapReceiverIndex" ).val();
                            if ( index >= 0 ) {
                                updateTrapReceiver( index );
                            }
                            else {
                                createTrapReceiver();

                            }

                            theDialog.dialog( "close" );
                        }
                    }
                }, {
                    text : resCancelButton,
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );

    jQuery( "#testTrap" ).button( {
        icons : {
            primary : "ui-icon-plusthick"
        }
    } ).off( 'click.apc' ).on( 'click.apc', function () {

        if ( jQuery( "#trapReceiverForm" ).validate().form() ) {

            jQuery( "#testTrapResult" ).hide();
            jQuery( "#testTrapResult" ).text( "" );

            var trapdata = {
                formtoken : jQuery( "#formtoken" ).val(),
                formtokenid : jQuery( "#formtokenid" ).val(),
                enable : jQuery.trim( jQuery( "#nmsEnable" ).is( ':checked' ) ),
                nms : jQuery.trim( jQuery( "#nmsIP" ).val() ),
                port : jQuery.trim( jQuery( "#nmsPort" ).val() ),
                type : jQuery( "#trapReceiverDialog input:radio[name='nmsType']:checked" ).val(),
                profile : function () {

                    if ( jQuery( "#trapReceiverDialog input:radio[name='nmsType']:checked" ).val() == "V1" ) {
                        return jQuery.trim( jQuery( "#nmsV1User" ).val() );
                    }
                    else {
                        return jQuery.trim( jQuery( "#nmsV3User" ).val() );
                    }
                }
            };

            if ( trapdata[ 'type' ] == "V3" ) {
                // we have to pass the V3 user, in case the user has been added, but not
                // saved yet
                // get the existing user index
                var profile = trapdata[ 'profile' ](); // this variable contains a function, so we have to run it.
                var index = jQuery( "#v3ProfilesList .v3Profile" ).filter( function () {

                    return $( this ).text() == profile;
                } ).parent().index();

                var user = jQuery( "#v3ProfilesList li" ).eq( index );
                trapdata[ 'UserName' ] = user.children( ".v3Profile" ).text();
                trapdata[ 'authProtocol' ] = user.children( ".authProtocol" ).text();
                trapdata[ 'authPass' ] = user.children( ".authPass" ).text();
                trapdata[ 'privProtocol' ] = user.children( ".privProtocol" ).text();
                trapdata[ 'privPass' ] = user.children( ".privPass" ).text();

            }
            else {

                // we do not need to send user details for V1. Only the community string is used in sending a trap
            }

            $.ajax( {
                url : "/testTrap",
                type : "post",
                data : trapdata,
                statusCode : {
                    401 : function () {

                        window.alert( "PCNS has been logged out" );
                        window.location.replace( "/login" );
                    }
                },
                success : function ( result ) {

                    jQuery( "#testTrapResult" ).show();

                    if ( result == true ) {
                        jQuery( "#testTrapResult" ).text( resTrapTestSuccess );
                    }
                    else {
                        jQuery( "#testTrapResult" ).text( resTrapTestFail );
                    }
                }
            } );
        }

    } );

}

function initTrapDialogValidation () {

    onlyDigits( jQuery( "#CriticalTrapDialog #trapDelay" ) );
    onlyDigits( jQuery( "#CriticalTrapDialog #repeatInterval" ) );
    onlyDigits( jQuery( "#CriticalTrapDialog #repeatN" ) );

    jQuery( "#CriticalTrapForm" ).validate( {
        //ignore : [],
        rules : {
            trapDelay : {
                required : true,
                digits : true,
                range : [
                        0, 999
                ]
            },
            repeatInterval : {
                required : true,
                digits : true,
                range : [
                        1, 999
                ]
            },
            repeatN : {
                required : function ( element ) {

                    return jQuery( "#CriticalTrapDialog #repeatNTimes" ).is( ':checked' );
                },
                digits : true,
                range : [
                        0, 999
                ]
            }
        },
        messages : {
            trapDelay : {
                required : resRequiredField,
                range : resRangeValidation
            },
            repeatInterval : {
                required : resRequiredField,
                range : resRangeValidation
            },
            repeatN : {
                required : resRequiredField,
                range : resRangeValidation
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );

    onlyDigits( jQuery( "#CommTrapDialog #trapDelay" ) );
    onlyDigits( jQuery( "#CommTrapDialog #repeatInterval" ) );
    onlyDigits( jQuery( "#CommTrapDialog #repeatN" ) );

    jQuery( "#CommTrapForm" ).validate( {
        //ignore : [],
        rules : {
            trapDelay : {
                required : true,
                digits : true,
                range : [
                        0, 999
                ]
            },
            repeatInterval : {
                required : true,
                digits : true,
                range : [
                        1, 999
                ]
            },
            repeatN : {
                required : function ( element ) {

                    return jQuery( "#CommTrapForm #repeatNTimes" ).is( ':checked' );
                },
                digits : true,
                range : [
                        0, 999
                ]
            }
        },
        messages : {
            trapDelay : {
                required : resRequiredField,
                range : resRangeValidation
            },
            repeatInterval : {
                required : resRequiredField,
                range : resRangeValidation
            },
            repeatN : {
                required : resRequiredField,
                range : resRangeValidation
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );

    onlyDigits( jQuery( "#trapReceiverDialog #mmsPort" ) );

    jQuery( "#addTrapReceiverBtn" ).button( "option", "disabled", false );
    jQuery( "#trapReceiverForm" ).validate( {
        //ignore : [],
        rules : {
            nmsIP : {
                required : true,
                IPChecker : true
            },
            nmsPort : {
                required : true,
                digits : true,
                range : [
                        0, 65535
                ]
            },
            nmsV1User : {
                required : function ( element ) {

                    return jQuery( "#trapReceiverForm #nmsTypeV1" ).is( ':checked' );
                },
                maxlength : {
                    param : 15
                }
            },
            nmsV3User : {
                required : function ( element ) {

                    return jQuery( "#trapReceiverForm #nmsTypeV3" ).is( ':checked' );
                }
            }
        },
        messages : {
            nmsIP : {
                required : resRequiredField
            },
            nmsPort : {
                required : resRequiredField,
                range : resRangeValidation
            },
            nmsV1User : {
                required : resRequiredField
            },
            nmsV3User : {
                required : resRequiredField
            }
        },
        errorPlacement : function ( error, element ) {

            error.appendTo( element.closest( ".labelvaluediv" ) );
        }
    } );

}

//Do the changes to the  profile
function resetTrapReceiverForm () {

    jQuery( "#trapReceiverForm" )[ 0 ].reset();
    jQuery( "#trapReceiverForm" ).validate().resetForm();
    jQuery( "#trapReceiverIndex" ).val( "-1" );
}

function updateTrapReceiver ( index ) {

    var enable = jQuery.trim( jQuery( "#nmsEnable" ).is( ':checked' ) );
    var nms = jQuery.trim( jQuery( "#nmsIP" ).val() );
    var port = jQuery.trim( jQuery( "#nmsPort" ).val() );
    var type = jQuery( "#trapReceiverDialog input:radio[name='nmsType']:checked" ).val();
    if ( type == "V1" ) {
        var profile = jQuery.trim( jQuery( "#nmsV1User" ).val() );
    }
    else {
        var profile = jQuery.trim( jQuery( "#nmsV3User" ).val() );
    }

    jQuery( "#trapReceiversList li" ).eq( index ).children( ".nmsEnable" ).text( enable );
    jQuery( "#trapReceiversList li" ).eq( index ).children( ".nmsIP" ).text( nms );
    jQuery( "#trapReceiversList li" ).eq( index ).children( ".nmsPort" ).text( port );
    jQuery( "#trapReceiversList li" ).eq( index ).children( ".nmsType" ).text( type );
    jQuery( "#trapReceiversList li" ).eq( index ).children( ".nmsProfile" ).text( profile );
}

function createTrapReceiver () {

    var enable = jQuery.trim( jQuery( "#nmsEnable" ).is( ':checked' ) );
    var nms = jQuery.trim( jQuery( "#nmsIP" ).val() );
    var port = jQuery.trim( jQuery( "#nmsPort" ).val() );
    var type = jQuery( "#trapReceiverDialog input:radio[name='nmsType']:checked" ).val();

    if ( type == "V1" ) {
        var profile = jQuery.trim( jQuery( "#nmsV1User" ).val() );
    }
    else {
        var profile = jQuery.trim( jQuery( "#nmsV3User" ).val() );
    }

    //window.alert("Create"+profile);

    var html = "<li class=\"trapReceiversItem ui-widget-content ui-corner-all\">" + "<span class=\"nmsEnable\"></span>"
            + "<span class=\"nmsIP\"></span>" + "<span class=\"nmsPort\"></span>" + "<span class=\"nmsType\"></span>"
            + "<span class=\"nmsProfile\"></span>"
            + "<a href=\"#\" class=\"editBtn\"></a><a href=\"#\" class=\"deleteBtn\"></a></li>";

    jQuery( "#trapReceiversList" ).append( html );
    //these just set the last in the list.  because we appended.
    jQuery( "#trapReceiversList li .nmsEnable" ).last().text( enable );
    jQuery( "#trapReceiversList li .nmsIP" ).last().text( nms );
    jQuery( "#trapReceiversList li .nmsPort" ).last().text( port );
    jQuery( "#trapReceiversList li .nmsType" ).last().text( type );
    jQuery( "#trapReceiversList li .nmsProfile" ).last().text( profile );

    updateRemoveBtn( jQuery( "#trapReceiversList li:last a.deleteBtn" ) );
    updateTrapEditBtn( jQuery( "#trapReceiversList li:last a.editBtn" ) );
}

//This is copies data from the sub forms to the main form before submitting it.
function copyTrapDialogsToForm () {

    createHiddenInputField( "UPSCriticalEvents_Enabled", jQuery( "#CriticalTrapDialog #trapEnabled" ).is( ':checked' ) );
    createHiddenInputField( "UPSCriticalEvents_SendClearingTrap", jQuery( "#CriticalTrapDialog #clearingTrap" ).is(
            ':checked' ) );
    createHiddenInputField( "UPSCriticalEvents_Delay", jQuery( "#CriticalTrapDialog #trapDelay" ).val() );
    createHiddenInputField( "UPSCriticalEvents_RepeatInterval", jQuery( "#CriticalTrapDialog #repeatInterval" ).val() );
    createHiddenInputField( "UPSCriticalEvents_RepeatUntilCleared", jQuery(
            "#CriticalTrapDialog input:radio[name='repeat']:checked" ).val() == "repeatTillClear" );
    createHiddenInputField( "UPSCriticalEvents_RepeatTimes", jQuery( "#CriticalTrapDialog #repeatN" ).val() );

    createHiddenInputField( "LostCommsEvents_Enabled", jQuery( "#CommTrapDialog #trapEnabled" ).is( ':checked' ) );
    createHiddenInputField( "LostCommsEvents_SendClearingTrap", jQuery( "#CommTrapDialog #clearingTrap" ).is(
            ':checked' ) );
    createHiddenInputField( "LostCommsEvents_Delay", jQuery( "#CommTrapDialog #trapDelay" ).val() );
    createHiddenInputField( "LostCommsEvents_RepeatInterval", jQuery( "#CommTrapDialog #repeatInterval" ).val() );
    createHiddenInputField( "LostCommsEvents_RepeatUntilCleared", jQuery(
            "#CommTrapDialog input:radio[name='repeat']:checked" ).val() == "repeatTillClear" );
    createHiddenInputField( "LostCommsEvents_RepeatTimes", jQuery( "#CommTrapDialog #repeatN" ).val() );

}

function createTrapReceiversListString () {

    var result = "";
    jQuery( "#trapReceiversList li" ).each( function ( i ) {

        if ( result.length > 0 ) {
            result += "\r\n";
        }

        var enable = $( this ).children( ".nmsEnable" ).text();
        var ip = $( this ).children( ".nmsIP" ).text();
        var port = $( this ).children( ".nmsPort" ).text();
        var type = $( this ).children( ".nmsType" ).text();
        var profile = $( this ).children( ".nmsProfile" ).text();

        result += enable + "\t" + ip + "\t" + port + "\t" + type + "\t" + profile;
    } );

    //window.alert("result:" + result);
    return result;
}

//---------------------------------------------------------------------------------

function initResourceStrings () {

    resRequiredField = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();
    resPortInUseValidation = jQuery("#resPortInUseValidation").text();
    resInvalidIPAddress = jQuery( "#resInvalidIPAddress" ).text();
    resInvalidPassword = jQuery( "#resInvalidPassword" ).text();
    resInvalidPasswordLong = jQuery( "#resInvalidPasswordLong" ).text();
    resUnique = jQuery( "#resUnique" ).text();
    resOKButton = jQuery( "#resOKButton" ).text();
    resCancelButton = jQuery( "#resCancelButton" ).text();
    resCloseButton = jQuery( "#resCancelButton" ).text();
    resProfileDialogTitle = jQuery( "#resProfileDialogTitle" ).text();
    resTrapDialogTitle = jQuery( "#resTrapDialogTitle" ).text();
    resTrapReceiverDialogTitle = jQuery( "#resTrapReceiverDialogTitle" ).text();

    resTrapTestSuccess = jQuery( "#resTrapTestSuccess" ).text();
    resTrapTestFail = jQuery( "#resTrapTestFail" ).text();

}
