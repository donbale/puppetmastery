jQuery( document ).ready( function () {

    initVCenterCheckingDialog();
    loadPage();
} );

function initialize () {

    var hostImage = "images/host.gif";
    jQuery( "#pcnsRunningOnVmOrHost" ).show();
    if ( jQuery( "#hyperVFlag" ).length > 0 ) {
        hostImage = "images/host_hyperv.png";
    }

    initializeTooltips();
    jQuery( "[title]" ).tooltip( "option", "content", function () {

        return jQuery( this ).attr( 'title' );
    } );

    jQuery( "#mappedlist" ).bind( "loaded.jstree", function ( event, data ) {

        jQuery( this ).jstree( "open_all" );
    } ).bind( "move_node.jstree", function ( event, data ) {

        moveHosts( event, data );
        enableResetButton();
        enableApplyButton();
        updateDeleteButton();
        updateNextButton();
    } ).bind( "select_node.jstree", function ( event, data ) {

        selectHosts( jQuery( this ), event, data );
        updateDeleteButton();
    } ).bind( "deselect_node.jstree", function ( event, data ) {

        updateDeleteButton();
    } ).jstree( {
        "core" : {
            "strings" : {
                multiple_selection : jQuery( "#res_multiple_selection" ).text()
            }
        },
        "themes" : {
            "theme" : "default",
            "dots" : false,
            "icons" : true
        },
        "ui" : {
            "selected_parent_close" : false,
            "select_prev_on_delete" : false,
            "disable_selecting_children" : true
        },
        "types" : {
            "valid_children" : [
                    "ups", "ups_no_outlet", "upsgroup", "singleups"
            ],
            "types" : {
                "ups" : {
                    "valid_children" : [
                        "outlet"
                    ],
                    "icon" : {
                        "image" : "images/ups16x16.png"
                    }
                },
                "ups_no_outlet" : {
                    "valid_children" : [
                            "host", "pcnshost", "vcsahost", "vcsapcnshost"
                    ],
                    "icon" : {
                        "image" : "images/ups16x16.png"
                    }
                },
                "upsgroup" : {
                    "valid_children" : [
                            "host", "pcnshost", "vcsahost", "vcsapcnshost"
                    ],
                    "icon" : {
                        "image" : "images/upsgroup.png"
                    }
                },
                "singleups" : {
                    "valid_children" : [
                            "host", "pcnshost", "vcsahost", "vcsapcnshost"
                    ],
                    "icon" : {
                        "image" : "images/ups16x16.png"
                    }
                },
                "outlet" : {
                    "valid_children" : [
                            "host", "pcnshost", "vcsahost", "vcsapcnshost"
                    ],
                    "icon" : {
                        "image" : "images/socket.png"
                    }
                },
                "host" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : hostImage
                    }
                },
                "pcnshost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/pwrchute.png"
                    }
                },
                "vcsahost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vsphere.png"
                    }
                },
                "vcsapcnshost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/hybrid.png"
                    }
                }
            }
        },
        "crrm" : {
            "move" : {
                "always_copy" : "multitree", // create a copy if move is between trees
                "check_move" : function ( m ) {

                    // only allow hosts to be moved
                    var $target = jQuery( m.o[ 0 ] );
                    var type = $target.attr( "rel" );
                    if ( type == "host" || type == "pcnshost" || type == "vcsahost" || type == "vcsapcnshost" ) {
                        // and don't allow already mapped hosts
                        return !( $target.hasClass( "mapped" ) );
                    }

                    return false;
                }
            }
        },
        "dnd" : {
            "drop_target" : false,
            "drag_target" : false
        },
        "plugins" : [
                "themes", "html_data", "dnd", "crrm", "ui", "types"
        ]
    } );

    initCancelConfirmDialog();
    initWaitDialog();

    jQuery( "#deletebtn" ).button( {
        disabled : true
    } ).click( function () {

        removeHosts();
        updateDeleteButton();
        updateNextButton();
        enableResetButton();
        enableApplyButton();
    } );

    jQuery( "#resetbtn" ).button( {
        disabled : true
    } ).click( function () {

        createHiddenInputField( "reset", "reset" );
        dirty = false;
        $form.submit();
    } );

    jQuery( "#applybtn" ).button( {
        disabled : true
    } ).click( function () {

        createHiddenInputField( "apply", "apply" );
        postMappedHosts();
    } );

    jQuery( "#next" ).click( function ( event ) {

        createHiddenInputField( "next", "next" );
        postMappedHosts();
        return false;
    } );

    jQuery( "#previous" ).click( function ( event ) {

        createHiddenInputField( "previous", "previous" );
        postMappedHosts();
        return false;
    } );

    jQuery( "#cancel" ).click( function () {

        jQuery( "#confirmdialog" ).dialog( "open" );
        return false;
    } );

    var $next = jQuery( "#next" );
    /*
     * on next click it will disable next button to avoid the user to click multiple times
     */
    $next.click( function () {

        $next.button( "option", "disabled", true );
        return false;
    } );

    // Enable next button if there are hosts mapped
    var isEmptyHostsMappedList = jQuery( "#res" ).data( "emptymappedlist" );

    if ( !isEmptyHostsMappedList ) {
        $next.button( "option", "disabled", false );
    }
    showHideValidation();
    window.onbeforeunload = confirmExit;
}
function initCancelConfirmDialog () {

    jQuery( "#confirmdialog" ).dialog( {
        autoOpen : false,
        modal : true,
        draggable : false,
        resizable : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        buttons : [
                {
                    text : jQuery( "#res_yes_button" ).text(),
                    click : function () {

                        createHiddenInputField( "cancel", "cancel" );
                        dirty = false;
                        $form.submit();
                    }
                }, {
                    text : jQuery( "#res_no_button" ).text(),
                    click : function () {

                        jQuery( this ).dialog( "close" );
                    }
                }
        ]
    } );

}

function showHideValidation () {


    // If nutanix, all host must be mapped under the same single ups or ups group.
    if ( $( "#nutanixFlag" ).length > 0 ) {
        if ( allHostsMappedUnderSameGroup() ) {
            jQuery( "#allHostsNotMappedWarning" ).hide();
        }
        else {
            jQuery( "#allHostsNotMappedWarning" ).show();
            jQuery( "#applybtn" ).button( "option", "disabled", true );
        }
    }
    else {
    if ( jQuery( "#mappedlist li.host" ).length > 0 ) {
        jQuery( "#validationText" ).hide();
    }
    else {
        jQuery( "#validationText" ).show();
            jQuery( "#applybtn" ).button( "option", "disabled", true );
        }
    }
}

function allHostsMappedUnderSameGroup () {
	var allOK = true;
    var clusters = jQuery( "#inventory .cluster" ).each(
	 function () {
		 var groups = new Set();
		jQuery( this ).find(".host").each(
			//each host in the cluster
			function () {
				//Find its target in the mapped host list.  
				var target = jQuery( "#mappedlist li.host[lnk='" + jQuery(this).attr( "lnk" ) + "']" );
				
				var ups = jQuery(target).closest(".upsgroup, .singleups, .ups_no_outlet, .ups, .outlet").attr( "id" );
				//NOTE:  if it  is not mapped, then ups is 'undefined'  Which is then added to the groups as required.				
				groups.add(ups);
				
			});
			if(groups.size>1){
				allOK = false;
			};
			
		return allOK; //if this is true we continue, if it is false we stop
	}); //this = clusters
	  
	return allOK;
			
}

function postMappedHosts () {

    jQuery( "#mappedlist li.ups" ).each(
            function () {

                var upsIP = this.id;
                jQuery( this ).find( "li.outlet" ).each(
                        function () {

                            var $outlet = jQuery( this );
                            var outLetGroupNumber = $outlet.children( "span.hidden" ).text();
                            $outlet.find( "li.host" ).each(
                                    function () {

                                        createHiddenInputField( "mappedHost", jQuery( this ).attr( "lnk" ) + "," +
                                                upsIP + "," + outLetGroupNumber );
                                    } );
                        } );
            } );

    jQuery( "#mappedlist li.ups_no_outlet, #mappedlist li.upsgroup, #mappedlist li.singleups" ).each( function () {

        var upsIP = this.id;
        jQuery( this ).find( "li.host" ).each( function () {

            createHiddenInputField( "mappedHost", jQuery( this ).attr( "lnk" ) + "," + upsIP );
        } );
    } );

    dirty = false;
    jQuery( "#waitDialog" ).dialog( "open" );
    $form.submit();
}

function loadPage () {

    var options = {
        "ismainui" : jQuery( "#res" ).data( "ismainui" )
    };

    var req = jQuery.post( '/AJAXHostNMCMapping', options );

    var parentDiv = jQuery( "#hostListsContainer" );
    req.success( function ( data ) {

        parentDiv.html( data );
        jQuery( ".checkConnectionDialog" ).dialog( "close" );
        initialize();
        initializeInventory();

    } );
}
