jQuery(document).ready(function() {

    initVCenterCheckingDialog();
    loadPage();

});

function initialize() {

    var hostImage = "images/host.gif";
    if (jQuery("#hyperVFlag").length > 0) {
        hostImage = "images/host_hyperv.png";
    }

    jQuery("#mappedlist").bind("move_node.jstree", function(event, data) {
        moveHosts(event, data);
        movePCNSHostToLastPosition();
        showHidePCNSHostWarning();
        enableResetButton();
        enableApplyButton();
        updateDeleteButton();
        updateNextButton();
       
    }).bind("select_node.jstree", function(event, data) {
        updateDeleteButton();
    }).bind("deselect_node.jstree", function(event, data) {
        updateDeleteButton();
    }).jstree({
        "core" : {
            "strings" : {
                multiple_selection : jQuery("#res_multiple_selection").text()
            }
        },
        "themes" : {
            "theme" : "default",
            "dots" : false,
            "icons" : true
        },
        "ui" : {
            "select_prev_on_delete" : false
        },
        "types" : {
            "valid_children" : [
                    "host", "pcnshost", "vcsahost", "vcsapcnshost"
            ],
            "types" : {
                "host" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : hostImage
                    }
                },
                "pcnshost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/pwrchute.png"
                    }
                },
                "vcsahost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/vsphere.png"
                    }
                },
                "vcsapcnshost" : {
                    "valid_children" : "none",
                    "icon" : {
                        "image" : "images/hybrid.png"
                    }
                }
            }
        },
        "crrm" : {
            "move" : {
                "always_copy" : "multitree", // create a copy if move is between trees
                "check_move" : function(m) {

                    return !(jQuery(m.o[0]).hasClass("mapped"));
                }
            }
        },
        "dnd" : {
            "drop_target" : false,
            "drag_target" : false
        },
        "plugins" : [
                "themes", "html_data", "dnd", "crrm", "ui", "types"
        ]
    });

    initWaitDialog();

    jQuery("#deletebtn").button({
        disabled : true
    }).click(function() {
        removeHosts();
        showHidePCNSHostWarning();
        updateDeleteButton();
        updateNextButton();
        enableResetButton();
        enableApplyButton();
    });

    jQuery("#resetbtn").button({
        disabled : true
    }).click(function() {
        createHiddenInputField("reset", "reset");
        dirty = false;
        $form.submit();
    });

    jQuery("#applybtn").button({
        disabled : true
    }).click(function() {
        if (jQuery("#mappedlist li.host").length > 0) {
            createHiddenInputField("apply", "apply");
            postTargetHosts();
        }
    });

    var $next = jQuery("#next");
    $next.click(function(event) {
        createHiddenInputField("next", "next");
        postTargetHosts();
        return false;
    });

    // Enable next button if there are hosts mapped
    var isEmptyHostsMappedList = jQuery("#res").data("emptymappedlist");

    if (!isEmptyHostsMappedList) {
        $next.button("option", "disabled", false);
    }

    jQuery("#previous").click(function(event) {

        createHiddenInputField("previous", "previous");
        postTargetHosts();
        return false;
    });

    jQuery("#cancel").click(function(event) {

        // we don't show a navigate away warning for Cancel button
        dirty = false;
    });

    showHideValidation();
    showHidePCNSHostWarning();
    window.onbeforeunload = confirmExit;
}

function showHidePCNSHostWarning() {
    if (jQuery("#inventory li.pcns").length > 0) {
        if (jQuery("#mappedlist li.pcns").length > 0) {
            jQuery("#PCNSHostWarning").hide();
        } else {
            jQuery("#PCNSHostWarning").show();
        }
    }
	
	if ($("#nutanixFlag").length > 0) {
		if (jQuery("#mappedlist .pcns.host").length > 0) {
            jQuery("#pcnsRunningOnVmOrHost").show();
        } else {
            jQuery("#pcnsRunningOnVmOrHost").hide();
        }
	}
		
}

function showHideValidation() {
    if ($("#nutanixFlag").length > 0) {
		clustersok = true;
		jQuery("#inventory .cluster").each(function() {
	 	   mappedhosts = jQuery(this).find( ".host.mapped" ).length;		   
		   hosts = jQuery(this).find( ".host" ).length;
		   
		   if(mappedhosts==0 || mappedhosts==hosts){
		   //its ok
		   } else {
			clustersok = false;
		   };
		
		});
	
	   if(clustersok){
		jQuery("#allHostsNotMappedWarning").hide();
		jQuery("#applybtn").button("option", "disabled", false);
	   } else {
		jQuery("#allHostsNotMappedWarning").show();
		jQuery("#applybtn").button("option", "disabled", true); 
	   };
	
    } else {
        if (jQuery("#mappedlist li.host").length > 0) {
            jQuery("#validationText").hide();
        } else {
            jQuery("#validationText").show();
            jQuery("#applybtn").button("option", "disabled", true);
        }
    }
}

function movePCNSHostToLastPosition() {
    var PCNSHost = jQuery("#mappedlist li.pcns");
    if (PCNSHost.length > 0) {
        if (!PCNSHost.hasClass("jstree-last")) {
            jQuery("#mappedlist").jstree("move_node", PCNSHost, -1, "last", false);
        }
    }
}

function postTargetHosts() {
    jQuery("#mappedlist li.host").each(function() {

        createHiddenInputField("targetHost", jQuery(this).attr("lnk"));
    });

    dirty = false;
    jQuery("#waitDialog").dialog("open");
    $form.submit();
}

function loadPage() {
    var options = {
        "ismainui" : jQuery("#res").data("ismainui")
    };

    var req = jQuery.post('/AJAXTargetHostSelection', options);
    var parentDiv = jQuery("#hostListsContainer");
    req.success(function(data) {

        parentDiv.html(data);
        initialize();
        initializeInventory();
        jQuery(".checkConnectionDialog").dialog("close");
    });
}
