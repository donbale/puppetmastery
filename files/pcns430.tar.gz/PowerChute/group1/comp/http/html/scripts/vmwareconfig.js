var $next, $form, resRequiredFieldValidation, resValidServerValidation, resAttemptConnection, resNetworkError;
var resInvalidCredentials, resRangeValidation, connectionError, doServerCheck;

jQuery( document ).ready( function () {

    dirty = false;
    $form = jQuery( "form" );
    $next = jQuery( "#next" );
    doServerCheck = true;
    connectionError = jQuery( "#connectionError" );
    resRequiredFieldValidation = jQuery( "#requiredSpan" ).text();
    resValidServerValidation = jQuery( "#invalidIpSpan" ).text();
    resAttemptConnection = jQuery( "#attemptConnectionSpan" ).text();
    resNetworkError = jQuery( "#networkErrorSpan" ).text();
    resInvalidCredentials = jQuery( "#invalidCredentialsSpan" ).text();
    resRangeValidation = jQuery( "#rangeSpan" ).text();

    connectionError.hide();

    jQuery( "input" ).on( "keyup paste", function () {

        connectionError.hide();
        doServerCheck = true;
        validateVCenterForm();
        dirty = true;
    } );

    jQuery( "input" ).change( function () {

        dirty = true;
        validateVCenterForm();
    } );

    $( "#cancel, #previous" ).addClass( "cancel" );

    $( "#cancel, #previous" ).click( function () {

        doServerCheck = false;
        dirty = false;
    } );

    var prefix = "vcenter_server_";
    if ( jQuery( "#esxi_host_protocol" ).length > 0 ) {
        prefix = "esxi_host_";
    }
    jQuery( "#" + prefix + "protocol" ).change( function () {

        setDefaultPort( prefix );
        validateVCenterForm();
    } );

    initVCenterValidation();
    validateVCenterForm();
} );

function initVCenterValidation () {

    $form.validate( {
        rules : {
            vcenter_server_protocol : {
                required : true
            },
            vcenter_server_port : {
                required : true,
                range : [
                        0, 65535
                ]
            },
            vcenter_server_ip : {
                required : true,
                checkValidServerAddress : resValidServerValidation
            },
            vcenter_server_username : {
                required : true
            },
            vcenter_server_password : {
                required : true
            },
            esxi_host_protocol : {
                required : true
            },
            esxi_host_port : {
                required : true,
                range : [
                        0, 65535
                ]
            },
            esxi_host_ip : {
                required : true,
                checkValidServerAddress : resValidServerValidation
            },
            esxi_host_username : {
                required : true
            },
            esxi_host_password : {
                required : true
            }
        },
        messages : {
            vcenter_server_protocol : {
                required : resRequiredFieldValidation
            },
            vcenter_server_port : {
                required : resRequiredFieldValidation,
                range : resRangeValidation
            },
            vcenter_server_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            vcenter_server_username : {
                required : resRequiredFieldValidation
            },
            vcenter_server_password : {
                required : resRequiredFieldValidation
            },
            esxi_host_protocol : {
                required : resRequiredFieldValidation
            },
            esxi_host_port : {
                required : resRequiredFieldValidation,
                range : resRangeValidation
            },
            esxi_host_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            esxi_host_username : {
                required : resRequiredFieldValidation
            },
            esxi_host_password : {
                required : resRequiredFieldValidation
            }
        },
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        invalidHandler : function ( event, validator ) {

            // needed for handling remote validation error
            jQuery( "#next" ).button( 'option', 'disabled', true );
        },
        submitHandler : function ( form ) {

            if ( doServerCheck == true ) {
                // only for next
                checkServerAvailability( function ( result ) {

                    if ( result != null && result.isValid == 1 ) {
                        dirty = false;
                        window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                        doServerCheck = false;
                        $form.submit();
                        //if the buttons are enabled users might press them, and
                        //that messes up the wizard
                        jQuery("#next, #cancel, #previous").button('option','disabled', true);
                    }
                } );
            }
            else {
                dirty = false;
                window.allowNavigation = true; // prevent cfgWizard.js from blocking submit
                form.submit();
            }
        }

    } );
    jQuery.validator.addMethod( "checkValidServerAddress", function ( address, element ) {

        var result = isValidServerAddress( address );
        // Only enable next button if there are no other fields on invalid
        // state
        if ( result == true && $form.validate().numberOfInvalids() == 0 ) {
            $next.button( 'option', 'disabled', false );
        }
        else {
            $next.button( 'option', 'disabled', true );
        }
        return this.optional( element ) || result;
    } );

}

function updateButtons () {

    if ( $form.validate().numberOfInvalids() > 0 ) {
        $next.button( 'option', 'disabled', true );
    }
    else {
        $next.button( 'option', 'disabled', false );
    }
}

function validateVCenterForm () {

    if ( $form.validate().form() ) {
        $form.validate().resetForm();
    }

    updateButtons();
}

//cfgwizard.js override to prevent Next button enabled with validation errors
function initValidation () {

    // This does the cookies check
    loginOnLoad();
}

function checkServerAvailability ( callback ) {

    connectionError.hide();

    var req = jQuery.post( "/AJAXCheckHostConnection", $form.serialize() );

    req.success( function ( result ) {

        if ( result == null || result.isValid == 0 ) {
            connectionError.text( resInvalidCredentials );
            connectionError.show();
            jQuery( "#waitDialog" ).dialog( "close" );
        }
        else if ( result.isValid == -1 ) {
            connectionError.text( resNetworkError );
            connectionError.show();
            jQuery( "#waitDialog" ).dialog( "close" );
        }
        else {
            setTimeout( function () {

                jQuery( "#waitDialog" ).dialog( "close" );
            }, 2000 );
        }

        callback( result );
    } );

    req.error( function ( data ) {

        connectionError.show();
        jQuery( "#waitDialog" ).dialog( "close" );
        return callback( false );
    } );
}

function setDefaultPort ( prefix ) {

    var port = jQuery( "#" + prefix + "port" );
    var protocol = jQuery( "#" + prefix + "protocol" );
    var portVal = port.val();
    var protocolVal = protocol.val();
    if ( protocolVal == "https" ) {
        if ( !portVal || portVal == "80" ) {
            port.val( "443" );
        }
    }
    else {
        if ( !portVal || portVal == "443" ) {
            port.val( "80" );
        }
    }
}
