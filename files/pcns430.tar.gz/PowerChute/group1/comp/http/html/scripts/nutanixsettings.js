var resRequiredFieldValidation,
    resRangeLengthValidation,
    resInvalidCharacters,
    resPassPhraseWhiteSpaceError,
    resSSHKeyNotFound,
    resVMPasswordDialogTitle,
    resVMPassphraseDialogTitle,
    resVMHostPasswordDialogTitle,
    resVMPasswordName,
    resVMPassphraseName,
    resVMHostPasswordName,
    resOKButton,
    resCancelButton,
    resCloseButton,
    resPasswordsDoNotMatch,
    dirty,
    vmpasswordDirty,
    vmpassphraseDirty,
    vmSshKeyPathDirty,
    resAttemptConnection,
    resInvalidConnection,
    pageForm,
    isHyperV,
    isVCenterManaged,
    isNutanix,
    vmInitPasswordValidation,
    vmInitPassphraseValidation, 
    vmInitPasswordDialog,
    vmInitPassphraseDialog,
    vmResetPasswordForm, 
    vmResetPassphraseForm,
    adminValidatePasswordForm,
    vmValidatePasswordForm,
    vmValidatePassphraseForm,
    isClusterPasswordSet,
    isHostPasswordSet,
    isSSHKeyPathSet;

jQuery(document).ready(function() {
    dirty = false;
    vmpasswordDirty = false;
    vmpassphraseDirty = false;
    vmSshKeyPathDirty = false;
    resRequiredFieldValidation = jQuery("#resRequiredFieldValidation").text();
    resRangeLengthValidation = jQuery("#resRangeLengthValidation").text();
    resInvalidCharacters = jQuery("#resInvalidCharacters").text();
    resPassPhraseWhiteSpaceError = jQuery("#resPassPhraseWhiteSpaceError").text();
    resSSHKeyNotFound = jQuery("#resSSHKeyNotFound").text();
    resVMPasswordDialogTitle = jQuery("#resVMPasswordDialogTitle").text();
    resVMPasswordName = jQuery("#resVMPasswordName").text();
    resVMPassphraseName = jQuery("#resVMSshPassphraseName").text();
    resOKButton = jQuery("#resOKButton").text();
    resCancelButton = jQuery("#resCancelButton").text();
    resCloseButton = jQuery("#resCloseButton").text();
    resPasswordsDoNotMatch = jQuery("#resPasswordsDoNotMatch").text();
    resRangeValidation = jQuery("#rangeSpan").text();
    resAttemptConnection = jQuery("#attemptConnectionSpan").text();
    resInvalidConnection = jQuery("#invalidConnectionSpan").text();
    resVMPassphraseDialogTitle = jQuery("#resVMPassphraseDialogTitle").text();
    resPassphrasesDoNotMatch = jQuery("#resPassphrasesDoNotMatch").text();
    pageForm = "#nutanixsettingsform";
    isVCenterManaged = false;
    isHyperV = false;
    isNutanix = true;

    setupVMChangePasswordParams();

    vmInitPasswordValidation = makeInitPasswordValidation(changeVMPasswordDialog);
    vmInitPassphraseValidation = makeInitPasswordValidation(changeVMPassphraseDialog);

    vmResetPasswordForm = makeResetPasswordForm(changeVMPasswordDialog.passwordForm, changeVMPasswordDialog.passwordError);
    vmResetPassphraseForm = makeResetPasswordForm(changeVMPassphraseDialog.passwordForm, changeVMPassphraseDialog.passwordError);

    vmValidatePasswordForm = makeValidatePasswordForm(changeVMPasswordDialog.passwordForm);
    vmValidatePassphraseForm = makeValidatePasswordForm(changeVMPassphraseDialog.passwordForm);

    vmInitPasswordDialog = makeInitPasswordDialog(changeVMPasswordDialog, vmResetPasswordForm, vmValidatePasswordForm);
    vmInitPassphraseDialog = makeInitPasswordDialog(changeVMPassphraseDialog, vmResetPassphraseForm, vmValidatePassphraseForm);
        
    isClusterPasswordSet = false;
    isHostPasswordSet = false;
    isSSHKeyPathSet = false;
    
    isClusterPasswordSet = ($("#isClusterPasswordSet").length > 0);
    isSSHKeyPathSet = ($("#isSSHKeyPathSet").length > 0);
        
    blockNavigation(pageForm);

    jQuery("#resetButton").click(function() {

        vmResetPasswordForm();
        jQuery(pageForm)[0].reset();
        jQuery(pageForm).validate().resetForm();
        
        vmResetPasswordForm();
        jQuery("#" + resVMPasswordName).remove();
        dirty = false;
        vmpasswordDirty = false;

        vmResetPassphraseForm();
        jQuery("#" + resVMPassphraseName).remove();
        vmpassphraseDirty = false;

        vmSshKeyPathDirty = false;

        jQuery("#passwordWillBeDeletedWarning").hide();
        jQuery("#SshKeyPathWillBeDeletedWarning").hide();

    });

    initValidation();
    vmInitPasswordDialog();
    vmInitPasswordValidation();
    jQuery("#vmchangePasswordLink").click(function() {

        jQuery("#" + resVMPasswordName).remove();
        jQuery("#" + resVMPassphraseName).remove();

        vmpassphraseDirty = false;
        vmpasswordDirty = false;
        
        showHideNutanixPasswordWarnings();

        jQuery(changeVMPasswordDialog.passwordDiv).dialog("open");
        vmResetPasswordForm();
    });

    vmInitPassphraseDialog();
    vmInitPassphraseValidation();
    jQuery("#vmchangePassphraseLink").click(function() {
        jQuery("#" + resVMPassphraseName).remove();
        vmpassphraseDirty = false;
        jQuery(changeVMPassphraseDialog.passwordDiv).dialog("open");
        vmResetPassphraseForm();
    });

    jQuery("#nutanix_ssh_key_path").on("keyup paste", function () {
        vmSshkeyPathDirty = true;
        if (jQuery("#nutanix_ssh_key_path").val() != "") {
            jQuery("#" + resVMPasswordName).remove();
            vmpasswordDirty = false;
            jQuery("#passwordWillBeDeletedWarning").show();
            jQuery("#SshKeyPathWillBeDeletedWarning").hide();
        } else { 
            jQuery("#passwordWillBeDeletedWarning").hide();
        }
        validateNutanixPasswords();
    });

    initWaitDialog();
    window.onbeforeunload = confirmExit;
    validateForm(pageForm);
    checkNutanixConnection();

});

function initValidation() {
    jQuery(pageForm).validate({
        ignore : [],
        ignoreTitle : true,
        rules : {
            nutanix_cluster_ip : {
                required : true,
                checkValidServerAddress : true
            },
            nutanix_ssh_key_path : {
                required : function(){
                    var newClusterPasswordToSet = jQuery("#" + resVMPasswordName).length > 0;
                    return !(newClusterPasswordToSet || isClusterPasswordSet);    
                },
                remote : {
                    url : "/verifyfile",
                    type : "post",
                    data : {
                        // readable check
                        executable : false,
                        param_name : "nutanix_ssh_key_path",
                        formtoken : jQuery("#formtoken").val(),
                        formtokenid : jQuery("#formtokenid").val()
                    }
                }
            }
        },
        messages : {
            nutanix_cluster_ip : {
                required : resRequiredFieldValidation,
                checkValidServerAddress : resValidServerValidation
            },
            nutanix_ssh_key_path : {
                required : resRequiredFieldValidation,
                remote : resSSHKeyNotFound
            }  
        },
        errorPlacement : function(error, element) {

            error.appendTo(element.closest(".labelvaluediv"));
        },
        submitHandler : function(form) {

            dirty = false;
            vmpasswordDirty = false;
            vmpassphraseDirty = false;
            vmSshKeyPathDirty = false;
            jQuery("#waitDialog").dialog("open");
            form.submit();
        }
    });

    jQuery.validator.addMethod("checkValidServerAddress", function(address, element) {

        var result = isValidServerAddress(address);
        return this.optional(element) || result;
    });
    jQuery.validator.addMethod("validchars", function(value, element) {

        return this.optional(element) || /^[\x20-\x3B\x3D\x3F-\x7E]+$/.test(value);
    }, resInvalidCharacters);
    jQuery.validator.addMethod("usascii", function(value, element) {

        return this.optional(element) || /^[\x20-\x7E]+$/.test(value);
    }, resInvalidCharacters);
    jQuery.validator.addMethod("whitespace", function(value, element) {

        return this.optional(element) || /^\S.*\S$/.test(value);
    }, resPassPhraseWhiteSpaceError);
}

function validateForm(pageForm) {
    validateNutanixPasswords();
    if (jQuery(pageForm).validate().form()) {
        jQuery(pageForm).validate().resetForm();
    }
}

function makeInitPasswordValidation(changePasswordDialog) {
    return function() {
        if (jQuery(changePasswordDialog.passwordForm).length == 0) {
            return;
        }

        makePasswordMatchRule(changePasswordDialog);

        jQuery(changePasswordDialog.passwordForm).validate({
            ignoreTitle : true,
            rules : {
                ignore : [],
                vmnewPassword1 : {
                    required : true,
                    usascii : true,
                    rangelength : [
                            3, 32
                    ]
                },
                vmnewPassword2 : {
                    required : true,
                    vmPasswordMatch : true
                },
                vmnewPassphrase2 : {
                    vmPassphraseMatch : true
                },
            },
            messages : {
                vmnewPassword1 : {
                    required : resRequiredFieldValidation,
                    rangelength : resRangeLengthValidation
                },
                vmnewPassword2 : {
                    required : resRequiredFieldValidation
                }
            },
            errorPlacement : function(error, element) {

                // display error message after the label-value-pair row
                error.appendTo(element.closest(".labelvaluediv"));
            }
        });
    };
}

function confirmExit() {
    if (dirty || vmpasswordDirty || vmpassphraseDirty || vmSshKeyPathDirty) {
        return ("");
    }
}

function validateNutanixPasswords() {
    var newClusterPasswordToSet = jQuery("#" + resVMPasswordName).length > 0;
    var isSSHKeyFieldEmpty = jQuery("#nutanix_ssh_key_path").val() === "";
    var error = false;
    
    if (isSSHKeyFieldEmpty || newClusterPasswordToSet) {
        
        if (!(newClusterPasswordToSet || isClusterPasswordSet)) {
            jQuery("#nutanixClusterPasswordRequired").show();
            error = true;
            jQuery("#apply").button('option', 'disabled', true);
        } else {
            jQuery("#nutanixClusterPasswordRequired").hide();
        }
    }
    
    if(!error) {
        jQuery("#apply").button('option', 'disabled', false);
        jQuery("#nutanixClusterPasswordRequired").hide();
    }
}
