var resRequiredFieldValidation, resRangeValidation, $delay, $interval, $user;
var notifyUsersFormId = "#NotifyUsers";
function initNotifyUser () {

    $form = jQuery( notifyUsersFormId );
    $delay = jQuery( "#Delay" );
    $interval = jQuery( "#Interval" );
    $user = jQuery( "#User" );
    resRequiredFieldValidation = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();

    jQuery( "#Enable" ).click( function () {

        showHideNotifyOptions();
    } );

    initNotifyValidation();
    showHideNotifyOptions();

    initWaitDialog();
    validateForm();
}

function initNotifyValidation () {

    $form.validate( {
        ignore : ".ignore",
        rules : {
            Interval : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            Delay : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            User : {
                validateNotifyUser : true
            }
        },
        messages : {
            Interval : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            Delay : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            User : {
                validateNotifyUser : resRequiredFieldValidation
            }
        },
        // errorContainer: jQuery("#errorcontainer"),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );
    jQuery.validator.addMethod( "validateNotifyUser", function () {

        var result = validateNotifyUser();
        return result;
    } );
}

function showHideNotifyOptions () {

    if ( jQuery( "#Enable" ).is( ":checked" ) ) {
        jQuery( "#settingsdiv" ).show();
        $delay.removeClass( "ignore" );
        $interval.removeClass( "ignore" );
        $user.removeClass( "ignore" );
        $form.validate().resetForm();
    }
    else {
        $delay.addClass( "ignore" );
        $interval.addClass( "ignore" );
        $user.addClass( "ignore" );
        jQuery( "#settingsdiv" ).hide();
    }
}

function validateNotifyUser () {

    if ( jQuery( "#NotifySpecificUser" ).is( ':checked' ) ) {
        var user = jQuery( "input[name='User']" ).val();
        if ( user == null || user.length == 0 ) return false;
    }
    return true;
}
