var resRequiredFieldValidation, resRangeValidation, $delay, $param;
var $form = null;

function initCfgShutdown () {

    $form = jQuery( "#Shutdown" );
    $delay = jQuery( "#Delay" );
    $param = jQuery( "#paramValue" );
    resRequiredFieldValidation = jQuery( "#resRequiredFieldValidation" ).text();
    resRangeValidation = jQuery( "#resRangeValidation" ).text();

    jQuery( "#Enable" ).click( function () {

        showHideShutdownOptions();
    } );

    initShutdownValidation();
    showHideShutdownOptions();

    initWaitDialog();
    validateForm();
}

function initShutdownValidation () {

    $form.validate( {
        ignore : ".ignore",
        rules : {
            Delay : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            },
            paramValue : {
                required : true,
                range : [
                        0, 172800
                ],
                digits : [
                        0, 172800
                ]
            }

        },
        messages : {
            Delay : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            },
            paramValue : {
                required : resRequiredFieldValidation,
                range : resRangeValidation,
                digits : resRangeValidation
            }

        },
        // errorContainer: jQuery("#errorcontainer"),
        errorPlacement : function ( error, element ) {

            // display error message after the label-value-pair row
            error.appendTo( element.closest( ".labelvaluediv" ) );
        },
        submitHandler : function ( form ) {

            jQuery( "#waitDialog" ).dialog( "open" );
            form.submit();
        }
    } );
}

function showHideShutdownOptions () {

    if ( jQuery( "#Enable" ).is( ":checked" ) ) {
        jQuery( "#settingsdiv" ).show();
        $delay.removeClass( "ignore" );
        $param.removeClass( "ignore" );
        $form.validate().resetForm();
    }
    else {
        $delay.addClass( "ignore" );
        $param.addClass( "ignore" );
        jQuery( "#settingsdiv" ).hide();
    }
}
