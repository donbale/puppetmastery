var dirty;

jQuery( document ).ready( function () {

    dirty = false;
    loadCheckForUpdates();
    initWaitDialog();

    jQuery( "input" ).change( function () {

        dirty = true;
    } );

    jQuery( "#Reset" ).click( function () {

        dirty = false;
    } );

    jQuery( '#Apply' ).click( function ( e ) {

        e.preventDefault(); // cancel form submission
        dirty = false;
        jQuery( "#waitDialog" ).dialog( "open" );
        setTimeout( function () {

            jQuery( "#checkUpdatesForm" ).submit();
        }, 2000 );
    } );

    window.onbeforeunload = confirmExit;
} );

function loadCheckForUpdates () {

    jQuery.ajax( {
        type : "POST",
        url : "/AJAXCheckUpdates",
        success : function ( data ) {

            jQuery( '#checkUpdates' ).html( data );
            jQuery( '.newbutton' ).button();
        }
    } );
}

function checkForUpdates () {

    jQuery( "#checkUpdatesWaitDialog" ).dialog( "open" );
    jQuery.post( '/AJAXCheckUpdates', function ( data ) {

        jQuery( '#checkUpdates' ).html( data );
        jQuery( '.newbutton' ).button();
        jQuery( "#checkUpdatesWaitDialog" ).dialog( "close" );
    } );
}
