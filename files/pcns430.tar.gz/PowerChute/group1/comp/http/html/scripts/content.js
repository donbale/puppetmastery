jQuery( document ).ready( function () {

    jQuery( '.newbutton' ).button();

    initializeTooltips();

    if ( jQuery( "#heartbeat" ).length > 0 ) {
        initHeartBeat();
    }

    // prevent enter key from submitting the form
    blockSubmitOnEnter();
    extendDialog();
} );

function initializeTooltips () {

    // set tooltips for input fields
    jQuery( "[title]" ).tooltip( {
        position : {
            my : "left bottom-4",
            at : "left top"
        },
        show : "fade",
        hide : "fade"
    } ).filter( "a, select, input" ).off( "focusin focusout" );
}

// prevent form submit on pressing enter key in any text input field
function blockSubmitOnEnter () {

    // Prevent submit on pressing Enter-key for all input fields.
    // The only exception is the password field on PCNS login page.
    jQuery( "input" ).not( "#pcnsmainpass" ).keydown( function ( event ) {

        var code = ( event.keyCode ? event.keyCode : event.which );
        if ( code == 13 && event.currentTarget.type != "submit" ) {
            event.preventDefault();
            return false;
        }
    } );
}

function initWaitDialog () {

    jQuery( ".waitDialog" ).dialog( {
        height : 140,
        modal : true,
        closeOnEscape : false,
        closeText : "hide",
        resizable : false,
        draggable : false,
        autoOpen : false,
        position : {
            my : "center",
            at : "center",
            of : "#container"
        },
        open : function () {

            var thisRef = $( this );
            // remove close button
            thisRef.parents( ".ui-dialog:first" ).find( ".ui-dialog-titlebar-close" ).remove();
            // set hourglass cursor
            thisRef.parents().find( ".ui-widget-overlay:first, .ui-dialog:first" ).css( "cursor", "wait" );
        }
    } );
}

function isValidServerAddress ( address ) {

    var regex_ipv4 = new RegExp(
            "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$" ), regex_ipv6 = new RegExp(
            "^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$" ), regex_hostname = new RegExp(
            "(?=^.{1,253}$)(^(((?!-)[a-zA-Z0-9-]{0,62}[a-zA-Z0-9])|((?!-)[a-zA-Z0-9-]{0,62}[a-zA-Z0-9]\\.)+[a-zA-Z]{2,63})$)" );

    return regex_ipv4.test( address ) || regex_ipv6.test( address ) || regex_hostname.test( address );
}
